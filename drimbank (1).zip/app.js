
// ── Landing screen slide logic ────────────────────────
const landingSlides = [
  { badge:'Smart Banking',  title:'Banking\nReimagined',    sub:'Manage all your finances in one secure, powerful platform designed for the modern world.' },
  { badge:'Instant Transfers', title:'Send Money\nInstantly',  sub:'Transfer funds locally & internationally in seconds with zero hidden fees.' },
  { badge:'Maximum Security', title:'Bank-Grade\nSecurity',  sub:'AES-256 encryption, biometric authentication and real-time fraud detection protect you 24/7.' },
];
let landingIdx = 0;
let landingTimer = null;

function updateLandingSlide(animate) {
  const s = landingSlides[landingIdx];
  const titleEl = document.getElementById('ld-title');
  const subEl   = document.getElementById('ld-sub');
  const badgeEl = document.getElementById('ld-badge');
  const dotsEl  = document.getElementById('ld-dots');

  const setContent = () => {
    const lines = s.title.split('\n');
    if(titleEl) titleEl.innerHTML = lines.map((l,i) => i===1 ? `<span style="color:#60A5FA;">${l}</span>` : l).join('<br>');
    if(subEl) subEl.textContent = s.sub;
    if(badgeEl) badgeEl.textContent = s.badge;
  };

  if(animate) {
    [titleEl,subEl,badgeEl].forEach(el=>{ if(el){ el.style.transition='opacity .25s ease,transform .25s ease'; el.style.opacity='0'; el.style.transform='translateY(12px)'; } });
    setTimeout(()=>{ setContent(); [titleEl,subEl,badgeEl].forEach(el=>{ if(el){ el.style.opacity='1'; el.style.transform='translateY(0)'; } }); }, 260);
  } else {
    setContent();
  }

  if(dotsEl) {
    dotsEl.innerHTML = '';
    landingSlides.forEach((_,i) => {
      const d = document.createElement('div');
      d.style.cssText = `height:5px;border-radius:3px;transition:all .35s;background:${i===landingIdx?'#3b82f6':'rgba(255,255,255,0.18)'};width:${i===landingIdx?'24px':'6px'};cursor:pointer;`;
      d.onclick = () => { landingIdx=i; updateLandingSlide(true); };
      dotsEl.appendChild(d);
    });
  }
}

function startLandingSlides() {
  clearInterval(landingTimer);
  landingIdx = 0;
  updateLandingSlide(false);
  landingTimer = setInterval(() => {
    landingIdx = (landingIdx + 1) % landingSlides.length;
    updateLandingSlide(true);
  }, 3500);
}
// alias
function startLandingSlider() { startLandingSlides(); }
function toggleLandingMenu() {}

document.addEventListener('DOMContentLoaded', () => {
  const base = window.showScreen;
  if(typeof base === 'function') {
    window.showScreen = function(name) {
      base.call(this, name);
      if(name === 'landing') { startLandingSlides(); }
      else { clearInterval(landingTimer); }
    };
  }
});



// ─── State ───────────────────────────────────────────────────────────────────
let users = [];
let currentUser = null;
let alerts = [];
let currentAppScreen = 'dashboard';
let regStep = 1;
let regForm = {};
let regOtp = '';
let slideIdx = 0;
let darkMode = false;
let appScreenHistory = []; // back navigation stack
let idleTimer = null;
const IDLE_TIMEOUT_MS = null; // Auto sign-out disabled
const slides = [
  { icon:'🏦', title:'Smart Banking', sub:'Manage all your finances in one secure, powerful platform.' },
  { icon:'💸', title:'Instant Transfers', sub:'Send money locally & internationally in seconds.' },
  { icon:'🔒', title:'Bank-Grade Security', sub:'AES-256 encryption & biometric authentication protect you.' },
];

// ─── Cloud Storage — Firebase Firestore (Real-Time) ──────────────────────────
const DARK_KEY = 'drimbank_dark_v3';

let activationCodes = {};
let _db = null;                      // Firestore instance
let _unsubscribe = null;             // Real-time listener handle
let _appReady = false;               // True only after full startup completes
let _saving  = false;               // True while saveUsers() is writing to Firestore
const FS_COL = 'drimbank';
const FS_DOC = 'appdata';

// ── Your Firebase project config ─────────────────────────────────────────────
// Create a free project at https://console.firebase.google.com
// then paste your config below (or enter via Settings > Connect Cloud Storage)
// Firebase config — baked in
let FIREBASE_CFG = {
  apiKey:            "AIzaSyDPHne--lN0pRCqAXYEfmOS2KyWjHvOj0g",
  authDomain:        "drimbank-e2caf.firebaseapp.com",
  projectId:         "drimbank-e2caf",
  storageBucket:     "drimbank-e2caf.firebasestorage.app",
  messagingSenderId: "471730179536",
  appId:             "1:471730179536:web:0d2f2beba5ade6a2833dd5"
};

function isFirebaseConfigured() { return !!_db; }
function showStorageStatus(msg, color) {}

// ── Init Firestore and start real-time listener ───────────────────────────────
async function _initFirestore(cfg) {
  try {
    if (!window.firebase) { addToast('Firebase SDK not loaded', 'error'); return false; }
    // Initialize app (only once)
    if (!firebase.apps || firebase.apps.length === 0) {
      firebase.initializeApp(cfg);
    }
    _db = firebase.firestore();
    // Start real-time listener — fires instantly on ANY change from any device
    if (_unsubscribe) _unsubscribe();
    _unsubscribe = _db.collection(FS_COL).doc(FS_DOC).onSnapshot(snap => {
      if (!snap.exists) return;
      const data = snap.data();
      if (!Array.isArray(data.users)) return;
      users = data.users;
      if (data.activationCodes) activationCodes = data.activationCodes;
      // Update localStorage cache
      try { localStorage.setItem('drimbank_users_cache', JSON.stringify(users)); } catch(_) {}
      try { localStorage.setItem('cb_activation_codes', JSON.stringify(activationCodes)); } catch(_) {}
      // If logged in AND startup is complete, refresh currentUser and re-render current screen.
      // The _appReady guard prevents the initial snapshot (fired during _initFirestore)
      // from triggering re-renders or interfering with the admin upsert at startup.
      // Skip re-render if we triggered this snapshot ourselves (our own saveUsers write)
      if (currentUser && _appReady && !_saving) {
        const fresh = users.find(u => u.id === currentUser.id);
        if (fresh) {
          currentUser = fresh;
          try { $('top-avatar').src = currentUser.avatar; } catch(_) {}
          // Re-render whatever screen is currently active so admin changes
          // (balance, freeze, wallet, links, etc.) appear immediately on all devices
          if (currentAppScreen) {
            const renderers = {
              dashboard: renderDashboard, transfer: renderTransfer, cards: renderCards,
              crypto: renderCrypto, savings: renderSavings, loans: renderLoans,
              history: renderHistory, notifications: renderNotifications,
              support: renderSupport, profile: renderProfile, admin: renderAdmin,
              subscription: renderSubscription, deposit: renderDeposit, withdraw: renderWithdraw,
            };
            const fn = renderers[currentAppScreen];
            if (fn) {
              const content = $('screen-content');
              if (content) {
                const result = fn();
                if (result && typeof result.then === 'function') {
                  result.then(html => { if (currentAppScreen === currentAppScreen) content.innerHTML = html || ''; });
                } else {
                  content.innerHTML = result || '';
                }
              }
            }
          }
        }
      }
    }, err => {
      console.error('[Firestore] listener error:', err);
    });
    console.log('[Firestore] Real-time sync active');
    return true;
  } catch(e) {
    console.error('[Firestore] init failed:', e);
    return false;
  }
}

async function saveUsers() {
  // Always cache locally first
  try { localStorage.setItem('drimbank_users_cache', JSON.stringify(users)); } catch(_) {}
  try { localStorage.setItem('cb_activation_codes', JSON.stringify(activationCodes)); } catch(_) {}
  // Push to Firestore
  if (!_db) return;
  // Set _saving flag so the onSnapshot triggered by this write doesn't
  // re-render the screen with potentially stale data mid-write
  _saving = true;
  try {
    await _db.collection(FS_COL).doc(FS_DOC).set({ users, activationCodes });
  } catch(e) {
    console.error('[Firestore] saveUsers failed:', e);
  } finally {
    // Clear after a short delay to allow the echo snapshot to pass through
    setTimeout(() => { _saving = false; }, 1500);
  }
}

async function loadUsers() {
  if (!_db) { _loadFromLocalStorage(); return; }
  // The onSnapshot listener attached in _initFirestore fires immediately (synchronously
  // queued) and populates users[] before this .get() resolves. We still do the .get()
  // as a reliable one-shot read, but if onSnapshot already gave us data we keep it.
  try {
    const snap = await _db.collection(FS_COL).doc(FS_DOC).get();
    if (snap.exists) {
      const data = snap.data();
      if (Array.isArray(data.users) && data.users.length > 0) {
        users = data.users;
        if (data.activationCodes) activationCodes = data.activationCodes;
        try { localStorage.setItem('drimbank_users_cache', JSON.stringify(users)); } catch(_) {}
        try { localStorage.setItem('cb_activation_codes', JSON.stringify(activationCodes)); } catch(_) {}
        return;
      }
    }
  } catch(e) {
    console.error('[Firestore] loadUsers failed:', e);
  }
  // Only fall back to localStorage if Firestore gave us nothing
  if (users.length === 0) _loadFromLocalStorage();
}

function _loadFromLocalStorage() {
  try {
    const cache = localStorage.getItem('drimbank_users_cache');
    if (cache) users = JSON.parse(cache);
    const codes = localStorage.getItem('cb_activation_codes');
    if (codes) activationCodes = JSON.parse(codes);
  } catch(_) {}
  if (!Array.isArray(users)) users = [];
}

// Firebase is now initialized in the main DOMContentLoaded handler below,
// which ensures it completes before loadUsers() is called (eliminating the race condition).

async function saveDarkPref(on) {
  try { localStorage.setItem(DARK_KEY, on ? '1' : '0'); } catch(_) {}
}

async function loadDarkPref() {
  try { if (localStorage.getItem(DARK_KEY) === '1') applyDark(true); } catch(_) {}
}

function applyDark(on) {
  darkMode = on;
  document.documentElement.setAttribute('data-theme', on ? 'dark' : '');
  document.body.style.background = on ? '#0d1117' : '#F5F7FB';
  const appContent = document.getElementById('app-content');
  if (appContent) appContent.style.background = on ? '#0d1117' : '';
}
function toggleDarkMode() {
  applyDark(!darkMode);
  saveDarkPref(darkMode);
  addToast(darkMode ? '🌙 Dark mode on' : '☀️ Light mode on', 'info');
  if(currentAppScreen==='profile') goScreen('profile');
}

// updateCurrentUser is defined below after loginUser


// ─── Utilities ────────────────────────────────────────────────────────────────
const uid = () => Math.random().toString(36).slice(2,10).toUpperCase();
const genAccountNumber = () => Math.floor(1000000000 + Math.random()*9000000000).toString();
const genCardNumber = () => Array.from({length:4}, () => Math.floor(1000+Math.random()*9000)).join(' ');
const genCVV = () => Math.floor(100 + Math.random()*900).toString();
const genExpiry = () => { const d = new Date(); return `${String(d.getMonth()+1).padStart(2,'0')}/${String(d.getFullYear()+4).slice(2)}`; };
const fmtMoney = n => new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
const fmtDate = d => new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'});
const $ = id => document.getElementById(id);

// ─── Privacy helpers ──────────────────────────────────────────────────────────
function maskEmail(email) {
  if (!email) return '—';
  const [local, domain] = email.split('@');
  if (!domain) return email;
  const visible = local.length > 2 ? local.slice(0,2) : local[0] || '';
  const masked = visible + '*'.repeat(Math.max(3, local.length - 2));
  const [dname, ...drest] = domain.split('.');
  const maskedDomain = dname.slice(0,1) + '*'.repeat(Math.max(2, dname.length-1)) + '.' + (drest.join('.') || 'com');
  return masked + '@' + maskedDomain;
}
function maskPhone(phone) {
  if (!phone) return '—';
  const digits = phone.replace(/\D/g,'');
  if (digits.length < 6) return phone.slice(0,2) + '***' + phone.slice(-2);
  return phone.slice(0,3) + ' *****' + phone.slice(-3);
}

// ─── Balance visibility ───────────────────────────────────────────────────────
let balanceVisible = true;
function toggleBalanceVisibility() {
  balanceVisible = !balanceVisible;
  // Update all balance display elements on the dashboard
  const balEl = document.getElementById('dash-balance-display');
  const savEl = document.getElementById('dash-savings-display');
  const eyeBtn = document.getElementById('dash-balance-eye');
  if (balEl) balEl.textContent = balanceVisible ? fmtMoney(currentUser.balance) : '••••••';
  if (savEl) savEl.textContent = balanceVisible ? fmtMoney(currentUser.savings) : '••••';
  // Also update all .balance-amount elements
  document.querySelectorAll('.balance-amount').forEach(el=>{
    if(balanceVisible){ if(el.dataset.real) el.innerHTML=el.dataset.real; }
    else { if(!el.dataset.real) el.dataset.real=el.innerHTML; el.innerHTML='••••••'; }
  });
  if (eyeBtn) eyeBtn.innerHTML = balanceVisible
    ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.7)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>'
    : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.7)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>';
}

function sampleTransactions() {
  const d = (n) => new Date(Date.now() - n*3600000).toISOString();
  return [
    {id:uid(),type:'credit',desc:'Salary – Acme Corp',amount:4850.00,date:d(2),category:'Income'},
    {id:uid(),type:'debit',desc:'Netflix Subscription',amount:-15.49,date:d(18),category:'Entertainment'},
    {id:uid(),type:'debit',desc:'Uber Eats – Order #2947',amount:-34.20,date:d(28),category:'Food & Drink'},
    {id:uid(),type:'credit',desc:'Refund – Apple Store',amount:129.00,date:d(50),category:'Income'},
    {id:uid(),type:'debit',desc:'Shell Fuel Station',amount:-62.80,date:d(72),category:'Transport'},
    {id:uid(),type:'debit',desc:'Tesco Extra – Groceries',amount:-118.35,date:d(96),category:'Groceries'},
    {id:uid(),type:'debit',desc:'AWS Cloud Services',amount:-23.47,date:d(120),category:'Technology'},
    {id:uid(),type:'credit',desc:'Bank Interest Credit',amount:12.40,date:d(145),category:'Income'},
    {id:uid(),type:'debit',desc:'Planet Fitness – Monthly',amount:-24.99,date:d(170),category:'Health'},
    {id:uid(),type:'debit',desc:'Starbucks',amount:-7.85,date:d(180),category:'Food & Drink'},
    {id:uid(),type:'debit',desc:'Adobe Creative Cloud',amount:-54.99,date:d(200),category:'Technology'},
    {id:uid(),type:'credit',desc:'Freelance Invoice #112',amount:800.00,date:d(220),category:'Income'},
    {id:uid(),type:'debit',desc:'Amazon – Electronics',amount:-249.99,date:d(250),category:'Shopping'},
    {id:uid(),type:'debit',desc:'Spotify Premium',amount:-9.99,date:d(270),category:'Entertainment'},
    {id:uid(),type:'credit',desc:'Wire Transfer – James O.',amount:350.00,date:d(300),category:'Income'},
    {id:uid(),type:'debit',desc:'Walgreens Pharmacy',amount:-38.47,date:d(320),category:'Health'},
    {id:uid(),type:'debit',desc:'McDonald\'s – Drive Thru',amount:-14.60,date:d(340),category:'Food & Drink'},
    {id:uid(),type:'debit',desc:'T-Mobile – Monthly Bill',amount:-85.00,date:d(360),category:'Technology'},
    {id:uid(),type:'credit',desc:'PayPal Transfer Received',amount:200.00,date:d(390),category:'Income'},
    {id:uid(),type:'debit',desc:'IKEA – Home Decor',amount:-176.32,date:d(420),category:'Shopping'},
    {id:uid(),type:'debit',desc:'Delta Airlines – Ticket',amount:-312.00,date:d(460),category:'Transport'},
    {id:uid(),type:'credit',desc:'Cashback Reward Credit',amount:45.00,date:d(490),category:'Income'},
    {id:uid(),type:'debit',desc:'Whole Foods Market',amount:-92.15,date:d(510),category:'Groceries'},
    {id:uid(),type:'debit',desc:'Gym Membership – Equinox',amount:-110.00,date:d(540),category:'Health'},
    {id:uid(),type:'credit',desc:'Salary – Acme Corp',amount:4850.00,date:d(570),category:'Income'},
    {id:uid(),type:'debit',desc:'Apple Music',amount:-10.99,date:d(600),category:'Entertainment'},
    {id:uid(),type:'debit',desc:'BP Gas Station',amount:-55.40,date:d(630),category:'Transport'},
    {id:uid(),type:'debit',desc:'H&M – Clothing',amount:-87.50,date:d(660),category:'Shopping'},
    {id:uid(),type:'credit',desc:'Zelle – Sarah M.',amount:150.00,date:d(690),category:'Income'},
    {id:uid(),type:'debit',desc:'Domino\'s Pizza',amount:-29.99,date:d(720),category:'Food & Drink'},
  ];
}

// ─── Toast ───────────────────────────────────────────────────────────────────
function addToast(msg, type='info') {
  const id = uid();
  const colors = {error:'#EF4444', success:'#111827', info:'#0A2540'};
  const el = document.createElement('div');
  el.className='toast';
  el.style.background = colors[type]||colors.info;
  el.innerHTML = `<span style="flex:1;">${msg}</span><button class="toast-close" onclick="this.parentElement.remove()">×</button>`;
  $('toast-container').appendChild(el);
  setTimeout(()=>el.remove(), 4000);
}

// ─── Email ───────────────────────────────────────────────────────────────────
function addAlert(a) {
  alerts.push(a);
  // Persist alerts inside the user object so they survive page refresh and sync across browsers
  if (currentUser) {
    currentUser.alerts = alerts.slice(-100); // keep last 100
    const idx = users.findIndex(u => u.id === currentUser.id);
    if (idx >= 0) users[idx] = currentUser;
    saveUsers(); // async — fire and forget, UI never blocks
  }
  updateNotifBadge();
}
function updateNotifBadge() {
  const badge = $('notif-badge');
  if(badge) badge.style.display = alerts.length > 0 ? 'block' : 'none';
}

// ─── Resend Email API ─────────────────────────────────────────────────────────
// ─── EmailJS Configuration ────────────────────────────────────────────────────
const EMAILJS_PUBLIC_KEY    = '4dpVMA0cTsd2ykrAv';
const EMAILJS_SERVICE_ID    = 'service_dic8rnp';
const EMAILJS_SECURITY_TPL  = 'template_neaw86k';  // login + PIN change + OTP
const EMAILJS_TRANSACTION_TPL = 'template_r4zqch5'; // transfer + deposit/withdrawal

// ── Initialize EmailJS ────────────────────────────────────────────────────────
(function initEmailJS() {
  function _init() {
    if (window.emailjs) {
      emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
    } else {
      // Script not ready yet — retry after a short delay
      setTimeout(_init, 300);
    }
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _init);
  } else {
    _init();
  }
})();

function _fmtDate(iso) {
  try {
    return new Date(iso).toLocaleString('en-US',{dateStyle:'medium',timeStyle:'short'});
  } catch(_) { return iso || new Date().toLocaleString(); }
}

// Core EmailJS sender
async function _ejsSend(templateId, params) {
  try {
    if (!window.emailjs) {
      console.warn('EmailJS not loaded yet');
      addToast('❌ EmailJS library not loaded — check internet connection', 'error');
      return { sent: false };
    }
    console.log('[EmailJS] Sending via template:', templateId, '→', params.to_email);
    const res = await emailjs.send(EMAILJS_SERVICE_ID, templateId, params, EMAILJS_PUBLIC_KEY);
    console.log('[EmailJS] Success:', res);
    return { sent: true };
  } catch(err) {
    const msg = err?.text || err?.message || JSON.stringify(err);
    console.error('[EmailJS] FAILED:', err);
    addToast('❌ Email error: ' + msg, 'error');
    return { sent: false };
  }
}

// ── Security Email (login / PIN change) ──────────────────────────────────────
async function sendSecurityEmail({ to, userName, eventType, eventTitle, eventSubtitle, eventMessage, date }) {
  return _ejsSend(EMAILJS_SECURITY_TPL, {
    to_email:      to,
    user_name:     userName,
    event_type:    eventType,
    event_title:   eventTitle,
    event_subtitle: eventSubtitle,
    event_message: eventMessage,
    otp_code:      '',
    otp_expiry:    '',
    date:          date || _fmtDate(new Date().toISOString()),
  });
}

// ── Transaction Email (transfer / deposit / withdrawal) ─────────────────────
async function sendTransactionEmail({ to, userName, eventTitle, eventSubtitle, eventMessage, transactionType, amount, recipientName, newBalance, date }) {
  return _ejsSend(EMAILJS_TRANSACTION_TPL, {
    to_email:         to,
    user_name:        userName,
    event_title:      eventTitle,
    event_subtitle:   eventSubtitle,
    event_message:    eventMessage,
    transaction_type: transactionType,
    amount:           amount,
    recipient_name:   recipientName || '—',
    new_balance:      newBalance,
    date:             date || _fmtDate(new Date().toISOString()),
  });
}

// ── sendEmail — routes OTP emails through the existing Security template ──────
// Uses EMAILJS_SECURITY_TPL (template_neaw86k) for all 3 OTP flows:
//   1. Signup email verification
//   2. Login / 2FA verification
//   3. Forgot-password reset code
// Template variables: to_email, user_name, event_type, event_title,
//                     event_subtitle, event_message, date
async function sendEmail(to, subject, htmlBody, otpCode, callerName) {
  // Always log in-app alert
  addAlert({id:uid(),type:'email',subject,body:htmlBody,time:new Date().toISOString()});

  // Only send via EmailJS when there's an OTP code
  if (!otpCode) return { sent: false };

  try {
    if (!window.emailjs) {
      addToast('❌ EmailJS not loaded — check internet', 'error');
      return { sent: false };
    }

    // Determine which OTP flow from subject line
    const subLower   = subject.toLowerCase();
    const isSignup   = subLower.includes('verification');
    const isForgot   = subLower.includes('reset') || subLower.includes('password');

    // Use caller-supplied name, then try regex, then fall back
    const nameMatch  = htmlBody && htmlBody.match(/Hi(?:\s+|,\s*)<strong>([^<]+)<\/strong>/);
    const userName   = callerName || (nameMatch ? nameMatch[1] : 'User');

    const eventType  = isSignup ? 'signup_otp' : isForgot ? 'forgot_otp' : 'login_otp';
    const eventTitle = isSignup
      ? '🔐 Email Verification Code'
      : isForgot
        ? '🔑 Password Reset Code'
        : '🔐 Login Verification Code';
    const eventSubtitle = isSignup
      ? 'Complete your DrimBank account setup'
      : isForgot
        ? 'Use this code to reset your password'
        : 'A new sign-in was detected on your account';
    const expiry = isSignup ? '10' : '5';

    console.log('[OTP Email] Sending to:', to, '| template:', EMAILJS_SECURITY_TPL, '| code:', otpCode);
    const res = await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_SECURITY_TPL, {
      to_email:       to,
      user_name:      userName,
      event_type:     eventType,
      event_title:    eventTitle,
      event_subtitle: eventSubtitle,
      event_message:  `Your one-time verification code is:`,
      otp_code:       otpCode,
      otp_expiry:     expiry,
      date:           _fmtDate(new Date().toISOString()),
    }, EMAILJS_PUBLIC_KEY);
    console.log('[OTP Email] Success:', res);
    addToast('📧 OTP sent to ' + to, 'success');
    return { sent: true };
  } catch (err) {
    const msg = err?.text || err?.message || JSON.stringify(err);
    console.error('[OTP Email] FAILED:', err);
    addToast('❌ OTP email failed: ' + msg, 'error');
    return { sent: false };
  }
}

// ─── Screen Router ────────────────────────────────────────────────────────────
function showScreen(name) {
  try {
    ['splash-screen','landing-screen','register-screen','login-screen','twofa-screen','app-screen'].forEach(id=>{
      const el=$(id);
      if(!el) return;
      el.style.display='none';
    });
    const target = $(name+'-screen');
    if(target) {
      if(name==='register') { target.style.display='flex'; try{initRegister();}catch(e){console.warn(e);} }
      else if(name==='login') { target.style.display='flex'; try{refreshDemoAccounts();}catch(e){console.warn(e);} }
      else if(name==='twofa') { target.style.display='flex'; }
      else if(name==='app') { target.style.display='flex'; }
      else if(name==='landing') { target.style.display='flex'; try{startLandingSlides();}catch(e){console.warn(e);} }
      else target.style.display='block';
    } else {
      const landing = $('landing-screen');
      if(landing) landing.style.display='flex';
    }
  } catch(err) {
    console.error('showScreen error:', err);
    const landing = $('landing-screen');
    if(landing) landing.style.display='flex';
  }
}

// ─── Slide show (legacy stub — new landing uses landingSlides) ────────────────
function updateSlide() {
  // No-op: landing now uses ld-title/ld-sub/ld-dots via updateLandingSlide()
}
// Removed old setInterval — new landing manages its own timer via startLandingSlides()

// ─── Register ────────────────────────────────────────────────────────────────
function initRegister() {
  regStep=1;
  ['reg-step-1','reg-step-2','reg-step-3'].forEach((id,i)=>$(id).style.display=i===0?'block':'none');
  updateRegStepBar(1);
  try{ regClearOtpTimer(); }catch(e){}
  try{ regOtpClearBoxes(); }catch(e){}
}
function updateRegStepBar(step) {
  const titles = ['Create Account', 'Verify Your Email', 'Secure Your Account'];
  const subs = ['Step 1 of 3 — Personal details', 'Step 2 of 3 — Email verification', 'Step 3 of 3 — Set credentials'];
  const t = document.getElementById('reg-header-title');
  const s = document.getElementById('reg-header-sub');
  if(t) t.textContent = titles[step-1] || titles[0];
  if(s) s.textContent = subs[step-1] || subs[0];
  [1,2,3].forEach(i => {
    const pill = document.getElementById('pill-'+i);
    if(pill) pill.style.background = i <= step ? 'rgba(255,255,255,.9)' : 'rgba(255,255,255,.2)';
  });
}

async function regStep1() {
  const fname=$('reg-fname').value.trim(), lname=$('reg-lname').value.trim(),
        email=$('reg-email').value.trim(), phone=$('reg-phone').value.trim();
  if(!fname||!lname||!email||!phone){addToast('Please fill all fields','error');return;}
  if(!email.includes('@')||!email.includes('.')){addToast('Enter a valid email address','error');return;}
  regForm={firstName:fname,lastName:lname,email,phone};
  const btn=$('reg-btn-1');
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span>Sending code...';
  const code=Math.floor(100000+Math.random()*900000).toString();
  regOtp=code;
  const html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f0f2f5;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f2f5;padding:32px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:linear-gradient(135deg,#5C0F0F 0%,#8B1A1A 100%);border-radius:16px 16px 0 0;padding:28px 48px;text-align:center;">
    <span style="color:#ffffff;font-size:22px;font-weight:800;letter-spacing:-0.5px;">🏦 DrimBank</span>
  </td></tr>
  <tr><td style="background:linear-gradient(160deg,#1a0505 0%,#3d0a0a 100%);padding:40px 48px;text-align:center;">
    <div style="font-size:52px;margin-bottom:14px;">🔐</div>
    <h1 style="color:#ffffff;font-size:24px;font-weight:800;margin:0 0 8px;">Verify Your Email</h1>
    <p style="color:rgba(255,255,255,0.6);font-size:14px;margin:0;">Complete your DrimBank account setup</p>
  </td></tr>
  <tr><td style="background:#ffffff;padding:40px 48px;">
    <p style="color:#333;font-size:15px;line-height:1.7;margin:0 0 16px;">Hi <strong>${fname}</strong>,</p>
    <p style="color:#555;font-size:15px;line-height:1.7;margin:0 0 28px;">Welcome to DrimBank — your secure gateway to modern banking. Use the code below to verify your email and activate your account.</p>
    <div style="background:#f8f9fa;border:2px dashed #dee2e6;border-radius:14px;padding:28px;text-align:center;margin:0 0 28px;">
      <p style="color:#888;font-size:11px;text-transform:uppercase;letter-spacing:2px;margin:0 0 10px;font-weight:600;">Your Verification Code</p>
      <div style="color:#5C0F0F;font-size:46px;font-weight:800;letter-spacing:14px;font-family:'Courier New',Courier,monospace;">${code}</div>
      <p style="color:#aaa;font-size:12px;margin:10px 0 0;">⏱ Expires in 10 minutes</p>
    </div>
    <p style="color:#333;font-size:14px;font-weight:700;margin:0 0 10px;">Here's what happens next:</p>
    <table cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Enter this code in the DrimBank app</td></tr>
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Set your secure password</td></tr>
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Start banking with ease</td></tr>
    </table>
    <div style="background:#fff8f0;border-left:4px solid #C9973A;border-radius:0 10px 10px 0;padding:14px 18px;margin-bottom:24px;">
      <p style="color:#92400e;font-size:13px;margin:0;line-height:1.6;">🔒 <strong>Security Notice:</strong> Never share this code with anyone. DrimBank staff will never ask for your OTP.</p>
    </div>
    <p style="color:#999;font-size:14px;margin:0;">Happy banking,<br><strong style="color:#5C0F0F;">Team DrimBank</strong></p>
  </td></tr>
  <tr><td style="background:#ffffff;padding:0 48px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="background:#ffffff;border-radius:0 0 16px 16px;padding:24px 48px;text-align:center;">
    <p style="color:#aaa;font-size:12px;margin:0 0 6px;">Need help? Our <span style="color:#5C0F0F;font-weight:600;">support team</span> is just a click away.</p>
    <p style="color:#ccc;font-size:11px;margin:0;">This is an automated message, please do not reply. &nbsp;|&nbsp; © 2026 DrimBank</p>
  </td></tr>
</table>
</td></tr></table>

</body></html>`;
  btn.disabled=false; btn.innerHTML='Send Verification Code →';

  // Mask email for display: n*****sh@gmail.com
  function maskEmail(e) {
    const [user,domain]=e.split('@');
    if(user.length<=2) return e;
    return user[0]+'*'.repeat(Math.min(5,user.length-2))+user.slice(-1)+'@'+domain;
  }
  const masked=$('reg-otp-masked-email');
  if(masked) masked.textContent=maskEmail(email);

  // Clear any previous boxes
  regOtpClearBoxes();

  // Show OTP directly on screen
  const otpDisplay=$('reg-otp-display');
  const otpShow=$('reg-otp-show');
  const otpMsg=$('reg-otp-msg');
  if(otpDisplay && otpShow){
    otpMsg.textContent='Your verification code:';
    otpShow.textContent=code;
    otpDisplay.style.display='block';
  }
  addToast('✅ Your verification code is displayed below','success');

  $('reg-step-1').style.display='none'; $('reg-step-2').style.display='block';
  updateRegStepBar(2);
  regStartOtpTimer(10*60);

  // Focus first box
  setTimeout(()=>{ const boxes=document.querySelectorAll('.reg-otp-box'); if(boxes[0]) boxes[0].focus(); },100);
}

function regStep2() {
  const input=$('reg-otp-input').value.trim();
  if(!input||input.length<6){addToast('Enter the 6-digit code','error');return;}
  if(input!==regOtp){addToast('Invalid code. Try again.','error');return;}
  regClearOtpTimer();
  $('reg-step-2').style.display='none'; $('reg-step-3').style.display='block';
  updateRegStepBar(3);
}

// ── OTP Box Wiring ──────────────────────────────────────────────────────────
let regOtpTimerInterval=null;
function regOtpClearBoxes(){
  document.querySelectorAll('.reg-otp-box').forEach(b=>{
    b.value='';
    b.style.borderColor='rgba(255,255,255,0.15)';
    b.style.boxShadow='none';
  });
  const hi=$('reg-otp-input'); if(hi) hi.value='';
}
function regOtpAssemble(){
  const vals=[...document.querySelectorAll('.reg-otp-box')].map(b=>b.value||'').join('');
  const hi=$('reg-otp-input'); if(hi) hi.value=vals;
  return vals;
}
function regOtpFocusStyle(box,active){
  box.style.borderColor=active?'rgba(96,165,250,0.8)':'rgba(255,255,255,0.15)';
  box.style.boxShadow=active?'0 0 0 3px rgba(59,130,246,0.18)':'none';
}
document.addEventListener('DOMContentLoaded',()=>{
  const boxes=[...document.querySelectorAll('.reg-otp-box')];
  boxes.forEach((box,idx)=>{
    box.addEventListener('focus',()=>regOtpFocusStyle(box,true));
    box.addEventListener('blur',()=>regOtpFocusStyle(box,false));
    box.addEventListener('input',e=>{
      // Only keep last digit typed
      box.value=box.value.replace(/\D/g,'').slice(-1);
      regOtpAssemble();
      if(box.value&&idx<boxes.length-1) boxes[idx+1].focus();
      if(regOtpAssemble().length===6) regStep2();
    });
    box.addEventListener('keydown',e=>{
      if(e.key==='Backspace'&&!box.value&&idx>0){ boxes[idx-1].focus(); boxes[idx-1].value=''; regOtpAssemble(); }
      if(e.key==='Enter') regStep2();
    });
    box.addEventListener('paste',e=>{
      e.preventDefault();
      const text=(e.clipboardData||window.clipboardData).getData('text').replace(/\D/g,'').slice(0,6);
      boxes.forEach((b,i)=>{ b.value=text[i]||''; });
      regOtpAssemble();
      const next=boxes[Math.min(text.length,5)]; if(next) next.focus();
      if(text.length===6) setTimeout(regStep2,50);
    });
  });
});
function regStartOtpTimer(seconds){
  regClearOtpTimer();
  let remaining=seconds;
  const el=$('reg-otp-timer');
  function tick(){
    if(!el) return;
    const m=Math.floor(remaining/60), s=remaining%60;
    el.textContent=(m<10?'0':'')+m+':'+(s<10?'0':'')+s;
    if(remaining<=0){ el.textContent='00:00'; el.style.color='#EF4444'; regClearOtpTimer(); return; }
    remaining--;
  }
  tick();
  regOtpTimerInterval=setInterval(tick,1000);
}
function regClearOtpTimer(){ clearInterval(regOtpTimerInterval); regOtpTimerInterval=null; }
async function regResendOtp(){
  if(!regForm||!regForm.email){ addToast('Please restart registration','error'); return; }
  regClearOtpTimer();
  const code=Math.floor(100000+Math.random()*900000).toString();
  regOtp=code;
  regOtpClearBoxes();
  const timerEl=$('reg-otp-timer'); if(timerEl){ timerEl.style.color='#60A5FA'; }
  // Show new OTP on screen
  const otpDisplay=$('reg-otp-display');
  const otpShow=$('reg-otp-show');
  const otpMsg=$('reg-otp-msg');
  if(otpDisplay && otpShow){
    otpMsg.textContent='Your new verification code:';
    otpShow.textContent=code;
    otpDisplay.style.display='block';
  }
  addToast('✅ New verification code generated','success');
  regStartOtpTimer(10*60);
  setTimeout(()=>{ const boxes=document.querySelectorAll('.reg-otp-box'); if(boxes[0]) boxes[0].focus(); },100);
}

async function regStep3() {
  const password=$('reg-password').value, dob=$('reg-dob').value;
  if(!password||password.length<8){addToast('Password must be at least 8 characters','error');return;}
  if(!dob){addToast('Date of birth is required','error');return;}
  const btn=$('reg-btn-3');
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span>Creating account...';
  await new Promise(r=>setTimeout(r,500));
  const acctNum=genAccountNumber();
  const acct={
    id:uid(), firstName:regForm.firstName, lastName:regForm.lastName,
    email:regForm.email, phone:regForm.phone, password, dob, accountNumber:acctNum,
    balance:0, savings:0, transactions:[],
    cards:[], loans:[], savingsPlans:[], createdAt:new Date().toISOString(),
    avatar:`https://ui-avatars.com/api/?name=${encodeURIComponent(regForm.firstName)}+${encodeURIComponent(regForm.lastName)}&background=1352DE&color=fff&size=128`,
  };
  const html=`<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f0f2f5;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f2f5;padding:32px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:linear-gradient(135deg,#5C0F0F 0%,#8B1A1A 100%);border-radius:16px 16px 0 0;padding:28px 48px;text-align:center;">
    <span style="color:#ffffff;font-size:22px;font-weight:800;letter-spacing:-0.5px;">🏦 DrimBank</span>
  </td></tr>
  <tr><td style="background:linear-gradient(160deg,#1a0505 0%,#3d0a0a 100%);padding:40px 48px;text-align:center;">
    <div style="font-size:52px;margin-bottom:14px;">🎉</div>
    <h1 style="color:#ffffff;font-size:24px;font-weight:800;margin:0 0 8px;">Welcome to DrimBank!</h1>
    <p style="color:rgba(255,255,255,0.6);font-size:14px;margin:0;">Your account is ready. Let's get started.</p>
  </td></tr>
  <tr><td style="background:#ffffff;padding:40px 48px;">
    <p style="color:#333;font-size:15px;line-height:1.7;margin:0 0 16px;">Hi <strong>${regForm.firstName}</strong>,</p>
    <p style="color:#555;font-size:15px;line-height:1.7;margin:0 0 28px;">Welcome to DrimBank — your secure gateway to modern banking. Your account has been successfully created and is ready to use.</p>
    <div style="background:linear-gradient(135deg,#5C0F0F,#8B1A1A);border-radius:14px;padding:28px 32px;margin:0 0 28px;">
      <p style="color:rgba(255,255,255,0.6);font-size:11px;text-transform:uppercase;letter-spacing:1.5px;margin:0 0 16px;font-weight:600;">Your Account Details</p>
      <table width="100%" cellpadding="0" cellspacing="0">
        <tr>
          <td style="color:rgba(255,255,255,0.65);font-size:13px;padding-bottom:10px;">Account Number</td>
          <td align="right" style="color:#ffffff;font-size:14px;font-weight:700;font-family:'Courier New',monospace;padding-bottom:10px;">${acctNum}</td>
        </tr>
        <tr>
          <td style="color:rgba(255,255,255,0.65);font-size:13px;">Opening Balance</td>
          <td align="right" style="color:#4ade80;font-size:15px;font-weight:800;">$0.00</td>
        </tr>
      </table>
    </div>
    <p style="color:#333;font-size:14px;font-weight:700;margin:0 0 12px;">Here's what you can do:</p>
    <table cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Verify your email</td></tr>
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Add money to your account</td></tr>
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Start buying, selling, and sending with ease</td></tr>
      <tr><td style="padding:5px 0;color:#555;font-size:14px;">✅ &nbsp;Get a virtual card instantly</td></tr>
    </table>
    <p style="color:#999;font-size:14px;margin:0;">We're excited to have you on board.<br><br>Happy banking,<br><strong style="color:#5C0F0F;">Team DrimBank</strong></p>
  </td></tr>
  <tr><td style="background:#ffffff;padding:0 48px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="background:#ffffff;border-radius:0 0 16px 16px;padding:24px 48px;text-align:center;">
    <p style="color:#aaa;font-size:12px;margin:0 0 6px;">Need help? Our <span style="color:#5C0F0F;font-weight:600;">support team</span> is just a click away.</p>
    <p style="color:#ccc;font-size:11px;margin:0;">This is an automated message, please do not reply. &nbsp;|&nbsp; © 2026 DrimBank</p>
  </td></tr>
</table>
</td></tr></table>


</body></html>`;
    await sendEmail(regForm.email,'Welcome to DrimBank! Your account is ready',html);
  users.push(acct);
  saveUsers();
  btn.disabled=false;
  loginUser(acct);
}

// ─── Forgot Password ──────────────────────────────────────────────────────────
let forgotOtp = '';
let forgotEmail = '';

function showForgotPassword() {
  document.getElementById('forgot-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'forgot-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:32px;max-width:380px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);">
    <div style="text-align:center;margin-bottom:24px;">
      <div style="font-size:48px;margin-bottom:12px;">🔑</div>
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:20px;margin-bottom:6px;">Reset Password</h3>
      <p style="color:var(--text3,#94A3B8);font-size:13px;">Enter your email to receive a reset code</p>
    </div>
    <div id="forgot-step-1">
      <div class="input-group" style="margin-bottom:16px;">
        <label>Email Address</label>
        <input id="forgot-email-input" type="email" placeholder="you@example.com">
      </div>
      <div id="forgot-error" style="display:none;background:rgba(239,68,68,.09);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:10px;margin-bottom:14px;font-size:13px;color:#DC2626;font-weight:600;text-align:center;"></div>
      <button id="forgot-send-btn" onclick="sendForgotOtp()" style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-bottom:10px;">Send Reset Code</button>
    </div>
    <div id="forgot-step-2" style="display:none;">
      <div id="forgot-otp-display" style="display:none;background:rgba(96,165,250,0.1);border:1.5px solid rgba(96,165,250,0.35);border-radius:14px;padding:16px;text-align:center;margin-bottom:16px;">
        <p style="font-size:12px;color:rgba(255,255,255,0.5);margin:0 0 8px;text-transform:uppercase;letter-spacing:0.8px;font-weight:600;">Your Reset Code</p>
        <p id="forgot-otp-show" style="font-family:'DM Mono',monospace;font-size:28px;font-weight:800;color:#60A5FA;letter-spacing:8px;margin:0 0 12px;"></p>
        <button onclick="(function(){const c=document.getElementById('forgot-otp-show').textContent;navigator.clipboard.writeText(c).then(()=>addToast('Code copied!','success')).catch(()=>addToast('Copy failed','error'));})()" style="background:rgba(96,165,250,0.15);border:1px solid rgba(96,165,250,0.3);border-radius:8px;color:#60A5FA;font-family:'Sora',sans-serif;font-size:12px;font-weight:700;padding:7px 16px;cursor:pointer;display:inline-flex;align-items:center;gap:6px;"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>Copy Code</button>
      </div>
      <div class="input-group" style="margin-bottom:16px;">
        <label>6-Digit Reset Code</label>
        <input id="forgot-otp-input" type="number" placeholder="000000">
      </div>
      <div class="input-group" style="margin-bottom:16px;">
        <label>New Password (8+ characters)</label>
        <input id="forgot-new-password" type="password" placeholder="New password">
      </div>
      <div class="input-group" style="margin-bottom:20px;">
        <label>Confirm New Password</label>
        <input id="forgot-confirm-password" type="password" placeholder="Confirm password">
      </div>
      <div id="forgot-error-2" style="display:none;background:rgba(239,68,68,.09);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:10px;margin-bottom:14px;font-size:13px;color:#DC2626;font-weight:600;text-align:center;"></div>
      <button onclick="confirmForgotReset()" style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#00C48C,#00A677);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-bottom:10px;">Reset Password ✅</button>
    </div>
    <button onclick="document.getElementById('forgot-modal').remove()" style="width:100%;padding:12px;border:none;background:none;color:var(--text3,#94A3B8);font-family:'Sora',sans-serif;font-size:13px;font-weight:600;cursor:pointer;">Cancel</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('forgot-email-input')?.focus(), 100);
}

async function sendForgotOtp() {
  const emailInput = document.getElementById('forgot-email-input');
  const errorEl = document.getElementById('forgot-error');
  const btn = document.getElementById('forgot-send-btn');
  if (!emailInput) return;
  const email = emailInput.value.trim().toLowerCase();
  if (!email || !email.includes('@')) { errorEl.style.display='block'; errorEl.textContent='Please enter a valid email.'; return; }

  // Check if user exists
  await loadUsers(); // Refresh from cloud
  const user = users.find(u => u.email.toLowerCase() === email);
  if (!user) { errorEl.style.display='block'; errorEl.textContent='No account found with that email address.'; return; }

  forgotEmail = email;
  forgotOtp = Math.floor(100000 + Math.random() * 900000).toString();

  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Sending...';
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f0f2f5;font-family:'Helvetica Neue',Helvetica,Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f0f2f5;padding:32px 16px;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:linear-gradient(135deg,#5C0F0F 0%,#8B1A1A 100%);border-radius:16px 16px 0 0;padding:28px 48px;text-align:center;">
    <span style="color:#ffffff;font-size:22px;font-weight:800;letter-spacing:-0.5px;">🏦 DrimBank</span>
  </td></tr>
  <tr><td style="background:linear-gradient(160deg,#1a0505 0%,#3d0a0a 100%);padding:40px 48px;text-align:center;">
    <div style="font-size:52px;margin-bottom:14px;">🔑</div>
    <h1 style="color:#ffffff;font-size:24px;font-weight:800;margin:0 0 8px;">Password Reset</h1>
    <p style="color:rgba(255,255,255,0.6);font-size:14px;margin:0;">We received a request to reset your password</p>
  </td></tr>
  <tr><td style="background:#ffffff;padding:40px 48px;">
    <p style="color:#333;font-size:15px;line-height:1.7;margin:0 0 16px;">Hi <strong>${user.firstName}</strong>,</p>
    <p style="color:#555;font-size:15px;line-height:1.7;margin:0 0 28px;">We received a request to reset your DrimBank password. Use the code below to continue. If you didn't make this request, you can safely ignore this email.</p>
    <div style="background:#f8f9fa;border:2px dashed #dee2e6;border-radius:14px;padding:28px;text-align:center;margin:0 0 28px;">
      <p style="color:#888;font-size:11px;text-transform:uppercase;letter-spacing:2px;margin:0 0 10px;font-weight:600;">Password Reset Code</p>
      <div style="color:#5C0F0F;font-size:46px;font-weight:800;letter-spacing:14px;font-family:'Courier New',Courier,monospace;">${forgotOtp}</div>
      <p style="color:#aaa;font-size:12px;margin:10px 0 0;">⏱ Expires in 10 minutes</p>
    </div>
    <div style="background:#fff8f0;border-left:4px solid #C9973A;border-radius:0 10px 10px 0;padding:14px 18px;margin-bottom:24px;">
      <p style="color:#92400e;font-size:13px;margin:0;line-height:1.6;">🔒 <strong>Security Notice:</strong> Never share this code with anyone. DrimBank staff will never ask for your reset code.</p>
    </div>
    <p style="color:#999;font-size:14px;margin:0;">Stay safe,<br><strong style="color:#5C0F0F;">Team DrimBank</strong></p>
  </td></tr>
  <tr><td style="background:#ffffff;padding:0 48px;"><div style="border-top:1px solid #eee;"></div></td></tr>
  <tr><td style="background:#ffffff;border-radius:0 0 16px 16px;padding:24px 48px;text-align:center;">
    <p style="color:#aaa;font-size:12px;margin:0 0 6px;">Need help? Our <span style="color:#5C0F0F;font-weight:600;">support team</span> is just a click away.</p>
    <p style="color:#ccc;font-size:11px;margin:0;">This is an automated message, please do not reply. &nbsp;|&nbsp; © 2026 DrimBank</p>
  </td></tr>
</table>
</td></tr></table>


</body></html>`;
  btn.disabled = false; btn.innerHTML = 'Send Reset Code';

  document.getElementById('forgot-step-1').style.display = 'none';
  document.getElementById('forgot-step-2').style.display = 'block';

  // Show OTP directly on screen
  const forgotOtpDisplay = document.getElementById('forgot-otp-display');
  const forgotOtpShowEl = document.getElementById('forgot-otp-show');
  if(forgotOtpDisplay && forgotOtpShowEl){
    forgotOtpShowEl.textContent = forgotOtp;
    forgotOtpDisplay.style.display = 'block';
  }
  addToast('✅ Your password reset code is displayed below','success');
}

function confirmForgotReset() {
  const otpInput = document.getElementById('forgot-otp-input');
  const newPwInput = document.getElementById('forgot-new-password');
  const confirmPwInput = document.getElementById('forgot-confirm-password');
  const errorEl = document.getElementById('forgot-error-2');
  if (!otpInput || !newPwInput || !confirmPwInput) return;

  const enteredOtp = otpInput.value.trim();
  const newPw = newPwInput.value;
  const confirmPw = confirmPwInput.value;

  if (enteredOtp !== forgotOtp) { errorEl.style.display='block'; errorEl.textContent='❌ Incorrect reset code.'; return; }
  if (!newPw || newPw.length < 8) { errorEl.style.display='block'; errorEl.textContent='Password must be at least 8 characters.'; return; }
  if (newPw !== confirmPw) { errorEl.style.display='block'; errorEl.textContent='Passwords do not match.'; return; }

  const idx = users.findIndex(u => u.email.toLowerCase() === forgotEmail);
  if (idx < 0) { errorEl.style.display='block'; errorEl.textContent='Account not found.'; return; }
  users[idx] = { ...users[idx], password: newPw };
  saveUsers();
  document.getElementById('forgot-modal')?.remove();
  addToast('✅ Password reset successfully! You can now sign in.', 'success');
  forgotOtp = ''; forgotEmail = '';
}

// ─── Login ────────────────────────────────────────────────────────────────────
function refreshDemoAccounts() {
  const el = document.getElementById('demo-accounts');
  if (!el) return;
  if (!users || users.length === 0) {
    el.innerHTML = '<p style="color:rgba(255,255,255,0.3);font-size:12px;font-style:italic;">No demo accounts yet — register to create one.</p>';
    return;
  }
  el.innerHTML = users.slice(0,3).map(u=>`
    <div onclick="$('login-email').value='${u.email}';$('login-password').value='${u.password||''}';"
      style="display:flex;align-items:center;gap:10px;padding:9px 10px;border-radius:10px;cursor:pointer;transition:background .15s;margin-bottom:4px;"
      onmouseover="this.style.background='rgba(255,255,255,0.08)'" onmouseout="this.style.background='transparent'">
      <img src="${u.avatar||''}" style="width:28px;height:28px;border-radius:50%;object-fit:cover;border:1px solid rgba(255,255,255,0.15);" onerror="this.style.display='none'">
      <div style="flex:1;min-width:0;">
        <div style="font-weight:700;color:rgba(255,255,255,0.75);font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${u.firstName} ${u.lastName}</div>
        <div style="font-size:11px;color:rgba(255,255,255,0.35);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${u.email}</div>
      </div>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
    </div>`).join('');
}

// ─── 2FA State ─────────────────────────────────────────────────────────────────
let twoFaUser = null;
let twoFaCode = '';
let twoFaExpiry = null;
let twoFaTimer = null;
let twoFaInputValues = ['','','','','',''];

async function doLogin() {
  const email=$('login-email').value, password=$('login-password').value;
  if(!email||!password){addToast('Enter credentials','error');return;}
  const btn=$('login-btn');
  btn.disabled=true; btn.innerHTML='<span class="spinner"></span>';
  // Always fetch latest data from cloud so wallet addresses and account state are current
  await loadUsers();
  await new Promise(r=>setTimeout(r,500));
  const user=users.find(u=>u.email===email&&u.password===password);
  btn.disabled=false; btn.innerHTML='Sign In →';
  if(!user){addToast('Invalid email or password','error');return;}
  if(user.blocked){addToast('🚫 This account has been blocked. Contact support.','error');return;}
  // Route through 2FA
  twoFaUser = user;
  twoFaInputValues = ['','','','','',''];
  launch2FA(user);
}

function launch2FA(user) {
  // Generate 6-digit code
  twoFaCode = String(Math.floor(100000 + Math.random() * 900000));
  twoFaExpiry = Date.now() + 5 * 60 * 1000; // 5 minutes

  // Send email alert + show 2FA screen
  const ip=`192.168.${Math.floor(Math.random()*254)}.${Math.floor(Math.random()*254)}`;

  // Show 2FA screen
  showScreen('twofa');
  // Update masked email display — slightly longer delay to ensure DOM is ready
  setTimeout(async () => {
    const emailEl = document.getElementById('twofa-masked-email');
    if (emailEl) emailEl.textContent = maskEmail(user.email);
    start2FATimer();
    init2FAInputs();

    // Show OTP directly on screen
    const fb = document.getElementById('twofa-otp-fallback');
    if(fb){
      const codeEl = document.getElementById('twofa-otp-code');
      if(codeEl) codeEl.textContent = twoFaCode;
      fb.style.display = 'block';
    }

    // Scroll to top of 2FA screen
    const twofaScreen = document.getElementById('twofa-screen');
    if (twofaScreen) twofaScreen.scrollTop = 0;
    window.scrollTo(0,0);
  }, 120);
}

function init2FAInputs() {
  twoFaInputValues = ['','','','','',''];
  // Clone all boxes first to strip old listeners, then re-grab
  for (let i = 0; i < 6; i++) {
    const old = document.getElementById('twofa-box-'+i);
    if (!old) continue;
    const fresh = old.cloneNode(true);
    old.parentNode.replaceChild(fresh, old);
  }
  const boxes = [];
  for (let i = 0; i < 6; i++) {
    const b = document.getElementById('twofa-box-'+i);
    if (b) { b.value = ''; boxes.push(b); }
  }
  boxes.forEach((box, i) => {
    box.addEventListener('input', function() {
      const val = this.value.replace(/\D/g,'').slice(-1);
      this.value = val;
      twoFaInputValues[i] = val;
      if (val && i < 5) boxes[i+1].focus();
      if (twoFaInputValues.filter(v=>v).length === 6) verify2FA();
    });
    box.addEventListener('keydown', function(e) {
      if (e.key === 'Backspace') {
        twoFaInputValues[i] = '';
        if (!this.value && i > 0) boxes[i-1].focus();
      }
    });
    box.addEventListener('paste', function(e) {
      e.preventDefault();
      const paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g,'');
      paste.split('').slice(0,6).forEach((ch, j) => {
        if (boxes[j]) { boxes[j].value = ch; twoFaInputValues[j] = ch; }
      });
      if (twoFaInputValues.filter(v=>v).length === 6) verify2FA();
    });
  });
  if (boxes[0]) boxes[0].focus();
}

function start2FATimer() {
  clearInterval(twoFaTimer);
  twoFaTimer = setInterval(() => {
    const remaining = Math.max(0, Math.ceil((twoFaExpiry - Date.now()) / 1000));
    const mins = String(Math.floor(remaining / 60)).padStart(2,'0');
    const secs = String(remaining % 60).padStart(2,'0');
    const el = document.getElementById('twofa-timer');
    if (el) el.textContent = `${mins}:${secs}`;
    if (remaining === 0) {
      clearInterval(twoFaTimer);
      addToast('Verification code expired. Please try again.', 'error');
      showScreen('login');
    }
  }, 1000);
}

function resend2FA() {
  if (!twoFaUser) return;
  twoFaInputValues = ['','','','','',''];
  launch2FA(twoFaUser);
  addToast('A new code has been generated.', 'success');
}

function verify2FA() {
  // Read directly from boxes in case twoFaInputValues is slightly behind
  const boxes = [0,1,2,3,4,5].map(i => document.getElementById('twofa-box-'+i)).filter(Boolean);
  const entered = boxes.map(b => b.value.replace(/\D/g,'')).join('');
  twoFaInputValues = boxes.map(b => b.value.replace(/\D/g,''));
  if (entered.length < 6) { addToast('Enter the 6-digit code', 'error'); return; }
  if (Date.now() > twoFaExpiry) { addToast('Code expired. Please resend.', 'error'); return; }
  if (entered !== twoFaCode) {
    addToast('Incorrect code. Try again.', 'error');
    boxes.forEach(b => { b.value = ''; b.style.borderColor = '#EF4444'; b.style.boxShadow = '0 0 0 3px rgba(239,68,68,0.2)'; });
    twoFaInputValues = ['','','','','',''];
    setTimeout(() => {
      boxes.forEach(b => { b.style.borderColor = '#E2E8F0'; b.style.boxShadow = 'none'; });
      if (boxes[0]) boxes[0].focus();
    }, 1200);
    return;
  }
  clearInterval(twoFaTimer);
  addToast(`Welcome back, ${twoFaUser.firstName}! 👋`,'success');
  loginUser(twoFaUser);
  twoFaUser = null;
}

function resetIdleTimer() {
  if(typeof resetPinLockTimer==='function') resetPinLockTimer();
}
function startIdleWatcher() {
  if(typeof resetPinLockTimer==='function') resetPinLockTimer();
}
function stopIdleWatcher() {
  clearTimeout(idleTimer);
  clearTimeout(typeof pinLockTimer!=='undefined'?pinLockTimer:null);
}

function saveSession() {
  if (!currentUser) return;
  try {
    localStorage.setItem('cb_session_userId', currentUser.id);
    localStorage.setItem('cb_session_screen', currentAppScreen || 'dashboard');
  } catch(_) {}
}

function clearSession() {
  try { localStorage.removeItem('cb_session_userId'); localStorage.removeItem('cb_session_screen'); } catch(_) {}
}

function loginUser(user) {
  // Check if subscriptions have expired — use end-of-day tolerance to prevent
  // premature expiry (e.g. timezone differences, same-day edge cases)
  const now = new Date();
  let subExpired = false;
  if (user.isPro && user.proExpiresAt) {
    const expiry = new Date(user.proExpiresAt);
    expiry.setHours(23, 59, 59, 999); // expire at end of expiry day, not start
    if (expiry < now) { user.isPro = false; subExpired = true; }
  }
  if (user.isBasic && user.basicExpiresAt) {
    const expiry = new Date(user.basicExpiresAt);
    expiry.setHours(23, 59, 59, 999);
    if (expiry < now) { user.isBasic = false; subExpired = true; }
  }
  if (user.isPremium && user.premiumExpiresAt) {
    const expiry = new Date(user.premiumExpiresAt);
    expiry.setHours(23, 59, 59, 999);
    if (expiry < now) { user.isPremium = false; subExpired = true; }
  }
  if (subExpired) {
    const idx = users.findIndex(u => u.id === user.id);
    if (idx >= 0) users[idx] = user;
    saveUsers();
    addToast('Your subscription has expired. Subscribe to renew.', 'info');
  }
  user.lastLoginAt = new Date().toISOString();
  currentUser=user;
  // ── Login email notification ─────────────────────────────────────────────
  sendSecurityEmail({
    to:           user.email,
    userName:     user.firstName + " " + user.lastName,
    eventType:    "Account Login",
    eventTitle:   "New Login Detected",
    eventSubtitle:"Your DrimBank account was just accessed.",
    eventMessage: "We noticed a successful login to your DrimBank account. If this was you, no action is needed. If you do not recognise this activity, please secure your account immediately.",
    date:         _fmtDate(new Date().toISOString()),
  });
  // Restore alerts from user's cloud-persisted notification history
  alerts = Array.isArray(user.alerts) ? [...user.alerts] : [];
  updateNotifBadge();
  $('top-avatar').src=user.avatar;
  showScreen('app');
  const savedScreen = localStorage.getItem('cb_session_screen') || 'dashboard';
  // Push a state so the browser back button can be intercepted
  history.pushState({ app: true }, '');
  goScreen(savedScreen);
  saveSession();
  startIdleWatcher();
}

// ─── Activation Code Modal ────────────────────────────────────────────────────
function openActivationCodeModal() {
  document.getElementById('activation-code-overlay')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'activation-code-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.82);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeUp .25s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:28px;padding:36px 32px 32px;max-width:420px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 32px 80px rgba(0,0,0,.45);">
    <div style="text-align:center;margin-bottom:24px;">
      <div style="width:64px;height:64px;border-radius:20px;background:linear-gradient(135deg,#0A2540,#1352DE);display:flex;align-items:center;justify-content:center;margin:0 auto 14px;">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>
      </div>
      <h2 style="font-size:20px;font-weight:800;color:var(--text,#1E293B);margin-bottom:6px;">Enter Activation Code</h2>
      <p style="font-size:13px;color:var(--text3,#94A3B8);line-height:1.5;">Paste the code you received from admin after payment to unlock your plan.</p>
    </div>
    <div style="margin-bottom:20px;">
      <label style="font-size:11px;font-weight:700;color:var(--text2,#475569);text-transform:uppercase;letter-spacing:.8px;display:block;margin-bottom:8px;">Activation Code</label>
      <input id="activation-code-input" placeholder="DB-XXXX-XXXX" autocomplete="off" autocapitalize="characters"
        style="width:100%;padding:16px 18px;border:2px solid var(--border,#E2E8F0);border-radius:14px;font-family:'DM Mono',monospace;font-size:18px;font-weight:700;text-align:center;letter-spacing:3px;text-transform:uppercase;color:var(--text,#1E293B);background:var(--input-bg,#fff);outline:none;box-sizing:border-box;transition:border .2s;"
        onfocus="this.style.borderColor='#1352DE';this.style.boxShadow='0 0 0 3px rgba(19,82,222,.1)'"
        onblur="this.style.borderColor='';this.style.boxShadow=''"
        oninput="this.value=this.value.toUpperCase().replace(/[^A-Z0-9-]/g,'')"
        onkeydown="if(event.key==='Enter')applyActivationCode()">
    </div>
    <div id="activation-error-msg" style="display:none;background:rgba(239,68,68,.09);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:10px 14px;margin-bottom:16px;font-size:13px;color:#DC2626;font-weight:600;text-align:center;"></div>
    <button onclick="applyActivationCode()" style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#0A2540,#1352DE);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-bottom:10px;display:flex;align-items:center;justify-content:center;gap:8px;transition:opacity .2s;" onmouseover="this.style.opacity='.88'" onmouseout="this.style.opacity='1'">
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/></svg>
      Activate My Plan
    </button>
    <button onclick="document.getElementById('activation-code-overlay').remove()" style="width:100%;padding:12px;border:none;background:none;color:var(--text3,#94A3B8);font-family:'Sora',sans-serif;font-size:13px;font-weight:600;cursor:pointer;">Cancel</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('activation-code-input')?.focus(), 100);
}

function applyActivationCode() {
  const input = document.getElementById('activation-code-input');
  const errorEl = document.getElementById('activation-error-msg');
  if (!input) return;
  const code = input.value.trim().toUpperCase();
  if (!code) {
    errorEl.style.display = 'block'; errorEl.textContent = 'Please enter your activation code.'; return;
  }
  const codeData = activationCodes[code];
  if (!codeData) {
    errorEl.style.display = 'block'; errorEl.textContent = 'Invalid code — check for typos and try again.';
    input.style.borderColor = '#EF4444'; setTimeout(()=>input.style.borderColor='',600); return;
  }
  if (codeData.used) {
    errorEl.style.display = 'block'; errorEl.textContent = 'This code has already been used.'; return;
  }
  // Check if code itself has expired (admin codes expire after 30 days of creation)
  if (new Date(codeData.expiresAfter) < new Date()) {
    errorEl.style.display = 'block'; errorEl.textContent = 'This code has expired. Contact admin for a new one.'; return;
  }

  // Apply the plan
  const plan = codeData.plan; // '2weeks', '1month', 'premium', 'demo'
  const days = codeData.durationDays || (plan === '2weeks' ? 14 : 30);
  const expiry = new Date();
  if (plan === 'demo') {
    expiry.setTime(expiry.getTime() + 2 * 3600 * 1000); // exactly 2 hours from now
  } else {
    expiry.setDate(expiry.getDate() + days);
    expiry.setHours(23, 59, 59, 999);
  }

  let updates = {};
  if (plan === '2weeks') {
    updates = { isBasic: true, isPro: false, isPremium: false, basicExpiresAt: expiry.toISOString(), proExpiresAt: null, premiumExpiresAt: null };
  } else if (plan === '1month') {
    updates = { isPro: true, isBasic: false, isPremium: false, proExpiresAt: expiry.toISOString(), basicExpiresAt: null, premiumExpiresAt: null };
  } else if (plan === 'premium') {
    updates = { isPremium: true, isPro: true, isBasic: false, premiumExpiresAt: expiry.toISOString(), proExpiresAt: expiry.toISOString(), basicExpiresAt: null };
  } else if (plan === 'demo') {
    // Demo: full Premium access but expires in 2 hours
    updates = { isPremium: true, isPro: true, isBasic: false, premiumExpiresAt: expiry.toISOString(), proExpiresAt: expiry.toISOString(), basicExpiresAt: null, isDemoAccess: true };
  }

  // Mark code as used
  activationCodes[code] = { ...codeData, used: true, usedBy: currentUser.id, usedAt: new Date().toISOString() };
  try { localStorage.setItem('cb_activation_codes', JSON.stringify(activationCodes)); } catch(_) {}

  updateCurrentUser(u => ({ ...u, ...updates }));
  saveUsers();

  document.getElementById('activation-code-overlay')?.remove();
  selectedSubPlan = null;

  const planLabel = plan === '2weeks' ? 'Basic (2 Weeks)' : plan === '1month' ? 'Pro (1 Month)' : plan === 'demo' ? 'Demo (2 Hours)' : 'Premium';
  const durationTxt = plan === 'demo' ? '2 hours' : `${days} days`;
  addToast(`✅ ${planLabel} plan activated! Valid for ${durationTxt}.`, 'success');
  goScreen('subscription');
}

function logout() {
  stopIdleWatcher();
  clearSession();
  currentUser=null; alerts=[];
  adminSessionActive = false;
  appScreenHistory = [];
  showScreen('login');
  addToast('Signed out securely.','info');
}

// ─── App Screen Router ─────────────────────────────────────────────────────────
function goScreen(name, addToHistory = true) {
  // Admin guard: non-admin accounts can never reach admin screen
  if (name === 'admin') {
    if (!isAdminAccount(currentUser)) {
      addToast('Access denied.', 'error');
      return;
    }
    // Admin account but PIN not yet verified this session
    if (!adminSessionActive) {
      openAdminPinModal();
      return;
    }
  }
  if (addToHistory && currentAppScreen && currentAppScreen !== name) {
    appScreenHistory.push(currentAppScreen);
    if (appScreenHistory.length > 20) appScreenHistory.shift();
  }
  currentAppScreen=name;
  saveSession();
  // Push a dummy browser history state so the device back button is interceptable
  history.pushState({ app: true, screen: name }, '');
  document.querySelectorAll('.nav-btn').forEach(b=>{
    b.classList.toggle('active', b.id==='nav-'+name);
  });
  updateNotifBadge();
  const content=$('screen-content');
  content.innerHTML='';
  // Apply dark background for crypto screen
  const appContent = document.getElementById('app-content');
  if(appContent) appContent.style.background = (name==='crypto') ? '#0B0F19' : '';
  const renderers = {
    dashboard: renderDashboard, transfer: renderTransfer, cards: renderCards, crypto: renderCrypto,
    savings: renderSavings, loans: renderLoans, history: renderHistory,
    notifications: renderNotifications, support: renderSupport,
    profile: renderProfile, admin: renderAdmin, subscription: renderSubscription,
    deposit: renderDeposit, withdraw: renderWithdraw,
  };
  if(renderers[name]) {
    const result = renderers[name]();
    if(result && typeof result.then === 'function') {
      content.innerHTML = '<div style="padding:48px;text-align:center;color:var(--text3);"><div style="font-size:32px;margin-bottom:12px;">⏳</div><p>Loading...</p></div>';
      result.then(html => { if(currentAppScreen===name) content.innerHTML = html||''; });
    } else {
      content.innerHTML = result || '';
    }
  } else content.innerHTML=`<div style="padding:24px;text-align:center;color:var(--text3);">Screen not found</div>`;
  // Attach event listeners after render
  if(name==='support') initSupport();
  if(name==='transfer') initTransfer();
}

function goBack() {
  if (appScreenHistory.length > 0) {
    const prev = appScreenHistory.pop();
    goScreen(prev, false);
  } else {
    goScreen('dashboard', false);
  }
}

// Intercept browser/device back button so it navigates within the app, not out
window.addEventListener('popstate', function(e) {
  // Always push a new state so there's always something to catch next time
  history.pushState({ app: true }, '');
  if (currentUser) {
    goBack();
  }
});

// Helper to sync currentUser updates
function updateCurrentUser(fn) {
  currentUser = fn(currentUser);
  const idx = users.findIndex(u => u.id === currentUser.id);
  if (idx >= 0) users[idx] = currentUser;
  try { $('top-avatar').src = currentUser.avatar; } catch(_) {}
  try { localStorage.setItem('drimbank_users_cache', JSON.stringify(users)); } catch(_) {}
  return saveUsers();
}


// ─── Back Button Helper ────────────────────────────────────────────────────────
function backBtn(label = 'Back') {
  return `<button onclick="goBack()" style="display:inline-flex;align-items:center;gap:6px;background:none;border:none;color:var(--blue);cursor:pointer;font-size:14px;font-family:'Sora',sans-serif;font-weight:600;padding:0;margin-bottom:16px;">← ${label}</button>`;
}

// ─── Profile Modal Functions ──────────────────────────────────────────────────
function openChangePasswordModal() {
  document.getElementById('change-pw-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'change-pw-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:32px;max-width:380px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">🔐 Change Password</h3>
      <button onclick="document.getElementById('change-pw-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    <div style="display:flex;flex-direction:column;gap:14px;">
      <div class="input-group"><label>Current Password</label><input id="cpw-current" type="password" placeholder="Current password"></div>
      <div class="input-group"><label>New Password (8+ chars)</label><input id="cpw-new" type="password" placeholder="New password"></div>
      <div class="input-group"><label>Confirm New Password</label><input id="cpw-confirm" type="password" placeholder="Confirm password"></div>
      <div id="cpw-error" style="display:none;background:rgba(239,68,68,.09);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:10px;font-size:13px;color:#DC2626;font-weight:600;text-align:center;"></div>
      <button onclick="doChangePassword()" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;">Update Password</button>
    </div>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function doChangePassword() {
  const cur = document.getElementById('cpw-current')?.value;
  const nw = document.getElementById('cpw-new')?.value;
  const conf = document.getElementById('cpw-confirm')?.value;
  const err = document.getElementById('cpw-error');
  if (cur !== currentUser.password) { err.style.display='block'; err.textContent='Current password is incorrect.'; return; }
  if (!nw || nw.length < 8) { err.style.display='block'; err.textContent='New password must be at least 8 characters.'; return; }
  if (nw !== conf) { err.style.display='block'; err.textContent='Passwords do not match.'; return; }
  updateCurrentUser(u => ({...u, password: nw}));
  document.getElementById('change-pw-modal')?.remove();
  addToast('✅ Password changed successfully!', 'success');
}

function openActiveSessionsModal() {
  document.getElementById('sessions-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'sessions-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:32px;max-width:380px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">💻 Active Sessions</h3>
      <button onclick="document.getElementById('sessions-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    <div style="background:var(--bg3,#F1F5F9);border-radius:14px;padding:16px;margin-bottom:16px;">
      <div style="display:flex;align-items:center;gap:12px;">
        <span style="font-size:24px;">📱</span>
        <div style="flex:1;">
          <p style="font-weight:700;color:var(--text,#1E293B);font-size:14px;">This Device</p>
          <p style="color:var(--text3,#94A3B8);font-size:12px;">Current session · Active now</p>
        </div>
        <span style="background:rgba(0,196,140,.15);color:#00A677;font-size:11px;font-weight:700;padding:3px 10px;border-radius:20px;">Current</span>
      </div>
    </div>
    <p style="font-size:13px;color:var(--text3,#94A3B8);text-align:center;margin-bottom:16px;">No other active sessions found.</p>
    <button onclick="logout();document.getElementById('sessions-modal')?.remove();" style="width:100%;padding:14px;border:none;border-radius:14px;background:rgba(239,68,68,.1);color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;border:1px solid rgba(239,68,68,.2);">Sign Out All Devices</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function openNotificationSettings() {
  document.getElementById('notif-settings-modal')?.remove();
  const prefs = currentUser.notifPrefs || { push: true, email: true, sms: false };
  const overlay = document.createElement('div');
  overlay.id = 'notif-settings-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:32px;max-width:380px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">🔔 Notifications</h3>
      <button onclick="document.getElementById('notif-settings-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    ${[['push','📲','Push Notifications','In-app alerts'],['email','📧','Email Notifications','Transaction emails'],['sms','💬','SMS Notifications','Text message alerts']].map(([key,icon,label,sub])=>`
    <div style="display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid var(--border,#E2E8F0);">
      <span style="font-size:22px;">${icon}</span>
      <div style="flex:1;"><p style="font-weight:600;color:var(--text,#1E293B);font-size:14px;">${label}</p><p style="color:var(--text3,#94A3B8);font-size:12px;">${sub}</p></div>
      <div id="notif-toggle-${key}" onclick="toggleNotifPref('${key}')" style="width:42px;height:24px;border-radius:12px;background:${prefs[key]?'#1352DE':'var(--border,#E2E8F0)'};position:relative;transition:background .2s;cursor:pointer;"><div style="position:absolute;top:3px;left:${prefs[key]?'21px':'3px'};width:18px;height:18px;border-radius:50%;background:#fff;transition:left .2s;box-shadow:0 1px 4px rgba(0,0,0,.2);"></div></div>
    </div>`).join('')}
    <button onclick="document.getElementById('notif-settings-modal').remove();addToast('Notification preferences saved ✅','success')" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-top:20px;">Save Preferences</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function toggleNotifPref(key) {
  const prefs = currentUser.notifPrefs || { push: true, email: true, sms: false };
  prefs[key] = !prefs[key];
  updateCurrentUser(u => ({...u, notifPrefs: prefs}));
  const toggle = document.getElementById('notif-toggle-'+key);
  if (toggle) {
    toggle.style.background = prefs[key] ? '#1352DE' : 'var(--border,#E2E8F0)';
    const knob = toggle.querySelector('div');
    if (knob) knob.style.left = prefs[key] ? '21px' : '3px';
  }
}

function openLanguageModal() {
  addToast('Only English (US) is available at this time.', 'info');
}

function openHelpModal() {
  document.getElementById('help-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'help-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:32px;max-width:420px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);max-height:85vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">❓ Help & FAQ</h3>
      <button onclick="document.getElementById('help-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    ${[['How do I send money?','Go to Transfer → Send Money. Enter the recipient\'s account number and amount.'],
       ['How do I deposit funds?','Go to Transfer → Deposit Funds and enter the amount you wish to add.'],
       ['How do I get a virtual card?','Go to Cards → tap "+ Add Card" → choose New Virtual card.'],
       ['What is Pro subscription?','Pro unlocks withdrawals, unlimited deposits, and the ability to add existing cards.'],
       ['How do I enter an activation code?','Go to Profile → tap "Enter Activation Code" and enter the code from admin.'],
       ['How do I apply for a loan?','Go to Loans → tap "Apply Now" and fill in the loan application form.'],
       ['How do I contact support?','Use the Support chat (Maya AI) available from the menu, or email support@drimbank.com.'],
    ].map(([q,a])=>`
    <div style="margin-bottom:16px;background:var(--bg3,#F1F5F9);border-radius:14px;padding:16px;">
      <p style="font-weight:700;color:var(--text,#1E293B);font-size:14px;margin-bottom:6px;">Q: ${q}</p>
      <p style="color:var(--text2,#475569);font-size:13px;line-height:1.6;">A: ${a}</p>
    </div>`).join('')}
    <button onclick="goScreen('support');document.getElementById('help-modal').remove()" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-top:4px;">💬 Chat with Maya AI</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function openPrivacyModal() {
  document.getElementById('privacy-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'privacy-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(12px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:32px;max-width:420px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);max-height:85vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">🛡️ Privacy Policy</h3>
      <button onclick="document.getElementById('privacy-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    <div style="font-size:13px;color:var(--text2,#475569);line-height:1.8;">
      <p style="font-weight:700;color:var(--text,#1E293B);margin-bottom:8px;">Data Collection</p>
      <p style="margin-bottom:16px;">DrimBank collects your name, email, phone number, and financial transaction data solely to operate your account and provide banking services.</p>
      <p style="font-weight:700;color:var(--text,#1E293B);margin-bottom:8px;">Data Security</p>
      <p style="margin-bottom:16px;">All data is encrypted using industry-standard AES-256 encryption. We never sell your personal data to third parties.</p>
      <p style="font-weight:700;color:var(--text,#1E293B);margin-bottom:8px;">Data Retention</p>
      <p style="margin-bottom:16px;">Your data is retained for as long as your account is active. You may request deletion by contacting support.</p>
      <p style="font-weight:700;color:var(--text,#1E293B);margin-bottom:8px;">Contact</p>
      <p>Privacy inquiries: privacy@drimbank.com</p>
    </div>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}
// Only accounts with this email can ever access admin.
// Change this to YOUR email before deploying.
const ADMIN_EMAIL = 'nifemish@gmail.com';
// Admin PIN — change this to your own secret PIN (4–8 digits recommended).
const ADMIN_PIN   = '252025';

let adminSessionActive = false; // true only after PIN verified this session

function isAdminAccount(user) {
  return !!(user && user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());
}

function openAdminPinModal() {
  // Extra safety: only admin email may even open this
  if (!isAdminAccount(currentUser)) {
    addToast('Access denied.', 'error');
    return;
  }
  document.getElementById('admin-pin-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'admin-pin-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.88);backdrop-filter:blur(14px);z-index:5000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:28px;width:100%;max-width:380px;overflow:hidden;font-family:'Sora',sans-serif;box-shadow:0 32px 80px rgba(0,0,0,.5);">

    <!-- Header -->
    <div style="background:linear-gradient(135deg,#0A2540,#1352DE);padding:32px 28px 28px;text-align:center;">
      <div style="width:64px;height:64px;border-radius:20px;background:rgba(255,255,255,.12);border:2px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 16px;">🛡️</div>
      <h2 style="color:#fff;font-size:20px;font-weight:800;margin-bottom:6px;">Admin Access</h2>
      <p style="color:rgba(255,255,255,.6);font-size:13px;">Enter your admin PIN to continue</p>
    </div>

    <!-- PIN input -->
    <div style="padding:28px;">
      <div style="position:relative;margin-bottom:20px;">
        <input id="admin-pin-input" type="password" maxlength="8" placeholder="••••"
          style="width:100%;padding:16px 48px 16px 20px;border-radius:14px;border:2px solid var(--border,#E2E8F0);font-size:24px;font-family:'JetBrains Mono',monospace;letter-spacing:8px;text-align:center;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;box-sizing:border-box;transition:border .2s;"
          onfocus="this.style.borderColor='#1352DE'" onblur="this.style.borderColor=''"
          onkeydown="if(event.key==='Enter')verifyAdminPin()">
      </div>
      <div id="admin-pin-error" style="display:none;background:rgba(239,68,68,.09);border:1px solid rgba(239,68,68,.25);border-radius:10px;padding:10px 14px;margin-bottom:16px;font-size:13px;color:#DC2626;font-weight:600;text-align:center;">❌ Incorrect PIN. Try again.</div>
      <button onclick="verifyAdminPin()" style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#0A2540,#1352DE);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;transition:opacity .2s;margin-bottom:10px;" onmouseover="this.style.opacity='.88'" onmouseout="this.style.opacity='1'">🛡️ Verify &amp; Enter</button>
      <button onclick="document.getElementById('admin-pin-modal').remove()" style="width:100%;padding:12px;border:none;background:none;color:var(--text3);font-family:'Sora',sans-serif;font-size:13px;font-weight:600;cursor:pointer;">Cancel</button>
    </div>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('admin-pin-input')?.focus(), 100);
}

let adminPinAttempts = 0;
function verifyAdminPin() {
  const input = document.getElementById('admin-pin-input');
  const errorEl = document.getElementById('admin-pin-error');
  if (!input) return;
  const val = input.value.trim();

  if (val === ADMIN_PIN) {
    adminPinAttempts = 0;
    adminSessionActive = true;
    document.getElementById('admin-pin-modal')?.remove();
    addToast('🛡️ Admin session active', 'success');
    goScreen('admin');
  } else {
    adminPinAttempts++;
    input.value = '';
    if (errorEl) errorEl.style.display = 'block';
    input.style.borderColor = '#EF4444';
    setTimeout(() => { input.style.borderColor = ''; }, 600);
    // Lock out after 5 wrong attempts
    if (adminPinAttempts >= 5) {
      addToast('Too many wrong attempts. Locked for 60 seconds.', 'error');
      document.getElementById('admin-pin-modal')?.remove();
      adminPinAttempts = 0;
      setTimeout(() => { adminPinAttempts = 0; }, 60000);
    }
  }
}

// ─── Pro Tier ─────────────────────────────────────────────────────────────────
function isPro(user) {
  return !!(user && user.isPro);
}
function isPremium(user) {
  // Premium plan includes crypto + international transfer access
  return !!(user && user.isPremium);
}
function getUserPlanLabel(user) {
  if (!user) return 'Free';
  if (user.isPremium) return 'Premium';
  if (user.isPro) return 'Pro';
  if (user.isBasic) return 'Basic';
  return 'Free';
}

function openProModal() {
  // Redirect to subscription screen instead of old modal
  goScreen('subscription');
}

// ─── Subscription Plans ────────────────────────────────────────────────────────
let selectedSubPlan = null; // 'basic', 'pro', 'premium'

function renderSubscription() {
  const u = currentUser;
  const planLabel = getUserPlanLabel(u);
  const isPrem = isPremium(u);
  const isPr = isPro(u) && !isPrem;
  const isBasic = u.isBasic && !isPr && !isPrem;
  const hasAnySub = u.isPro || u.isPremium || u.isBasic;

  if (hasAnySub && !selectedSubPlan) {
    const expiry = u.premiumExpiresAt ? new Date(u.premiumExpiresAt) :
                   u.proExpiresAt ? new Date(u.proExpiresAt) :
                   u.basicExpiresAt ? new Date(u.basicExpiresAt) : null;
    const expired = expiry && expiry < new Date();
    const daysLeft = expiry ? Math.ceil((expiry - new Date()) / 86400000) : null;
    const gradients = { Premium:'linear-gradient(135deg,#1a0550,#4c1d95)', Pro:'linear-gradient(135deg,#0A2540,#1352DE)', Basic:'linear-gradient(135deg,#1a1a2e,#16213e)', Free:'linear-gradient(135deg,#374151,#1f2937)' };
    const icons = { Premium:'💎', Pro:'👑', Basic:'⚡', Free:'🆓' };
    return `<div style="padding:24px 20px;max-width:520px;margin:0 auto;">
    ${backBtn()}
    <h2 style="font-size:22px;font-weight:800;color:var(--text);margin-bottom:24px;">My Subscription</h2>
    <div style="background:${gradients[planLabel]};border-radius:24px;padding:28px;margin-bottom:24px;text-align:center;">
      <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);border-radius:20px;padding:6px 18px;margin-bottom:16px;">
        <span style="font-size:16px;">${icons[planLabel]}</span>
        <span style="font-weight:800;font-size:13px;color:#fff;letter-spacing:.5px;">${planLabel.toUpperCase()} MEMBER</span>
      </div>
      <h3 style="color:#fff;font-size:20px;font-weight:800;margin-bottom:6px;">${u.firstName} ${u.lastName}</h3>
      <p style="color:rgba(255,255,255,.65);font-size:14px;margin-bottom:16px;">${isPrem ? 'Crypto + All features unlocked' : isPr ? 'All banking features unlocked' : '2-week starter access'}</p>
      ${expiry ? `<div style="background:rgba(255,255,255,.1);border-radius:14px;padding:14px;">
        <p style="color:rgba(255,255,255,.7);font-size:12px;font-weight:600;margin-bottom:4px;">SUBSCRIPTION EXPIRES</p>
        <p style="color:#fff;font-size:16px;font-weight:700;">${expiry.toLocaleDateString('en-US',{day:'numeric',month:'long',year:'numeric'})}</p>
        ${expired ? `<p style="color:#f87171;font-size:12px;font-weight:700;margin-top:6px;">⚠️ Expired — renew below</p>` : `<p style="color:#4ade80;font-size:12px;font-weight:700;margin-top:6px;">✅ ${daysLeft} day${daysLeft!==1?'s':''} remaining</p>`}
      </div>` : ''}
    </div>
    <div class="card" style="margin-bottom:20px;">
      <h3 style="font-weight:700;color:var(--text);font-size:16px;margin-bottom:16px;">${planLabel} Features</h3>
      ${(isPrem ? [['💎','Crypto Market','Buy BTC, ETH & top 10 coins'],['🔐','Crypto Wallet','Personal wallet generated for you'],['🌍','International Transfers','Send globally with no cap'],['💳','Add Existing Cards','Link your real cards'],['📤','Withdrawals','Transfer out anytime'],['💰','Unlimited Deposits','No cap on amounts']] :
         isPr ? [['👑','Unlimited Deposits','No cap on deposits'],['📤','Withdrawals','Transfer out anytime'],['💳','Add Existing Cards','Link your real cards']] :
         [['⚡','Unlimited Deposits','No cap on deposits'],['📤','Withdrawals','Transfer out anytime']]).map(([icon,t,d])=>`
        <div style="display:flex;align-items:center;gap:14px;padding:12px 0;border-bottom:1px solid var(--border);">
          <span style="font-size:22px;">${icon}</span>
          <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">${t}</p><p style="color:var(--text3);font-size:12px;">${d}</p></div>
          <span style="color:#00C48C;font-size:18px;">✓</span>
        </div>`).join('')}
    </div>
    ${expired || (daysLeft !== null && daysLeft <= 3) ? `<button onclick="selectedSubPlan=null;goScreen('subscription')" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#FFD700,#FFA500);color:#7B3F00;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-bottom:12px;">🔄 Renew / Upgrade Subscription</button>` : ''}
    <button onclick="openActivationCodeModal()" style="width:100%;padding:13px;border:1.5px solid var(--border);border-radius:14px;background:var(--bg3);color:var(--text);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;">🔐 Enter Activation Code</button>
  </div>`;
  }

  // Plan selection view
  if (!selectedSubPlan) {
    return `<div style="padding:24px 20px;max-width:520px;margin:0 auto;">
    <div style="background:linear-gradient(135deg,#5C0F0F 0%,#8B1A1A 60%,#C9973A 100%);border-radius:24px;padding:32px 24px;margin-bottom:28px;text-align:center;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-40px;right:-40px;width:160px;height:160px;border-radius:50%;background:rgba(255,215,0,.07);"></div>
      <p style="color:rgba(255,255,255,.7);font-size:12px;font-weight:700;letter-spacing:2px;text-transform:uppercase;margin-bottom:10px;">Choose Your Plan</p>
      <h2 style="color:#fff;font-size:24px;font-weight:800;line-height:1.2;margin-bottom:8px;">Unlock DrimBank</h2>
      <p style="color:rgba(255,255,255,.6);font-size:14px;">Select a plan that works for you</p>
    </div>

    <div style="display:flex;flex-direction:column;gap:14px;margin-bottom:28px;">

      <!-- Basic Plan -->
      <div onclick="selectSubPlan('basic')" id="plan-basic" style="border:2px solid var(--border);border-radius:20px;padding:20px;cursor:pointer;transition:all .2s;position:relative;background:var(--card-bg);">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(100,116,139,.15);display:flex;align-items:center;justify-content:center;font-size:22px;">⚡</div>
            <div>
              <div style="display:flex;align-items:center;gap:8px;"><p style="font-weight:800;color:var(--text);font-size:16px;">Basic</p><span style="font-size:10px;font-weight:700;background:#e2e8f0;color:#475569;padding:2px 8px;border-radius:8px;">2 WEEKS</span></div>
              <p style="color:var(--text3);font-size:12px;">Starter banking access</p>
            </div>
          </div>
          <div style="text-align:right;"><p style="font-size:22px;font-weight:800;color:var(--text);">₦1,000</p><p style="font-size:11px;color:var(--text3);">14 days</p></div>
        </div>
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);display:flex;flex-wrap:wrap;gap:6px;">
          ${['Unlimited Deposits','Withdrawals'].map(f=>`<span style="font-size:11px;font-weight:600;background:rgba(100,116,139,.1);color:var(--text2);padding:3px 10px;border-radius:20px;">${f}</span>`).join('')}
        </div>
        <div id="plan-basic-check" style="display:none;position:absolute;top:14px;right:14px;width:22px;height:22px;border-radius:50%;background:#1352DE;align-items:center;justify-content:center;color:#fff;font-size:13px;">✓</div>
      </div>

      <!-- Pro Plan -->
      <div onclick="selectSubPlan('pro')" id="plan-pro" style="border:2px solid var(--border);border-radius:20px;padding:20px;cursor:pointer;transition:all .2s;position:relative;background:var(--card-bg);">
        <div style="position:absolute;top:-1px;right:16px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-size:10px;font-weight:800;padding:3px 12px;border-radius:0 0 10px 10px;letter-spacing:.5px;">POPULAR</div>
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(19,82,222,.12);display:flex;align-items:center;justify-content:center;font-size:22px;">👑</div>
            <div>
              <div style="display:flex;align-items:center;gap:8px;"><p style="font-weight:800;color:var(--text);font-size:16px;">Pro</p><span style="font-size:10px;font-weight:700;background:rgba(19,82,222,.1);color:#1352DE;padding:2px 8px;border-radius:8px;">1 MONTH</span></div>
              <p style="color:var(--text3);font-size:12px;">Full banking access</p>
            </div>
          </div>
          <div style="text-align:right;"><p style="font-size:22px;font-weight:800;color:var(--text);">₦2,000</p><p style="font-size:11px;color:var(--text3);">30 days</p></div>
        </div>
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);display:flex;flex-wrap:wrap;gap:6px;">
          ${['Unlimited Deposits','Withdrawals','Add Existing Cards'].map(f=>`<span style="font-size:11px;font-weight:600;background:rgba(19,82,222,.08);color:#1352DE;padding:3px 10px;border-radius:20px;">${f}</span>`).join('')}
        </div>
        <div id="plan-pro-check" style="display:none;position:absolute;top:14px;right:14px;width:22px;height:22px;border-radius:50%;background:#1352DE;align-items:center;justify-content:center;color:#fff;font-size:13px;">✓</div>
      </div>

      <!-- Premium Plan -->
      <div onclick="selectSubPlan('premium')" id="plan-premium" style="border:2px solid var(--border);border-radius:20px;padding:20px;cursor:pointer;transition:all .2s;position:relative;background:var(--card-bg);">
        <div style="position:absolute;top:-1px;right:16px;background:linear-gradient(135deg,#7c3aed,#4c1d95);color:#fff;font-size:10px;font-weight:800;padding:3px 12px;border-radius:0 0 10px 10px;letter-spacing:.5px;">CRYPTO + ALL</div>
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div style="display:flex;align-items:center;gap:10px;">
            <div style="width:44px;height:44px;border-radius:12px;background:rgba(124,58,237,.12);display:flex;align-items:center;justify-content:center;font-size:22px;">💎</div>
            <div>
              <div style="display:flex;align-items:center;gap:8px;"><p style="font-weight:800;color:var(--text);font-size:16px;">Premium</p><span style="font-size:10px;font-weight:700;background:rgba(124,58,237,.1);color:#7c3aed;padding:2px 8px;border-radius:8px;">1 MONTH</span></div>
              <p style="color:var(--text3);font-size:12px;">Banking + Crypto market access</p>
            </div>
          </div>
          <div style="text-align:right;"><p style="font-size:22px;font-weight:800;color:var(--text);">₦2,500</p><p style="font-size:11px;color:var(--text3);">30 days</p></div>
        </div>
        <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border);display:flex;flex-wrap:wrap;gap:6px;">
          ${['Everything in Pro','Crypto Market','Personal Wallet','Int\'l Transfers'].map(f=>`<span style="font-size:11px;font-weight:600;background:rgba(124,58,237,.08);color:#7c3aed;padding:3px 10px;border-radius:20px;">${f}</span>`).join('')}
        </div>
        <div id="plan-premium-check" style="display:none;position:absolute;top:14px;right:14px;width:22px;height:22px;border-radius:50%;background:#7c3aed;align-items:center;justify-content:center;color:#fff;font-size:13px;">✓</div>
      </div>
    </div>

    <button onclick="proceedToPayment()" id="sub-proceed-btn" disabled style="width:100%;padding:16px;border:none;border-radius:16px;background:#CBD5E1;color:#64748B;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;cursor:not-allowed;transition:all .2s;margin-bottom:12px;">Select a Plan to Continue</button>
    <button onclick="openActivationCodeModal()" style="width:100%;padding:13px;border:1.5px solid var(--border);border-radius:14px;background:var(--bg3);color:var(--text);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;">🔐 I have an activation code</button>
  </div>`;
  }

  // Payment details view
  const planConfigs = {
    basic: { label:'Basic', amount:'₦1,000', days:14, whatsapp:'https://wa.link/x7mrgd', color:'#475569', bg:'rgba(100,116,139,.08)', iconSvg:'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>' },
    pro: { label:'Pro', amount:'₦2,000', days:30, whatsapp:'https://wa.link/xcdcc9', color:'#1352DE', bg:'rgba(19,82,222,.08)', iconSvg:'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>' },
    premium: { label:'Premium', amount:'₦2,500', days:30, whatsapp:'https://wa.link/v2w04m', color:'#7c3aed', bg:'rgba(124,58,237,.08)', iconSvg:'<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/><circle cx="12" cy="12" r="3" fill="currentColor" stroke="none"/></svg>' },
  };
  const cfg = planConfigs[selectedSubPlan] || planConfigs.pro;

  function copyAcct(num, btnId) {
    navigator.clipboard?.writeText(num).then(()=>{
      const b = document.getElementById(btnId);
      if(b){ const orig=b.textContent; b.textContent='Copied!'; setTimeout(()=>b.textContent=orig,1800); }
    });
  }

  return `<div style="padding:24px 20px;max-width:520px;margin:0 auto;">
    <button onclick="selectedSubPlan=null;goScreen('subscription')" style="background:none;border:none;color:var(--blue);cursor:pointer;font-family:'Sora',sans-serif;font-size:14px;font-weight:600;margin-bottom:20px;display:flex;align-items:center;gap:6px;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
      Back to Plans
    </button>

    <h2 style="font-size:24px;font-weight:800;color:var(--text);letter-spacing:-.5px;margin-bottom:4px;">Complete Payment</h2>
    <p style="color:var(--text3);font-size:14px;margin-bottom:24px;">${cfg.label} Plan &nbsp;·&nbsp; ${cfg.amount}</p>

    <!-- Plan summary card -->
    <div style="background:linear-gradient(135deg,#0A2540 0%,#1352DE 100%);border-radius:20px;padding:20px 22px;margin-bottom:20px;display:flex;align-items:center;gap:16px;">
      <div style="width:50px;height:50px;border-radius:14px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0;">${cfg.iconSvg}</div>
      <div style="flex:1;">
        <p style="color:rgba(255,255,255,.7);font-size:12px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;margin-bottom:2px;">DrimBank ${cfg.label}</p>
        <p style="color:#fff;font-size:13px;">${cfg.days} days · ${selectedSubPlan === 'premium' ? 'All banking + Crypto & Wallet' : selectedSubPlan === 'pro' ? 'Full banking access' : '2-week starter access'}</p>
      </div>
      <div style="text-align:right;">
        <p style="font-size:24px;font-weight:800;color:#fff;letter-spacing:-.5px;">${cfg.amount}</p>
        <p style="font-size:11px;color:rgba(255,255,255,.6);">${cfg.days} days</p>
      </div>
    </div>

    <!-- Account 1: OPay -->
    <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:20px;overflow:hidden;margin-bottom:12px;">
      <div style="padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;">
        <div style="width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,#1352DE,#2D6BE4);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
        </div>
        <span style="font-weight:700;color:var(--text);font-size:15px;">Option 1 &nbsp;—&nbsp; OPay Account</span>
      </div>
      <div style="padding:16px 18px;display:flex;flex-direction:column;gap:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Bank</span>
          <span style="font-size:13px;font-weight:700;color:var(--text);">OPay</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Account Name</span>
          <span style="font-size:13px;font-weight:700;color:var(--text);text-align:right;">OLAYEMI OLAWALE<br>OSANYINLUSI</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Account Number</span>
          <div style="display:flex;align-items:center;gap:8px;">
            <span style="font-size:14px;font-weight:800;color:var(--text);font-family:'DM Mono',monospace;letter-spacing:.5px;">8109893166</span>
            <button id="copy-opay-btn" onclick="navigator.clipboard?.writeText('8109893166').then(()=>{const b=document.getElementById('copy-opay-btn');if(b){const o=b.textContent;b.textContent='Copied!';b.style.background='#00C48C';setTimeout(()=>{b.textContent=o;b.style.background='';},1800)}})" style="padding:5px 12px;border-radius:8px;border:none;background:var(--blue);color:#fff;font-family:'Sora',sans-serif;font-size:11px;font-weight:700;cursor:pointer;transition:all .2s;">Copy</button>
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;padding-top:10px;border-top:1px solid var(--border);">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Amount</span>
          <span style="font-size:16px;font-weight:800;color:#1352DE;">${cfg.amount}</span>
        </div>
      </div>
    </div>

    <!-- Divider -->
    <div style="display:flex;align-items:center;gap:12px;margin:4px 0 12px;">
      <div style="flex:1;height:1px;background:var(--border);"></div>
      <span style="font-size:12px;font-weight:700;color:var(--text3);letter-spacing:1px;">OR</span>
      <div style="flex:1;height:1px;background:var(--border);"></div>
    </div>

    <!-- Account 2: Moniepoint -->
    <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:20px;overflow:hidden;margin-bottom:16px;">
      <div style="padding:14px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;">
        <div style="width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,#F59E0B,#D97706);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
        </div>
        <span style="font-weight:700;color:var(--text);font-size:15px;">Option 2 &nbsp;—&nbsp; Moniepoint MFB</span>
      </div>
      <div style="padding:16px 18px;display:flex;flex-direction:column;gap:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Bank</span>
          <span style="font-size:13px;font-weight:700;color:var(--text);">Moniepoint MFB</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Account Name</span>
          <span style="font-size:13px;font-weight:700;color:var(--text);text-align:right;">NBA WORLD / OSANYINLUSI<br>OLAYEMI</span>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Account Number</span>
          <div style="display:flex;align-items:center;gap:8px;">
            <span style="font-size:14px;font-weight:800;color:var(--text);font-family:'DM Mono',monospace;letter-spacing:.5px;">6383909463</span>
            <button id="copy-monie-btn" onclick="navigator.clipboard?.writeText('6383909463').then(()=>{const b=document.getElementById('copy-monie-btn');if(b){const o=b.textContent;b.textContent='Copied!';b.style.background='#00C48C';setTimeout(()=>{b.textContent=o;b.style.background='';},1800)}})" style="padding:5px 12px;border-radius:8px;border:none;background:#F59E0B;color:#fff;font-family:'Sora',sans-serif;font-size:11px;font-weight:700;cursor:pointer;transition:all .2s;">Copy</button>
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:center;padding-top:10px;border-top:1px solid var(--border);">
          <span style="font-size:13px;color:var(--text3);font-weight:500;">Amount</span>
          <span style="font-size:16px;font-weight:800;color:#F59E0B;">${cfg.amount}</span>
        </div>
      </div>
      <!-- Important notice -->
      <div style="padding:12px 18px;background:rgba(245,158,11,.08);border-top:1px solid rgba(245,158,11,.2);display:flex;align-items:flex-start;gap:10px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;margin-top:1px;"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
        <p style="font-size:12px;color:#D97706;font-weight:600;line-height:1.5;">Send the exact amount — ${cfg.amount}. Wrong amounts will delay activation.</p>
      </div>
    </div>

    <!-- Upload Receipt -->
    <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:20px;padding:20px;margin-bottom:20px;">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/></svg>
        <div>
          <p style="font-weight:700;color:var(--text);font-size:14px;">Upload Payment Receipt</p>
          <p style="font-size:12px;color:var(--text3);">After paying, upload your receipt screenshot</p>
        </div>
      </div>
      <!-- Hidden file input — lives outside the label so replacing preview doesn't kill it -->
      <input type="file" id="receipt-file-input" accept="image/*" style="display:none;" onchange="handleReceiptUpload(this)">
      <!-- Tap zone -->
      <div id="receipt-upload-zone" onclick="document.getElementById('receipt-file-input').click()"
        style="border:2px dashed var(--border);border-radius:14px;padding:24px 16px;text-align:center;cursor:pointer;transition:border .2s;"
        onmouseover="this.style.borderColor='var(--blue)'" onmouseout="this.style.borderColor=''">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" style="margin:0 auto 10px;display:block;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
        <p style="font-weight:600;color:var(--text2);font-size:13px;margin-bottom:4px;">Tap to upload receipt</p>
        <p style="font-size:11px;color:var(--text3);">PNG, JPG or screenshot accepted</p>
      </div>
      <!-- Preview area (hidden until image loaded) -->
      <div id="receipt-preview-wrap" style="display:none;margin-top:12px;text-align:center;position:relative;">
        <img id="receipt-preview-img" src="" style="max-width:100%;border-radius:12px;max-height:180px;object-fit:contain;">
        <button onclick="clearReceiptUpload()" style="position:absolute;top:6px;right:6px;background:rgba(239,68,68,.85);border:none;border-radius:50%;width:26px;height:26px;color:#fff;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;">✕</button>
        <p style="font-size:11px;color:#00A677;font-weight:600;margin-top:6px;">✅ Receipt ready to send</p>
      </div>
    </div>

    <!-- Activate My Account button with professional SVG icon -->
    <button onclick="onActivateSubClick()" style="width:100%;padding:17px;border:none;border-radius:16px;background:linear-gradient(135deg,#0A2540,#1352DE);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:12px;margin-bottom:12px;box-shadow:0 6px 24px rgba(19,82,222,.35);transition:opacity .2s;" onmouseover="this.style.opacity='.88'" onmouseout="this.style.opacity='1'">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        <polyline points="9 12 11 14 15 10"/>
      </svg>
      Activate My Account
    </button>
    <p style="text-align:center;font-size:12px;color:var(--text3);line-height:1.65;margin-bottom:20px;">After sending payment, contact admin with your receipt to receive a unique activation code.</p>
    <div style="text-align:center;">
      <button onclick="openActivationCodeModal()" style="background:none;border:none;color:var(--blue);cursor:pointer;font-family:'Sora',sans-serif;font-size:14px;font-weight:600;">Already have a code? Activate now →</button>
    </div>
  </div>`;
}

function selectSubPlan(plan) {
  selectedSubPlan = plan;
  const colors = { basic:'#475569', pro:'#1352DE', premium:'#7c3aed' };
  ['basic','pro','premium'].forEach(p => {
    const card = document.getElementById('plan-'+p);
    const check = document.getElementById('plan-'+p+'-check');
    if (card) {
      card.style.borderColor = p === plan ? (colors[p]||'#1352DE') : 'var(--border)';
      card.style.background = p === plan ? (colors[p]||'#1352DE')+'11' : 'var(--card-bg)';
    }
    if (check) check.style.display = p === plan ? 'flex' : 'none';
  });
  const btn = document.getElementById('sub-proceed-btn');
  if (btn) {
    btn.disabled = false;
    const labels = { basic:'Continue with Basic — ₦1,000', pro:'Continue with Pro — ₦2,000', premium:'Continue with Premium — ₦2,500' };
    const bgs = { basic:'linear-gradient(135deg,#475569,#334155)', pro:'linear-gradient(135deg,#1352DE,#2D6BE4)', premium:'linear-gradient(135deg,#7c3aed,#4c1d95)' };
    btn.style.background = bgs[plan] || bgs.pro;
    btn.style.color = '#fff';
    btn.style.cursor = 'pointer';
    btn.textContent = labels[plan] || 'Continue';
  }
}

function proceedToPayment() {
  if (!selectedSubPlan) { addToast('Please select a plan first', 'error'); return; }
  goScreen('subscription');
}

function onActivateSubClick() {
  const links = { basic:'https://wa.link/x7mrgd', pro:'https://wa.link/xcdcc9', premium:'https://wa.link/v2w04m' };
  const baseLink = links[selectedSubPlan] || links.pro;
  const planLabels = { basic:'Basic ₦1,000', pro:'Pro ₦2,000', premium:'Premium ₦2,500' };
  const planName = planLabels[selectedSubPlan] || 'Pro';
  const hasReceipt = !!(window._receiptDataUrl);
  const userName = currentUser ? `${currentUser.firstName} ${currentUser.lastName}` : '';
  const acctNum = currentUser ? currentUser.accountNumber : '';

  // Build a pre-filled WhatsApp message with user details
  const msg = `Hello, I just made payment for DrimBank ${planName} plan.\n\nName: ${userName}\nAccount: ${acctNum}\n\n${hasReceipt ? 'I have attached my payment receipt to this message.' : 'Please confirm my payment and send my activation code.'}`;
  const encoded = encodeURIComponent(msg);

  // Determine WhatsApp link (strip /join if present, then add text param)
  // wa.link shortlinks can't take params, so we use wa.me instead for admin DM
  // Admin WhatsApp numbers embedded from the original links
  const adminNumbers = { basic:'2349030000000', pro:'2349030000000', premium:'2349030000000' };
  // Try to extract from original wa.link — fallback: open link directly then prompt
  // Since we cannot resolve wa.link server-side, we open the direct link and show a tip
  if (hasReceipt) {
    // Show a modal instructing user to attach receipt in WhatsApp
    document.getElementById('receipt-send-modal')?.remove();
    const modal = document.createElement('div');
    modal.id = 'receipt-send-modal';
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(10px);z-index:5000;display:flex;align-items:flex-end;justify-content:center;padding:0;animation:fadeUp .2s ease;';
    modal.innerHTML = `
    <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:28px 28px 0 0;padding:28px 22px 48px;width:100%;max-width:540px;font-family:'Plus Jakarta Sans',sans-serif;">
      <div style="width:40px;height:4px;background:var(--border);border-radius:4px;margin:0 auto 20px;"></div>
      <div style="text-align:center;margin-bottom:20px;">
        <div style="width:64px;height:64px;border-radius:20px;background:linear-gradient(135deg,#00C48C,#009e72);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.36 12a19.79 19.79 0 0 1-3-8.59A2 2 0 0 1 3.32 1.2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L7.91 8.96a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>
        </div>
        <h3 style="font-size:19px;font-weight:800;color:var(--text);margin-bottom:6px;">Send Receipt to Admin</h3>
        <p style="font-size:13px;color:var(--text2);line-height:1.6;">Your receipt is ready. Here's how to send it:</p>
      </div>
      <!-- Steps -->
      <div style="background:var(--bg3,#F1F5F9);border-radius:16px;padding:16px;margin-bottom:20px;">
        <div style="display:flex;gap:12px;align-items:flex-start;padding-bottom:12px;border-bottom:1px solid var(--border);">
          <div style="width:28px;height:28px;border-radius:50%;background:#00C48C;color:#fff;font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;">1</div>
          <p style="font-size:13px;color:var(--text);font-weight:600;">Tap <strong>"Open WhatsApp"</strong> below — a pre-filled message opens in admin's DM</p>
        </div>
        <div style="display:flex;gap:12px;align-items:flex-start;padding:12px 0 12px;border-bottom:1px solid var(--border);">
          <div style="width:28px;height:28px;border-radius:50%;background:#00C48C;color:#fff;font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;">2</div>
          <p style="font-size:13px;color:var(--text);font-weight:600;">Tap the <strong>📎 attachment</strong> icon in WhatsApp and select your receipt from your gallery</p>
        </div>
        <div style="display:flex;gap:12px;align-items:flex-start;padding-top:12px;">
          <div style="width:28px;height:28px;border-radius:50%;background:#00C48C;color:#fff;font-size:13px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0;">3</div>
          <p style="font-size:13px;color:var(--text);font-weight:600;">Send the message — admin will verify and reply with your <strong>activation code</strong></p>
        </div>
      </div>
      <!-- Save receipt tip -->
      <div style="background:rgba(19,82,222,.07);border:1px solid rgba(19,82,222,.2);border-radius:12px;padding:12px 14px;margin-bottom:20px;display:flex;gap:10px;align-items:center;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1352DE" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
        <p style="font-size:12px;color:#1352DE;font-weight:600;">Your receipt screenshot is saved in your phone's gallery — attach it directly in WhatsApp</p>
      </div>
      <button onclick="window.open('${baseLink}','_blank');document.getElementById('receipt-send-modal')?.remove();" style="width:100%;padding:16px;border:none;border-radius:16px;background:linear-gradient(135deg,#25D366,#1ebe57);color:#fff;font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;margin-bottom:10px;box-shadow:0 6px 24px rgba(37,211,102,.3);">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413z"/></svg>
        Open WhatsApp → Admin DM
      </button>
      <button onclick="document.getElementById('receipt-send-modal')?.remove()" style="width:100%;padding:13px;border:1.5px solid var(--border);background:none;border-radius:14px;color:var(--text2);font-family:'Plus Jakarta Sans',sans-serif;font-weight:700;font-size:14px;cursor:pointer;">Cancel</button>
    </div>`;
    modal.addEventListener('click', e => { if(e.target === modal) modal.remove(); });
    document.body.appendChild(modal);
  } else {
    // No receipt — just open WhatsApp directly
    window.open(baseLink, '_blank');
  }
}

function handleReceiptUpload(input) {
  const f = input.files && input.files[0];
  if (!f) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    window._receiptDataUrl = e.target.result;
    const zone = document.getElementById('receipt-upload-zone');
    const preview = document.getElementById('receipt-preview-wrap');
    const img = document.getElementById('receipt-preview-img');
    if (zone) zone.style.display = 'none';
    if (img) img.src = e.target.result;
    if (preview) preview.style.display = 'block';
  };
  reader.readAsDataURL(f);
}

function clearReceiptUpload() {
  window._receiptDataUrl = null;
  const zone = document.getElementById('receipt-upload-zone');
  const preview = document.getElementById('receipt-preview-wrap');
  const input = document.getElementById('receipt-file-input');
  if (zone) zone.style.display = 'block';
  if (preview) preview.style.display = 'none';
  if (input) input.value = '';
}

// ─── Crypto Market ─────────────────────────────────────────────────────────────
const COINS = [
  {id:'bitcoin',symbol:'BTC',name:'Bitcoin',color:'#F7931A',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#F7931A"/><path d="M22.6 14.2c.3-2-1.2-3.1-3.3-3.8l.7-2.7-1.7-.4-.7 2.6-1.3-.3.7-2.7-1.7-.4-.7 2.7-1.1-.3-2.3-.6-.4 1.8s1.2.3 1.2.3c.7.2.8.6.8.9l-2 7.8c-.1.2-.3.5-.7.4 0 0-1.2-.3-1.2-.3l-.8 2 2.2.6 1.2.3-.7 2.8 1.7.4.7-2.8 1.3.3-.7 2.8 1.7.4.7-2.8c2.9.5 5.1.3 6-2.3.7-2-.03-3.2-1.5-3.9 1.1-.2 1.9-1 2.1-2.6zm-3.8 5.3c-.5 2-3.9 1-5 .7l.9-3.6c1.1.3 4.6.8 4.1 2.9zm.5-5.4c-.5 1.8-3.3 1-4.2.7l.8-3.2c.9.2 3.9.7 3.4 2.5z" fill="white"/></svg>`},
  {id:'ethereum',symbol:'ETH',name:'Ethereum',color:'#627EEA',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#627EEA"/><path d="M16 5l-6.5 11.5 6.5 3.7 6.5-3.7L16 5z" fill="white" opacity=".8"/><path d="M9.5 16.5L16 20.2l6.5-3.7-6.5 3.7-6.5-3.7z" fill="white" opacity=".6"/><path d="M16 21.5l-6.5-3.7L16 27l6.5-8.2-6.5 3.7z" fill="white"/></svg>`},
  {id:'binancecoin',symbol:'BNB',name:'BNB',color:'#F3BA2F',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#F3BA2F"/><path d="M12.2 16l-2.2-2.2-2.2 2.2 2.2 2.2L12.2 16zm3.8-3.8l3.8 3.8-3.8 3.8-3.8-3.8L16 12.2zm6 1.6l-2.2 2.2 2.2 2.2 2.2-2.2-2.2-2.2zM16 7.8l-2.2 2.2 2.2 2.2 2.2-2.2L16 7.8zm0 12l-2.2 2.2 2.2 2.2 2.2-2.2-2.2-2.2z" fill="white"/></svg>`},
  {id:'ripple',symbol:'XRP',name:'XRP',color:'#00AAE4',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#00AAE4"/><path d="M21.5 9h2.5l-5.5 5.5c-1.4 1.4-3.6 1.4-5 0L8 9h2.5l4.3 4.3c.7.7 1.7.7 2.4 0L21.5 9zm-11.4 14H7.6l5.5-5.5c1.4-1.4 3.6-1.4 5 0l5.5 5.5h-2.5l-4.3-4.3c-.7-.7-1.7-.7-2.4 0L10.1 23z" fill="white"/></svg>`},
  {id:'solana',symbol:'SOL',name:'Solana',color:'#9945FF',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#9945FF"/><path d="M10 20.5h14l-3 2.5H7l3-2.5zm0-5.5h14l-3 2.5H7l3-2.5zm11-6h-14l3-2.5h14l-3 2.5z" fill="white"/></svg>`},
  {id:'dogecoin',symbol:'DOGE',name:'Dogecoin',color:'#C2A633',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#C2A633"/><text x="16" y="21" text-anchor="middle" font-size="14" font-weight="bold" fill="white">Ð</text></svg>`},
  {id:'cardano',symbol:'ADA',name:'Cardano',color:'#0D6EFD',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#0D6EFD"/><text x="16" y="21" text-anchor="middle" font-size="14" font-weight="bold" fill="white">₳</text></svg>`},
  {id:'the-open-network',symbol:'TON',name:'TON',color:'#0098EA',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#0098EA"/><path d="M9 11h14l-7 11-7-11zm3.5 0l3.5 5.5L20.5 11h-8z" fill="white"/></svg>`},
  {id:'avalanche-2',symbol:'AVAX',name:'Avalanche',color:'#E84142',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#E84142"/><path d="M11.5 22h-3l7.5-13 7.5 13h-3l-4.5-8-4.5 8zm4.5-3h-2l1-2 1 2z" fill="white"/></svg>`},
  {id:'tron',symbol:'TRX',name:'TRON',color:'#EF0027',
    logo:`<svg viewBox="0 0 32 32" width="28" height="28"><circle cx="16" cy="16" r="16" fill="#EF0027"/><path d="M8 11l13 2-8 10-5-12zm5.5 1.5l2.5 6L20 13l-6.5-.5z" fill="white"/></svg>`},
];

let cryptoPrices = {};
let cryptoLastFetched = 0;
let cryptoTab = 'market'; // 'market' | 'wallets'
let cryptoFetchInProgress = false; // ← prevents re-render loop

// Sparkline SVG generator (random-ish but deterministic per coin+price)
function miniSparkline(coinId, change) {
  const up = change >= 0;
  const color = up ? '#00C48C' : '#EF4444';
  // Generate pseudo-random points seeded by coinId + approximate price bucket
  const seed = coinId.split('').reduce((a,c)=>a+c.charCodeAt(0),0);
  const points = [];
  let y = 20;
  for(let i = 0; i < 12; i++) {
    const noise = ((seed * (i+3) * 1009) % 17) - 8;
    y = Math.max(4, Math.min(36, y + noise));
    points.push([i * 7, y]);
  }
  // Tilt end toward direction of change
  if(up) points[points.length-1][1] = Math.min(points[points.length-1][1], 18);
  else points[points.length-1][1] = Math.max(points[points.length-1][1], 22);

  const pathD = points.map((p,i)=>`${i===0?'M':'L'}${p[0]},${p[1]}`).join(' ');
  const fillD = pathD + ` L${points[points.length-1][0]},40 L0,40 Z`;
  return `<svg width="72" height="40" viewBox="0 0 77 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs><linearGradient id="sg${coinId.slice(0,4)}" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="${color}" stop-opacity=".25"/><stop offset="100%" stop-color="${color}" stop-opacity="0"/></linearGradient></defs>
    <path d="${fillD}" fill="url(#sg${coinId.slice(0,4)})"/>
    <path d="${pathD}" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>`;
}

async function fetchCryptoPrices() {
  const now = Date.now();
  // Strong cache: 45s, and guard against concurrent fetches
  if (cryptoFetchInProgress) return;
  if (now - cryptoLastFetched < 45000 && Object.keys(cryptoPrices).length > 0) return;
  cryptoFetchInProgress = true;
  try {
    const ids = COINS.map(c=>c.id).join(',');
    const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_market_cap=true&include_24hr_vol=true`);
    if (!res.ok) return;
    cryptoPrices = await res.json();
    cryptoLastFetched = now;
  } catch(_) {}
  finally { cryptoFetchInProgress = false; }
}

// Refresh prices without causing a full re-render loop
async function refreshCryptoPricesOnly() {
  const now = Date.now();
  if (cryptoFetchInProgress) return;
  if (now - cryptoLastFetched < 45000 && Object.keys(cryptoPrices).length > 0) return;
  cryptoFetchInProgress = true;
  try {
    const ids = COINS.map(c=>c.id).join(',');
    const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${ids}&vs_currencies=usd&include_24hr_change=true&include_market_cap=true`);
    if (!res.ok) return;
    cryptoPrices = await res.json();
    cryptoLastFetched = now;
    // Only re-render if still on crypto screen; this is intentional user refresh
    if (currentAppScreen === 'crypto') renderCryptoInPlace();
  } catch(_) {}
  finally { cryptoFetchInProgress = false; }
}

// Re-render only the prices section without a full screen reload (avoids freeze)
function renderCryptoInPlace() {
  const el = document.getElementById('crypto-prices-list');
  if (!el) return;
  el.innerHTML = buildCryptoPriceRows();
  const walletEl = document.getElementById('crypto-wallet-holdings');
  if (walletEl) walletEl.innerHTML = buildWalletHoldings();
  const tsEl = document.getElementById('crypto-live-ts');
  if (tsEl) tsEl.textContent = 'Live · ' + new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
}

function buildCryptoPriceRows() {
  return COINS.map(coin => {
    const data = cryptoPrices[coin.id];
    const price = data?.usd;
    const change = data?.usd_24h_change;
    const up = change >= 0;
    const fmtPrice = price ? (price >= 1 ? '$'+price.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : '$'+price.toFixed(6)) : '—';
    const sparkline = (change !== undefined) ? miniSparkline(coin.id, change) : '';
    return `<div onclick="openBuyModal('${coin.id}')" style="display:flex;align-items:center;gap:12px;padding:13px 16px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06);transition:background .15s;" onmouseover="this.style.background='rgba(255,255,255,.04)'" onmouseout="this.style.background=''">
      <div style="width:44px;height:44px;border-radius:50%;overflow:hidden;flex-shrink:0;display:flex;align-items:center;justify-content:center;">${coin.logo}</div>
      <div style="flex:1;min-width:0;">
        <p style="font-weight:700;color:#fff;font-size:15px;line-height:1.2;">${coin.name}</p>
        <p style="color:rgba(255,255,255,.45);font-size:12px;font-weight:500;margin-top:2px;">${coin.symbol}</p>
      </div>
      <div style="flex-shrink:0;">${sparkline}</div>
      <div style="text-align:right;flex-shrink:0;min-width:80px;">
        <p style="font-weight:700;color:#fff;font-size:15px;">${fmtPrice}</p>
        ${change !== undefined ? `<p style="font-size:12px;font-weight:600;color:${up?'#00C48C':'#EF4444'};margin-top:2px;">${up?'+':''}${change.toFixed(2)}%</p>` : '<p style="font-size:12px;color:rgba(255,255,255,.3);margin-top:2px;">–</p>'}
      </div>
    </div>`;
  }).join('');
}

function getCryptoWallet(user) {
  return user.cryptoWallet || null;
}

function copyWalletAddress(addr) {
  navigator.clipboard.writeText(addr).then(() => {
    addToast('📋 Address copied!', 'success');
  }).catch(() => {
    // fallback for older browsers
    const ta = document.createElement('textarea');
    ta.value = addr; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    addToast('📋 Address copied!', 'success');
  });
}

function generateCryptoWallet() {
  // Use admin-assigned addresses if available; otherwise leave blank (pending admin setup)
  const adminBTC  = currentUser.adminBtcAddress  || '';
  const adminETH  = currentUser.adminEthAddress  || '';
  const adminUSDT = currentUser.adminUsdtAddress || '';
  const adminBNB  = currentUser.adminBnbAddress  || '';
  const adminSOL  = currentUser.adminSolAddress  || '';
  return {
    address:     adminETH,   // primary EVM address (ETH/USDT/BNB share same if set)
    btcAddress:  adminBTC,
    ethAddress:  adminETH,
    usdtAddress: adminUSDT,
    bnbAddress:  adminBNB,
    solAddress:  adminSOL,
    createdAt: new Date().toISOString(),
    holdings: {}
  };
}

async function createCryptoWallet() {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  if (currentUser.cryptoWallet) { addToast('You already have a wallet!', 'info'); return; }

  // Show loading on the button while we fetch fresh data
  const btn = document.querySelector('[onclick="createCryptoWallet()"]');
  if (btn) { btn.disabled = true; btn.textContent = '⏳ Checking...'; }

  // Pull fresh data from cloud so admin-set addresses are always current
  await loadUsers();

  // Re-sync currentUser from freshly loaded users array
  const freshUser = users.find(u => u.id === currentUser.id);
  if (freshUser) currentUser = freshUser;

  // Restore button
  if (btn) { btn.disabled = false; btn.innerHTML = '🔐 Create My Wallet'; }

  // Guard: user may have wallet now after cloud refresh
  if (currentUser.cryptoWallet) { addToast('Wallet already active!', 'info'); goScreen('crypto'); return; }

  // Check whether admin has assigned at least one real address
  const hasAdminAddr = currentUser.adminBtcAddress || currentUser.adminEthAddress ||
                       currentUser.adminUsdtAddress || currentUser.adminBnbAddress ||
                       currentUser.adminSolAddress;

  if (!hasAdminAddr) {
    showWalletPendingNotice();
    return;
  }

  // Build wallet object from admin addresses and save to cloud
  const wallet = generateCryptoWallet();
  updateCurrentUser(u => ({...u, cryptoWallet: wallet}));
  addToast('🎉 Crypto wallet activated!', 'success');
  cryptoTab = 'wallets';
  goScreen('crypto');
}

// ─── Create Wallet Modal (wallet type chooser) ────────────────────────────────
function openCreateWalletModal() {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  if (currentUser.cryptoWallet) { addToast('You already have a wallet!', 'info'); return; }

  document.getElementById('create-wallet-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'create-wallet-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5,10,25,.75);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);z-index:4000;display:flex;align-items:flex-end;justify-content:center;animation:fadeUp .2s ease;';

  const walletTypes = [
    { id:'multi',  icon:'🌐', label:'Multi-Coin Wallet',   desc:'BTC + ETH + USDT + BNB + SOL',   recommended: true },
    { id:'btc',    icon:'₿',  label:'Bitcoin Wallet',       desc:'BTC only – max privacy',          recommended: false },
    { id:'eth',    icon:'⟠',  label:'Ethereum Wallet',      desc:'ETH + all ERC-20 tokens',         recommended: false },
    { id:'usdt',   icon:'₮',  label:'USDT Wallet',          desc:'Tether – TRC-20 & ERC-20',        recommended: false },
    { id:'sol',    icon:'◎',  label:'Solana Wallet',        desc:'SOL + SPL tokens',                recommended: false },
  ];

  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:linear-gradient(180deg,#0f1520 0%,#0a0e18 100%);border-radius:28px 28px 0 0;width:100%;max-width:540px;padding:28px 22px 48px;font-family:'DM Sans',sans-serif;border-top:1px solid rgba(255,255,255,.08);max-height:90vh;overflow-y:auto;">
    <div style="width:42px;height:4px;border-radius:4px;background:rgba(255,255,255,.15);margin:0 auto 26px;"></div>
    <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:#fff;font-size:20px;margin-bottom:6px;">Choose Wallet Type</h3>
    <p style="color:rgba(255,255,255,.45);font-size:13px;margin-bottom:24px;">Select the type of crypto wallet you want to create. Your address will be assigned to you.</p>
    <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:24px;" id="wallet-type-list">
      ${walletTypes.map(wt => `
        <button onclick="selectWalletType('${wt.id}')" id="wallet-type-btn-${wt.id}"
          style="width:100%;padding:16px;border:1.5px solid rgba(255,255,255,.1);border-radius:16px;background:rgba(255,255,255,.05);cursor:pointer;display:flex;align-items:center;gap:14px;text-align:left;transition:all .18s;position:relative;"
          onmouseover="this.style.borderColor='rgba(59,130,246,.5)';this.style.background='rgba(59,130,246,.08)'"
          onmouseout="this.style.borderColor='rgba(255,255,255,.1)';this.style.background='rgba(255,255,255,.05)'">
          <div style="width:46px;height:46px;border-radius:14px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;">${wt.icon}</div>
          <div style="flex:1;">
            <p style="font-family:'Sora',sans-serif;font-weight:700;color:#fff;font-size:14px;margin-bottom:3px;">${wt.label}</p>
            <p style="color:rgba(255,255,255,.4);font-size:12px;">${wt.desc}</p>
          </div>
          ${wt.recommended ? `<span style="background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:#fff;font-size:9px;font-weight:800;padding:3px 9px;border-radius:20px;font-family:'Sora',sans-serif;letter-spacing:.5px;flex-shrink:0;">POPULAR</span>` : ''}
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.3)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><polyline points="9 18 15 12 9 6"/></svg>
        </button>`).join('')}
    </div>
    <p style="font-size:11px;color:rgba(255,255,255,.22);text-align:center;line-height:1.7;">Your wallet address is generated and assigned by DrimBank.<br>Addresses are secured and verified by our team.</p>
    <button onclick="document.getElementById('create-wallet-modal').remove()" style="width:100%;padding:14px;border:none;background:none;color:rgba(255,255,255,.35);font-family:'DM Sans',sans-serif;font-weight:600;font-size:14px;cursor:pointer;margin-top:14px;">Cancel</button>
  </div>`;

  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function selectWalletType(typeId) {
  // Highlight the selected type briefly, then show confirmation step
  const btn = document.getElementById('wallet-type-btn-'+typeId);
  if (btn) {
    btn.style.borderColor = '#3b82f6';
    btn.style.background = 'rgba(59,130,246,.15)';
  }
  setTimeout(() => {
    document.getElementById('create-wallet-modal')?.remove();
    showWalletCreateConfirm(typeId);
  }, 280);
}

function showWalletCreateConfirm(typeId) {
  const typeLabels = {
    multi: { icon:'🌐', label:'Multi-Coin Wallet', desc:'BTC + ETH + USDT + BNB + SOL' },
    btc:   { icon:'₿',  label:'Bitcoin Wallet',    desc:'BTC only – max privacy' },
    eth:   { icon:'⟠',  label:'Ethereum Wallet',   desc:'ETH + all ERC-20 tokens' },
    usdt:  { icon:'₮',  label:'USDT Wallet',        desc:'Tether – TRC-20 & ERC-20' },
    sol:   { icon:'◎',  label:'Solana Wallet',      desc:'SOL + SPL tokens' },
  };
  const t = typeLabels[typeId] || typeLabels.multi;

  document.getElementById('wallet-confirm-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'wallet-confirm-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5,10,25,.8);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);z-index:4000;display:flex;align-items:flex-end;justify-content:center;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:linear-gradient(180deg,#0f1520 0%,#0a0e18 100%);border-radius:28px 28px 0 0;width:100%;max-width:540px;padding:28px 22px 48px;font-family:'DM Sans',sans-serif;border-top:1px solid rgba(255,255,255,.08);">
    <div style="width:42px;height:4px;border-radius:4px;background:rgba(255,255,255,.15);margin:0 auto 26px;"></div>
    <div style="text-align:center;margin-bottom:24px;">
      <div style="width:70px;height:70px;border-radius:22px;background:linear-gradient(135deg,rgba(29,78,216,.5),rgba(59,130,246,.35));border:1.5px solid rgba(99,155,255,.35);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:28px;box-shadow:0 8px 28px rgba(29,78,216,.3);">${t.icon}</div>
      <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:#fff;font-size:19px;margin-bottom:6px;">${t.label}</h3>
      <p style="color:rgba(255,255,255,.45);font-size:13px;">${t.desc}</p>
    </div>
    <button onclick="createCryptoWalletTyped('${typeId}')" id="confirm-create-wallet-btn"
      style="width:100%;padding:16px;border:none;border-radius:16px;background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;cursor:pointer;box-shadow:0 8px 24px rgba(29,78,216,.4);margin-bottom:12px;display:flex;align-items:center;justify-content:center;gap:10px;">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
      Create Wallet Address Now
    </button>
    <button onclick="document.getElementById('wallet-confirm-modal').remove()" style="width:100%;padding:14px;border:none;background:none;color:rgba(255,255,255,.35);font-family:'DM Sans',sans-serif;font-weight:600;font-size:14px;cursor:pointer;">Cancel</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

async function createCryptoWalletTyped(typeId) {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  if (currentUser.cryptoWallet) { addToast('You already have a wallet!', 'info'); return; }

  // Show a loading toast
  addToast('⏳ Setting up your wallet...', 'info');

  // Pull fresh data from cloud so admin-set addresses are always current
  await loadUsers();
  const freshUser = users.find(u => u.id === currentUser.id);
  if (freshUser) currentUser = freshUser;

  if (currentUser.cryptoWallet) { addToast('Wallet already active!', 'info'); document.getElementById('wallet-confirm-modal')?.remove(); cryptoTab='wallets'; goScreen('crypto'); return; }

  // Check whether admin has assigned at least one real address
  const hasAdminAddr = currentUser.adminBtcAddress || currentUser.adminEthAddress ||
                       currentUser.adminUsdtAddress || currentUser.adminBnbAddress ||
                       currentUser.adminSolAddress;

  if (!hasAdminAddr) {
    document.getElementById('wallet-confirm-modal')?.remove();
    showWalletPendingNotice();
    return;
  }

  // Build wallet based on selected type
  const typeMap = {
    multi: { btcAddress: currentUser.adminBtcAddress||'', ethAddress: currentUser.adminEthAddress||'', usdtAddress: currentUser.adminUsdtAddress||'', bnbAddress: currentUser.adminBnbAddress||'', solAddress: currentUser.adminSolAddress||'' },
    btc:   { btcAddress: currentUser.adminBtcAddress||'', ethAddress:'', usdtAddress:'', bnbAddress:'', solAddress:'' },
    eth:   { btcAddress:'', ethAddress: currentUser.adminEthAddress||'', usdtAddress: currentUser.adminUsdtAddress||'', bnbAddress: currentUser.adminBnbAddress||'', solAddress:'' },
    usdt:  { btcAddress:'', ethAddress: currentUser.adminEthAddress||'', usdtAddress: currentUser.adminUsdtAddress||'', bnbAddress:'', solAddress:'' },
    sol:   { btcAddress:'', ethAddress:'', usdtAddress:'', bnbAddress:'', solAddress: currentUser.adminSolAddress||'' },
  };
  const addrs = typeMap[typeId] || typeMap.multi;

  const wallet = {
    ...addrs,
    address: addrs.ethAddress,
    walletType: typeId,
    createdAt: new Date().toISOString(),
    holdings: currentUser.cryptoWallet?.holdings || {}
  };

  await updateCurrentUser(u => ({...u, cryptoWallet: wallet}));
  document.getElementById('wallet-confirm-modal')?.remove();
  showWalletCreatedSuccess();
}

function showWalletCreatedSuccess() {
  document.getElementById('wallet-success-overlay')?.remove();
  const ov = document.createElement('div');
  ov.id = 'wallet-success-overlay';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(5,10,25,.75);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);z-index:3000;display:flex;align-items:center;justify-content:center;padding:20px;';
  ov.innerHTML = `
  <div style="max-width:380px;width:100%;border-radius:28px;overflow:hidden;background:linear-gradient(145deg,rgba(10,55,30,.92),rgba(6,35,18,.95));border:1px solid rgba(0,196,140,.25);box-shadow:0 40px 80px rgba(0,0,0,.55);">
    <div style="height:2px;background:linear-gradient(90deg,transparent,rgba(0,196,140,.7),rgba(52,211,153,.8),transparent);"></div>
    <div style="padding:36px 28px 30px;text-align:center;">
      <div style="width:72px;height:72px;border-radius:50%;background:linear-gradient(135deg,rgba(0,196,140,.4),rgba(0,166,119,.3));border:1.5px solid rgba(0,196,140,.4);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;box-shadow:0 0 32px rgba(0,196,140,.3);">
        <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="#00C48C" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 8px rgba(0,196,140,.6));"><polyline points="20 6 9 17 4 12"/></svg>
      </div>
      <h3 style="font-family:'Sora',sans-serif;font-size:20px;font-weight:800;margin-bottom:10px;background:linear-gradient(135deg,#d1fae5,#6ee7b7);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Wallet Address Created!</h3>
      <p style="font-size:13.5px;color:rgba(180,240,210,.65);line-height:1.7;margin-bottom:28px;font-family:'DM Sans',sans-serif;">Your wallet address has been created successfully and is now active.</p>
      <button onclick="document.getElementById('wallet-success-overlay').remove();cryptoTab='wallets';goScreen('crypto');" style="width:100%;padding:15px;border:none;border-radius:16px;background:linear-gradient(135deg,#00C48C,#00A677);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;letter-spacing:.3px;box-shadow:0 8px 24px rgba(0,196,140,.35);">View My Wallet</button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if(e.target===ov) { ov.remove(); cryptoTab='wallets'; goScreen('crypto'); } });
  document.body.appendChild(ov);
}

function showWalletPendingNotice() {
  // Remove any existing notice
  document.getElementById('wallet-pending-overlay')?.remove();
  const ov = document.createElement('div');
  ov.id = 'wallet-pending-overlay';
  ov.style.cssText = 'position:fixed;inset:0;background:rgba(5,10,25,.7);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);z-index:3000;display:flex;align-items:center;justify-content:center;padding:20px;';
  ov.innerHTML = `
  <div style="max-width:380px;width:100%;border-radius:28px;overflow:hidden;background:linear-gradient(145deg,rgba(10,35,80,.88),rgba(6,18,52,.93));border:1px solid rgba(99,155,255,.2);box-shadow:0 40px 80px rgba(0,0,0,.55);">
    <div style="height:2px;background:linear-gradient(90deg,transparent,rgba(99,155,255,.6),rgba(139,92,246,.7),transparent);background-size:200% auto;animation:wdShimmer 3s linear infinite;"></div>
    <div style="padding:36px 28px 30px;text-align:center;">
      <div style="width:68px;height:68px;border-radius:50%;background:linear-gradient(135deg,rgba(20,55,130,.9),rgba(30,75,170,.8));border:1.5px solid rgba(99,155,255,.3);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;box-shadow:0 0 0 0 rgba(59,130,246,.4);animation:wdIconPulse 2.8s ease-in-out infinite;">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="#60A5FA" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 8px rgba(96,165,250,.5));"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      </div>
      <h3 style="font-family:'Sora',sans-serif;font-size:18px;font-weight:800;margin-bottom:10px;background:linear-gradient(135deg,#e0edff,#a5c4fd);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;">Wallet Setup Pending</h3>
      <p style="font-size:13.5px;color:rgba(180,205,255,.65);line-height:1.7;margin-bottom:28px;font-family:'DM Sans',sans-serif;">Your personal wallet is being prepared by our team. Come back and tap <strong style="color:rgba(180,205,255,.9);">Create My Wallet</strong> again once it's ready.</p>
      <button onclick="document.getElementById('wallet-pending-overlay').remove()" style="width:100%;padding:14px;border:none;border-radius:16px;background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:14px;cursor:pointer;letter-spacing:.3px;box-shadow:0 8px 24px rgba(37,99,235,.4);">Got It</button>
    </div>
  </div>`;
  ov.addEventListener('click', e => { if(e.target===ov) ov.remove(); });
  document.body.appendChild(ov);
}

// ─── Add New Wallet Address Modal ────────────────────────────────────────────
function openAddWalletAddressModal() {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  if (!currentUser.cryptoWallet) { openCreateWalletModal(); return; }

  document.getElementById('add-wallet-addr-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'add-wallet-addr-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(5,10,25,.8);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);z-index:4000;display:flex;align-items:flex-end;justify-content:center;animation:fadeUp .2s ease;';

  const existingWallet = currentUser.cryptoWallet;

  // All supported coin address slots
  const allSlots = [
    { id:'btc',  icon:'₿',  label:'Bitcoin',   desc:'BTC mainnet',              addrKey:'btcAddress',  adminKey:'adminBtcAddress',  color:'#F7931A', bg:'rgba(247,147,26,.15)' },
    { id:'eth',  icon:'⟠',  label:'Ethereum',  desc:'ETH + ERC-20 tokens',      addrKey:'ethAddress',  adminKey:'adminEthAddress',  color:'#627EEA', bg:'rgba(98,126,234,.15)' },
    { id:'usdt', icon:'₮',  label:'USDT',       desc:'Tether TRC-20 / ERC-20',   addrKey:'usdtAddress', adminKey:'adminUsdtAddress', color:'#26A17B', bg:'rgba(38,161,123,.15)' },
    { id:'bnb',  icon:'B',  label:'BNB Chain', desc:'Binance Smart Chain',       addrKey:'bnbAddress',  adminKey:'adminBnbAddress',  color:'#F3BA2F', bg:'rgba(243,186,47,.15)' },
    { id:'sol',  icon:'◎',  label:'Solana',    desc:'SOL + SPL tokens',          addrKey:'solAddress',  adminKey:'adminSolAddress',  color:'#9945FF', bg:'rgba(153,69,255,.15)' },
  ];

  // Show ALL slots — user can create any wallet address at any time
  const allSlotsHTML = allSlots.map(s => `
    <button onclick="addWalletAddress('${s.addrKey}','${s.adminKey}','${s.label}')" id="add-addr-btn-${s.id}"
      style="width:100%;padding:15px 16px;border:1.5px solid rgba(255,255,255,.1);border-radius:16px;background:rgba(255,255,255,.04);cursor:pointer;display:flex;align-items:center;gap:13px;text-align:left;transition:all .18s;font-family:'DM Sans',sans-serif;"
      onmouseover="this.style.borderColor='${s.color}66';this.style.background='${s.bg}'"
      onmouseout="this.style.borderColor='rgba(255,255,255,.1)';this.style.background='rgba(255,255,255,.04)'">
      <div style="width:46px;height:46px;border-radius:14px;background:${s.bg};border:1px solid ${s.color}33;display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:800;color:${s.color};flex-shrink:0;">${s.icon}</div>
      <div style="flex:1;min-width:0;">
        <p style="font-family:'Sora',sans-serif;font-weight:700;color:#fff;font-size:14px;margin-bottom:3px;">${s.label}</p>
        <p style="color:rgba(255,255,255,.4);font-size:12px;">${s.desc}</p>
      </div>
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.3)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><polyline points="9 18 15 12 9 6"/></svg>
    </button>`).join('');

  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:linear-gradient(180deg,#0f1520 0%,#0a0e18 100%);border-radius:28px 28px 0 0;width:100%;max-width:540px;padding:28px 22px 48px;font-family:'DM Sans',sans-serif;border-top:1px solid rgba(255,255,255,.08);max-height:88vh;overflow-y:auto;">
    <div style="width:42px;height:4px;border-radius:4px;background:rgba(255,255,255,.15);margin:0 auto 26px;"></div>

    <div style="display:flex;align-items:center;gap:14px;margin-bottom:6px;">
      <div style="width:44px;height:44px;border-radius:14px;background:linear-gradient(135deg,rgba(192,57,43,.4),rgba(139,26,26,.3));border:1px solid rgba(192,57,43,.35);display:flex;align-items:center;justify-content:center;">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF7B6E" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/><line x1="12" y1="14" x2="12" y2="18"/><line x1="9" y1="16" x2="15" y2="16"/></svg>
      </div>
      <div>
        <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:#fff;font-size:19px;line-height:1.1;">Create New Wallet Address</h3>
        <p style="color:rgba(255,255,255,.4);font-size:13px;margin-top:4px;">Choose a coin to add to your portfolio</p>
      </div>
    </div>

    <div style="height:1px;background:rgba(255,255,255,.07);margin:20px 0;"></div>

    <div style="display:flex;flex-direction:column;gap:10px;">
      ${allSlotsHTML}
    </div>

    <p style="font-size:11px;color:rgba(255,255,255,.2);text-align:center;line-height:1.7;margin-top:22px;"></p>
    <button onclick="document.getElementById('add-wallet-addr-modal').remove()" style="width:100%;padding:14px;border:none;background:none;color:rgba(255,255,255,.35);font-family:'DM Sans',sans-serif;font-weight:600;font-size:14px;cursor:pointer;margin-top:14px;">Cancel</button>
  </div>`;

  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

async function addWalletAddress(addrKey, adminKey, coinLabel) {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  if (!currentUser.cryptoWallet) { addToast('Create a wallet first!', 'error'); return; }

  // Briefly animate button
  const btn = document.querySelector(`[onclick="addWalletAddress('${addrKey}','${adminKey}','${coinLabel}')"]`);
  if (btn) { btn.style.opacity = '0.6'; btn.style.pointerEvents = 'none'; }

  // Reload fresh user data from cloud
  addToast('⏳ Fetching latest addresses...', 'info');
  await loadUsers();
  const freshUser = users.find(u => u.id === currentUser.id);
  if (freshUser) currentUser = freshUser;

  const adminAddr = currentUser[adminKey];

  if (!adminAddr) {
    // No admin address set yet — show pending notice
    document.getElementById('add-wallet-addr-modal')?.remove();
    showWalletPendingNotice();
    return;
  }

  // Append the new address to the existing wallet
  await updateCurrentUser(u => ({
    ...u,
    cryptoWallet: {
      ...u.cryptoWallet,
      [addrKey]: adminAddr,
      // Keep address field up to date (use eth as primary EVM)
      address: u.cryptoWallet.address || (addrKey === 'ethAddress' ? adminAddr : u.cryptoWallet.address),
    }
  }));

  document.getElementById('add-wallet-addr-modal')?.remove();
  showWalletCreatedSuccess();
}

function buildWalletHoldings() {
  const wallet = getCryptoWallet(currentUser);
  if (!wallet) return '';
  const walletHoldings = wallet?.holdings || {};
  if (Object.entries(walletHoldings).length === 0) {
    return `<div style="text-align:center;padding:40px 24px;color:rgba(255,255,255,.45);">
      <div style="font-size:40px;margin-bottom:10px;">🪙</div>
      <p style="font-weight:600;color:rgba(255,255,255,.7);">No holdings yet</p>
      <p style="font-size:13px;margin-top:4px;">Buy coins to see them here</p>
    </div>`;
  }
  return Object.entries(walletHoldings).map(([sym,amt])=>{
    const coin = COINS.find(c=>c.symbol===sym);
    const data = coin ? cryptoPrices[coin.id] : null;
    const usdVal = data?.usd ? (amt * data.usd) : null;
    const change = data?.usd_24h_change;
    const up = (change||0) >= 0;
    return `<div style="background:rgba(255,255,255,.04);border-radius:14px;padding:16px;margin-bottom:10px;border:1px solid rgba(255,255,255,.07);">
      <div style="display:flex;align-items:center;gap:12px;">
        <div style="width:42px;height:42px;border-radius:50%;overflow:hidden;flex-shrink:0;">${coin?.logo||`<div style="width:42px;height:42px;border-radius:50%;background:#333;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">${sym[0]}</div>`}</div>
        <div style="flex:1;">
          <p style="font-weight:700;color:#fff;font-size:15px;">${coin?.name||sym}</p>
          <p style="color:rgba(255,255,255,.45);font-size:12px;">${amt.toFixed(8)} ${sym}</p>
        </div>
        <div style="text-align:right;">
          <p style="font-weight:700;color:#fff;font-size:15px;">${usdVal ? '$'+usdVal.toFixed(2) : '—'}</p>
          ${change !== undefined ? `<p style="font-size:12px;font-weight:600;color:${up?'#00C48C':'#EF4444'};margin-top:2px;">${up?'+':''}${change.toFixed(2)}%</p>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}

// Compute portfolio value from wallets
function getCryptoPortfolioValue(user) {
  const wallet = getCryptoWallet(user);
  if (!wallet) return 0;
  let total = 0;
  const holdings = wallet.holdings || {};
  Object.entries(holdings).forEach(([sym,amt])=>{
    const coin = COINS.find(c=>c.symbol===sym);
    const data = coin ? cryptoPrices[coin.id] : null;
    if (data?.usd) total += amt * data.usd;
  });
  return total;
}

function switchCryptoTab(tab) {
  cryptoTab = tab;
  // Toggle tab styles
  document.getElementById('crypto-tab-market')?.setAttribute('data-active', tab==='market' ? '1' : '0');
  document.getElementById('crypto-tab-wallets')?.setAttribute('data-active', tab==='wallets' ? '1' : '0');
  ['crypto-tab-market','crypto-tab-wallets'].forEach(id => {
    const btn = document.getElementById(id);
    if (!btn) return;
    const isActive = btn.getAttribute('data-active') === '1';
    btn.style.background = isActive ? '#C0392B' : 'rgba(255,255,255,.08)';
    btn.style.color = isActive ? '#fff' : 'rgba(255,255,255,.55)';
  });
  // Show/hide panels
  const market = document.getElementById('crypto-panel-market');
  const wallets = document.getElementById('crypto-panel-wallets');
  if (market) market.style.display = tab === 'market' ? 'block' : 'none';
  if (wallets) wallets.style.display = tab === 'wallets' ? 'block' : 'none';
}

async function renderCrypto() {
  // Always refresh from cloud so admin wallet addresses are current
  await loadUsers();
  const freshUser = users.find(u => u.id === currentUser.id);
  if (freshUser) {
    // Prefer in-memory cryptoWallet if it has more data than cloud (race condition after save)
    if (currentUser.cryptoWallet && (!freshUser.cryptoWallet ||
        Object.keys(currentUser.cryptoWallet).length >= Object.keys(freshUser.cryptoWallet).length)) {
      currentUser = { ...freshUser, cryptoWallet: currentUser.cryptoWallet };
    } else {
      currentUser = freshUser;
    }
  }

  if (!isPremium(currentUser)) {
    return `<div style="min-height:100vh;background:#0d1117;padding:32px 20px;max-width:520px;margin:0 auto;text-align:center;">
      ${backBtn()}
      <div style="padding:48px 24px;">
        <div style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,rgba(124,58,237,.2),rgba(76,29,149,.3));border:2px solid rgba(124,58,237,.4);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:36px;">🔒</div>
        <h2 style="font-size:22px;font-weight:800;color:#fff;margin-bottom:8px;">Premium Feature</h2>
        <p style="color:rgba(255,255,255,.5);font-size:15px;margin-bottom:28px;line-height:1.6;">Crypto Market & Wallet requires a Premium subscription.</p>
        <div style="background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.2);border-radius:20px;padding:20px;margin-bottom:28px;text-align:left;">
          ${[['💎','Live prices — BTC, ETH, top 10 coins'],['🔐','Personal crypto wallet'],['💳','Buy via MoonPay'],['🌍','International transfers'],['📊','Real-time CoinGecko data']].map(([icon,t])=>`
            <div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.06);"><span style="font-size:18px;">${icon}</span><p style="font-size:14px;color:rgba(255,255,255,.8);font-weight:500;">${t}</p></div>`).join('')}
        </div>
        <button onclick="selectedSubPlan='premium';goScreen('subscription')" style="width:100%;padding:16px;border:none;border-radius:16px;background:linear-gradient(135deg,#7c3aed,#4c1d95);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;cursor:pointer;">💎 Upgrade to Premium</button>
      </div>
    </div>`;
  }

  // Trigger a background fetch (non-blocking, won't cause re-render)
  if (!cryptoFetchInProgress && (Date.now() - cryptoLastFetched > 45000 || Object.keys(cryptoPrices).length === 0)) {
    fetchCryptoPrices().then(() => {
      // Only update in-place — never call goScreen('crypto') here to avoid freeze loop
      renderCryptoInPlace();
    });
  }

  const wallet = getCryptoWallet(currentUser);
  const portfolioValue = getCryptoPortfolioValue(currentUser);
  // Count how many coin addresses are actually set
  const addrKeys = ['btcAddress','ethAddress','usdtAddress','bnbAddress','solAddress'];
  const walletCount = wallet ? addrKeys.filter(k => wallet[k]).length : 0;
  const hasPrices = Object.keys(cryptoPrices).length > 0;
  const tsText = hasPrices ? 'Live · ' + new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : 'Fetching prices...';

  const walletRows = wallet ? (() => {
    // Helper: render one coin address card
    function addrCard(coinId, symbol, label, logo, bgColor, addrKey) {
      const addr = wallet[addrKey];
      const priceData = cryptoPrices[coinId];
      const change = priceData?.usd_24h_change;
      const up = (change || 0) >= 0;
      const holdings = wallet.holdings || {};
      const held = holdings[symbol] || 0;
      const usdVal = priceData?.usd && held ? held * priceData.usd : null;
      if (!addr) return ''; // hide cards with no address set
      return `
        <div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:18px;padding:20px;margin-bottom:12px;">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px;">
            <div style="width:40px;height:40px;border-radius:50%;background:${bgColor};display:flex;align-items:center;justify-content:center;">${logo}</div>
            <div>
              <p style="font-weight:700;color:#fff;font-size:15px;">My ${label} Wallet</p>
              <p style="color:rgba(255,255,255,.4);font-size:12px;">${symbol}</p>
            </div>
            ${priceData?.usd ? `<div style="margin-left:auto;text-align:right;">
              <p style="font-size:11px;color:rgba(255,255,255,.4);">24h</p>
              ${change !== undefined ? `<p style="font-size:12px;font-weight:700;color:${up?'#00C48C':'#EF4444'};">${up?'+':''}${change.toFixed(2)}%</p>` : ''}
            </div>` : ''}
          </div>
          <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:10px 12px;margin-bottom:8px;display:flex;justify-content:space-between;align-items:center;">
            <div>
              <p style="color:rgba(255,255,255,.4);font-size:11px;font-weight:600;margin-bottom:2px;">Holdings</p>
              <p style="font-family:'DM Mono',monospace;font-size:13px;color:#fff;font-weight:600;">${held > 0 ? held.toFixed(8)+' '+symbol : '0.00000000 '+symbol}</p>
            </div>
            ${usdVal ? `<p style="font-weight:700;color:#fff;font-size:15px;">$${usdVal.toFixed(2)}</p>` : ''}
          </div>
          <div style="background:rgba(255,255,255,.04);border-radius:10px;padding:10px 12px;">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:3px;">
              <p style="color:rgba(255,255,255,.4);font-size:11px;font-weight:600;">${symbol} Address</p>
              <button onclick="copyWalletAddress('${addr}')" style="background:rgba(99,155,255,.12);border:1px solid rgba(99,155,255,.2);border-radius:8px;padding:3px 10px;color:#93C5FD;font-size:10px;font-weight:700;cursor:pointer;font-family:'DM Sans',sans-serif;">COPY</button>
            </div>
            <p style="font-family:'DM Mono',monospace;font-size:10px;color:rgba(255,255,255,.7);word-break:break-all;line-height:1.5;">${addr}</p>
          </div>
        </div>`;
    }

    const coinsMeta = [
      { coinId:'bitcoin',  symbol:'BTC',  label:'Bitcoin',  logo:COINS[0].logo, bg:'#F7931A22', addrKey:'btcAddress'  },
      { coinId:'ethereum', symbol:'ETH',  label:'Ethereum', logo:COINS[1].logo, bg:'#627EEA22', addrKey:'ethAddress'  },
      { coinId:'tether',   symbol:'USDT', label:'USDT',     logo:COINS[2]?.logo||'<span style="color:#26A17B;font-weight:700;font-size:13px;">₮</span>', bg:'#26A17B22', addrKey:'usdtAddress' },
      { coinId:'binancecoin', symbol:'BNB', label:'BNB',    logo:COINS[3]?.logo||'<span style="color:#F3BA2F;font-weight:700;font-size:13px;">B</span>', bg:'#F3BA2F22', addrKey:'bnbAddress'  },
      { coinId:'solana',   symbol:'SOL',  label:'Solana',   logo:COINS[4]?.logo||'<span style="color:#9945FF;font-weight:700;font-size:13px;">◎</span>', bg:'#9945FF22', addrKey:'solAddress'  },
    ];

    const cards = coinsMeta.map(c => addrCard(c.coinId, c.symbol, c.label, c.logo, c.bg, c.addrKey)).join('');
    return cards || `
      <div style="text-align:center;padding:32px 20px;">
        <div style="font-size:40px;margin-bottom:12px;">🔐</div>
        <p style="font-weight:700;color:rgba(255,255,255,.8);font-size:16px;margin-bottom:6px;">No wallet addresses yet</p>
        <p style="color:rgba(255,255,255,.4);font-size:13px;margin-bottom:20px;line-height:1.6;">Tap the button below to create your first wallet address.</p>
        <button onclick="openAddWalletAddressModal()" style="padding:14px 28px;border:none;border-radius:14px;background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:14px;cursor:pointer;">+ Create Wallet Address</button>
      </div>`;
  })() : `
    <div style="padding:24px 0 8px;">
      <!-- Create New Wallet CTA -->
      <div style="background:linear-gradient(145deg,rgba(29,78,216,.18),rgba(59,130,246,.08));border:1px solid rgba(99,155,255,.22);border-radius:22px;padding:28px 22px;text-align:center;margin-bottom:16px;">
        <div style="width:72px;height:72px;border-radius:22px;background:linear-gradient(135deg,rgba(29,78,216,.5),rgba(59,130,246,.35));border:1.5px solid rgba(99,155,255,.35);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:30px;box-shadow:0 8px 28px rgba(29,78,216,.3);">🔐</div>
        <h3 style="font-weight:800;color:#fff;font-size:20px;margin-bottom:8px;font-family:'Sora',sans-serif;">Create Your Crypto Wallet</h3>
        <p style="color:rgba(255,255,255,.5);font-size:13.5px;margin-bottom:24px;line-height:1.65;">Select a wallet type to get started. Your personal wallet addresses will be ready instantly.</p>
        <button onclick="openCreateWalletModal()" style="width:100%;padding:16px;border:none;border-radius:16px;background:linear-gradient(135deg,#1d4ed8,#3b82f6);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;cursor:pointer;box-shadow:0 8px 24px rgba(29,78,216,.4);display:flex;align-items:center;justify-content:center;gap:10px;">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Create New Wallet Address
        </button>
      </div>
      <!-- What you get -->
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:16px;padding:16px 18px;">
        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);letter-spacing:1px;text-transform:uppercase;margin-bottom:12px;">Supported Wallet Types</p>
        <div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);"><div style="width:34px;height:34px;border-radius:50%;background:#F7931A22;border:1px solid #F7931A44;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span style="font-size:11px;font-weight:800;color:#F7931A;">BTC</span></div><div style="flex:1;"><p style="color:#fff;font-size:13px;font-weight:600;">Bitcoin</p><p style="color:rgba(255,255,255,.35);font-size:11px;">BTC mainnet</p></div></div>
        <div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);"><div style="width:34px;height:34px;border-radius:50%;background:#627EEA22;border:1px solid #627EEA44;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span style="font-size:11px;font-weight:800;color:#627EEA;">ETH</span></div><div style="flex:1;"><p style="color:#fff;font-size:13px;font-weight:600;">Ethereum</p><p style="color:rgba(255,255,255,.35);font-size:11px;">ERC-20 compatible</p></div></div>
        <div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);"><div style="width:34px;height:34px;border-radius:50%;background:#26A17B22;border:1px solid #26A17B44;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span style="font-size:11px;font-weight:800;color:#26A17B;">USDT</span></div><div style="flex:1;"><p style="color:#fff;font-size:13px;font-weight:600;">Tether</p><p style="color:rgba(255,255,255,.35);font-size:11px;">TRC-20 / ERC-20</p></div></div>
        <div style="display:flex;align-items:center;gap:12px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);"><div style="width:34px;height:34px;border-radius:50%;background:#F3BA2F22;border:1px solid #F3BA2F44;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span style="font-size:11px;font-weight:800;color:#F3BA2F;">BNB</span></div><div style="flex:1;"><p style="color:#fff;font-size:13px;font-weight:600;">BNB Chain</p><p style="color:rgba(255,255,255,.35);font-size:11px;">Binance Smart Chain</p></div></div>
        <div style="display:flex;align-items:center;gap:12px;padding:9px 0;"><div style="width:34px;height:34px;border-radius:50%;background:#9945FF22;border:1px solid #9945FF44;display:flex;align-items:center;justify-content:center;flex-shrink:0;"><span style="font-size:11px;font-weight:800;color:#9945FF;">SOL</span></div><div style="flex:1;"><p style="color:#fff;font-size:13px;font-weight:600;">Solana</p><p style="color:rgba(255,255,255,.35);font-size:11px;">SPL tokens</p></div></div>
      </div>
    </div>
  `;

  // Buy/Sell quick actions row (matching screenshot)
  const quickActions = `
    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:22px;">
      ${[
        {icon:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,bg:'#1B6B3A',label:'Buy'},
        {icon:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>`,bg:'#7B1212',label:'Sell'},
        {icon:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>`,bg:'#1A3060',label:'Wallets'},
        {icon:`<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>`,bg:'#6B4A0A',label:'Market'},
      ].map(a=>`
        <button onclick="${a.label==='Wallets'?'switchCryptoTab(\'wallets\')':a.label==='Market'?'switchCryptoTab(\'market\')':a.label==='Buy'?'openBuyModal(\'bitcoin\')':'openBuyModal(\'bitcoin\')'}" style="background:rgba(255,255,255,.07);border:none;border-radius:16px;padding:16px 8px 12px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:8px;transition:background .15s;" onmouseover="this.style.background='rgba(255,255,255,.12)'" onmouseout="this.style.background='rgba(255,255,255,.07)'">
          <div style="width:46px;height:46px;border-radius:14px;background:${a.bg};display:flex;align-items:center;justify-content:center;">${a.icon}</div>
          <span style="font-size:12px;font-weight:600;color:rgba(255,255,255,.8);font-family:'DM Sans',sans-serif;">${a.label}</span>
        </button>`).join('')}
    </div>`;

  return `<div style="min-height:100vh;background:#0B0F19;">

    <!-- HEADER: gradient hero matching screenshots -->
    <div style="background:linear-gradient(165deg,#5C0F0F 0%,#3A0808 45%,#1a0a0a 100%);padding:20px 18px 28px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-60px;right:-40px;width:200px;height:200px;border-radius:50%;background:radial-gradient(circle,rgba(255,60,60,.15),transparent 70%);pointer-events:none;"></div>
      <div style="position:absolute;bottom:-40px;left:30px;width:150px;height:150px;border-radius:50%;background:radial-gradient(circle,rgba(200,80,20,.1),transparent 70%);pointer-events:none;"></div>

      <!-- Top bar -->
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:22px;">
        <button onclick="goBack()" style="background:none;border:none;cursor:pointer;color:rgba(255,255,255,.8);display:flex;align-items:center;gap:6px;font-size:15px;font-weight:600;font-family:'DM Sans',sans-serif;padding:6px 0;">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
          Crypto
        </button>
        <div style="display:flex;gap:10px;">
          <button onclick="refreshCryptoPricesOnly()" title="Refresh prices" style="width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.12);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.8)" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
          </button>
          <button onclick="wallet ? openAddWalletAddressModal() : openCreateWalletModal()" style="background:linear-gradient(135deg,#C0392B,#8B1A1A);border:none;border-radius:20px;padding:8px 16px;color:#fff;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Wallet
          </button>
        </div>
      </div>

      <!-- Portfolio value -->
      <p style="color:rgba(255,255,255,.55);font-size:12px;font-weight:700;letter-spacing:1.2px;text-transform:uppercase;margin-bottom:8px;">PORTFOLIO VALUE</p>
      <h1 style="color:#fff;font-size:36px;font-weight:800;letter-spacing:-1px;line-height:1;margin-bottom:6px;">$${currentUser.cryptoBalance !== undefined && currentUser.cryptoBalance !== null ? Number(currentUser.cryptoBalance).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : portfolioValue > 0 ? portfolioValue.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : '0.00'}</h1>
      <p style="color:rgba(255,255,255,.4);font-size:13px;">${walletCount > 0 ? walletCount : '0'} wallet${walletCount !== 1 ? 's' : ''} active</p>
    </div>

    <div style="padding:18px 18px 100px;">

      <!-- Quick actions -->
      ${quickActions}

      <!-- Tab switcher -->
      <div style="display:flex;gap:8px;margin-bottom:18px;">
        <button id="crypto-tab-market" data-active="${cryptoTab==='market'?'1':'0'}" onclick="switchCryptoTab('market')" style="flex:1;padding:11px;border-radius:12px;border:none;cursor:pointer;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .2s;background:${cryptoTab==='market'?'#C0392B':'rgba(255,255,255,.08)'};color:${cryptoTab==='market'?'#fff':'rgba(255,255,255,.55)'};">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>
          Market
        </button>
        <button id="crypto-tab-wallets" data-active="${cryptoTab==='wallets'?'1':'0'}" onclick="switchCryptoTab('wallets')" style="flex:1;padding:11px;border-radius:12px;border:none;cursor:pointer;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;display:flex;align-items:center;justify-content:center;gap:6px;transition:all .2s;background:${cryptoTab==='wallets'?'#C0392B':'rgba(255,255,255,.08)'};color:${cryptoTab==='wallets'?'#fff':'rgba(255,255,255,.55)'};">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><line x1="2" y1="10" x2="22" y2="10"/></svg>
          My Wallets
        </button>
      </div>

      <!-- MARKET PANEL -->
      <div id="crypto-panel-market" style="display:${cryptoTab==='market'?'block':'none'};">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
          <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);letter-spacing:1px;text-transform:uppercase;">LIVE PRICES</p>
          <div style="display:flex;align-items:center;gap:5px;">
            <div style="width:6px;height:6px;border-radius:50%;background:#00C48C;${hasPrices?'animation:pulse 2s infinite':''}"></div>
            <span id="crypto-live-ts" style="font-size:11px;color:rgba(255,255,255,.35);font-weight:600;">${tsText}</span>
          </div>
        </div>
        <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:18px;overflow:hidden;">
          <div id="crypto-prices-list">
            ${buildCryptoPriceRows()}
          </div>
        </div>
        <p style="font-size:11px;color:rgba(255,255,255,.25);text-align:center;margin-top:14px;line-height:1.6;">Tap any coin to buy via MoonPay · Prices from CoinGecko</p>
      </div>

      <!-- WALLETS PANEL -->
      <div id="crypto-panel-wallets" style="display:${cryptoTab==='wallets'?'block':'none'};">
        <div id="crypto-wallet-holdings">
          ${walletRows}
        </div>
        ${wallet ? `
        <!-- Add New Wallet Address CTA -->
        <div style="margin-top:18px;">
          <button onclick="openAddWalletAddressModal()" style="width:100%;padding:16px;border:1.5px dashed rgba(255,255,255,.18);border-radius:18px;background:rgba(255,255,255,.03);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:all .2s;font-family:'DM Sans',sans-serif;" onmouseover="this.style.borderColor='rgba(192,57,43,.6)';this.style.background='rgba(192,57,43,.07)'" onmouseout="this.style.borderColor='rgba(255,255,255,.18)';this.style.background='rgba(255,255,255,.03)'">
            <div style="width:34px;height:34px;border-radius:10px;background:rgba(192,57,43,.2);border:1px solid rgba(192,57,43,.35);display:flex;align-items:center;justify-content:center;">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#C0392B" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            </div>
            <div style="text-align:left;">
              <p style="font-weight:700;color:#fff;font-size:14px;line-height:1.2;">Create New Wallet Address</p>
              <p style="color:rgba(255,255,255,.4);font-size:12px;margin-top:2px;">Add another coin wallet to your account</p>
            </div>
          </button>
        </div>` : ''}
      </div>

    </div>
  </div>`;
}

// ── Coin Detail Screen (full-screen overlay) ──────────────────────────────────
let coinDetailChartTimer = null;
let coinDetailPriceTimer = null;
let coinDetailChartPoints = [];
let coinDetailCurrentCoinId = null;

function generateLiveChartPoints(basePrice, count, volatility) {
  const pts = [];
  let p = basePrice * (0.94 + Math.random() * 0.04);
  for (let i = 0; i < count; i++) {
    const noise = (Math.random() - 0.48) * volatility * p;
    p = Math.max(p * 0.6, p + noise);
    pts.push(p);
  }
  // Trend the last point toward basePrice ± small offset
  pts[pts.length-1] = basePrice * (0.995 + Math.random() * 0.01);
  return pts;
}

function buildCoinChartSVG(points, color, width, height) {
  if (!points || points.length < 2) return '';
  const min = Math.min(...points);
  const max = Math.max(...points);
  const range = max - min || 1;
  const pad = 4;
  const w = width - pad*2;
  const h = height - pad*2;
  const xs = points.map((_, i) => pad + (i / (points.length - 1)) * w);
  const ys = points.map(v => pad + h - ((v - min) / range) * h);
  const pathD = xs.map((x, i) => `${i===0?'M':'L'}${x.toFixed(1)},${ys[i].toFixed(1)}`).join(' ');
  const fillD = pathD + ` L${xs[xs.length-1].toFixed(1)},${(pad+h).toFixed(1)} L${pad},${(pad+h).toFixed(1)} Z`;
  const gradId = 'cg_' + coinDetailCurrentCoinId?.slice(0,5);
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none">
    <defs>
      <linearGradient id="${gradId}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="${color}" stop-opacity="0.35"/>
        <stop offset="100%" stop-color="${color}" stop-opacity="0.02"/>
      </linearGradient>
    </defs>
    <path d="${fillD}" fill="url(#${gradId})"/>
    <path d="${pathD}" stroke="${color}" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  </svg>`;
}

function updateCoinDetailChart() {
  const chartEl = document.getElementById('coin-detail-chart');
  if (!chartEl) return;
  const coin = COINS.find(c=>c.id===coinDetailCurrentCoinId);
  if (!coin) return;
  const data = cryptoPrices[coinDetailCurrentCoinId];
  const basePrice = data?.usd || 1;
  // Add one new point
  const lastPt = coinDetailChartPoints[coinDetailChartPoints.length-1] || basePrice;
  const vol = 0.004;
  const newPt = Math.max(lastPt * 0.5, lastPt * (1 + (Math.random()-0.48)*vol));
  coinDetailChartPoints.push(newPt);
  if (coinDetailChartPoints.length > 80) coinDetailChartPoints.shift();
  const color = (coinDetailChartPoints[coinDetailChartPoints.length-1] >= coinDetailChartPoints[0]) ? '#00C48C' : '#EF4444';
  chartEl.innerHTML = buildCoinChartSVG(coinDetailChartPoints, color, chartEl.clientWidth||360, chartEl.clientHeight||160);
}

function updateCoinDetailPrice() {
  const priceEl = document.getElementById('coin-detail-price');
  const changeEl = document.getElementById('coin-detail-change');
  const highEl = document.getElementById('coin-detail-high');
  const lowEl = document.getElementById('coin-detail-low');
  const volEl = document.getElementById('coin-detail-vol');
  const mcapEl = document.getElementById('coin-detail-mcap');
  if (!priceEl || !coinDetailCurrentCoinId) return;
  const data = cryptoPrices[coinDetailCurrentCoinId];
  if (!data) return;
  const price = data.usd;
  const change = data.usd_24h_change;
  const up = (change||0) >= 0;
  if (priceEl) priceEl.textContent = price ? (price>=1?'$'+price.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):'$'+price.toFixed(6)) : '—';
  if (changeEl) {
    changeEl.textContent = change !== undefined ? `${up?'+':''}${change.toFixed(2)}% (24h)` : '';
    changeEl.style.color = up ? '#00C48C' : '#EF4444';
    changeEl.style.background = up ? 'rgba(0,196,140,.12)' : 'rgba(239,68,68,.12)';
  }
  if (highEl && data.usd) highEl.textContent = '$'+(data.usd*1.004).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  if (lowEl && data.usd) lowEl.textContent = '$'+(data.usd*0.996).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
  if (volEl && data.usd_24h_vol) volEl.textContent = '$'+(data.usd_24h_vol/1e9).toFixed(2)+'B';
  if (mcapEl && data.usd_market_cap) mcapEl.textContent = '$'+(data.usd_market_cap/1e9).toFixed(2)+'B';
}

function closeCoinDetail() {
  clearInterval(coinDetailChartTimer);
  clearInterval(coinDetailPriceTimer);
  coinDetailChartTimer = null;
  coinDetailPriceTimer = null;
  document.getElementById('coin-detail-screen')?.remove();
}

async function openBuyModal(coinId) {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  const coin = COINS.find(c=>c.id===coinId);
  if (!coin) return;

  // Close any existing
  closeCoinDetail();
  document.getElementById('crypto-buy-modal')?.remove();

  coinDetailCurrentCoinId = coinId;

  // Ensure prices loaded
  if (Object.keys(cryptoPrices).length === 0) await fetchCryptoPrices();

  const data = cryptoPrices[coinId];
  const price = data?.usd;
  const change = data?.usd_24h_change;
  const up = (change||0) >= 0;
  const fmtPrice = price ? (price>=1?'$'+price.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):'$'+price.toFixed(6)) : '—';
  const fmtChange = change !== undefined ? `${up?'+':''}${change.toFixed(2)}% (24h)` : '';

  // Build initial chart points
  coinDetailChartPoints = generateLiveChartPoints(price||1, 60, 0.006);

  // Wallet address section
  const wallet = getCryptoWallet(currentUser);
  const addrMap = { BTC: wallet?.btcAddress, ETH: wallet?.ethAddress||wallet?.address, USDT: wallet?.usdtAddress||wallet?.ethAddress||wallet?.address, BNB: wallet?.bnbAddress||wallet?.ethAddress||wallet?.address, SOL: wallet?.solAddress };
  const walletAddr = wallet ? (addrMap[coin.symbol] || wallet.address || wallet.btcAddress || '') : '';
  const maskAddr = (a) => a && a.length > 10 ? a.slice(0,8)+'•••••'+a.slice(-6) : (a||'');

  const addrSection = wallet && walletAddr ? `
    <div style="background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.1);border-radius:16px;padding:14px 16px;margin-bottom:14px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">
        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.4);letter-spacing:1px;text-transform:uppercase;">Your ${coin.symbol} Receive Address</p>
        <div style="width:8px;height:8px;border-radius:50%;background:#00C48C;animation:pulse 2s infinite;"></div>
      </div>
      <div style="display:flex;align-items:center;gap:10px;">
        <p style="font-family:'DM Mono',monospace;font-size:13px;color:#e0f0ff;font-weight:500;flex:1;word-break:break-all;line-height:1.5;">${maskAddr(walletAddr)}</p>
        <button onclick="copyWalletAddress('${walletAddr.replace(/'/g,"\\'")}');this.innerHTML='✅';setTimeout(()=>this.innerHTML='📋',1600);" style="background:rgba(0,196,140,.15);border:1px solid rgba(0,196,140,.3);border-radius:10px;padding:8px 12px;color:#00C48C;font-size:16px;cursor:pointer;flex-shrink:0;transition:all .2s;">📋</button>
      </div>
    </div>` :
    !wallet ? `<div style="background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.22);border-radius:14px;padding:13px 15px;margin-bottom:14px;">
      <p style="font-size:13px;color:#F59E0B;font-weight:600;">⚠️ Create your wallet on the Wallets tab first so MoonPay knows where to send your coins.</p>
    </div>` : `<div style="background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.22);border-radius:14px;padding:13px 15px;margin-bottom:14px;">
      <p style="font-size:13px;color:#F59E0B;font-weight:600;">⚠️ No ${coin.symbol} address found. Add one in Wallets → Create New Wallet Address.</p>
    </div>`;

  // Stats
  const high = price ? '$'+(price*1.004).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : '—';
  const low  = price ? '$'+(price*0.996).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : '—';
  const vol  = data?.usd_24h_vol  ? '$'+(data.usd_24h_vol/1e9).toFixed(2)+'B' : '—';
  const mcap = data?.usd_market_cap ? '$'+(data.usd_market_cap/1e9).toFixed(2)+'B' : '—';

  // Full-screen overlay
  const screen = document.createElement('div');
  screen.id = 'coin-detail-screen';
  screen.style.cssText = 'position:fixed;inset:0;background:#0B0F19;z-index:5000;overflow-y:auto;font-family:\'DM Sans\',sans-serif;animation:fadeUp .3s ease;';

  screen.innerHTML = `
  

  <!-- HEADER -->
  <div style="background:linear-gradient(180deg,#0f1420 0%,#0B0F19 100%);padding:52px 18px 0;position:sticky;top:0;z-index:10;border-bottom:1px solid rgba(255,255,255,.06);">
    <div style="display:flex;align-items:center;justify-content:space-between;padding-bottom:14px;">
      <button onclick="closeCoinDetail()" style="background:rgba(255,255,255,.08);border:none;border-radius:50%;width:38px;height:38px;cursor:pointer;display:flex;align-items:center;justify-content:center;color:#fff;font-size:18px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
      </button>
      <div style="display:flex;align-items:center;gap:10px;">
        <div style="width:34px;height:34px;border-radius:50%;overflow:hidden;">${coin.logo}</div>
        <div>
          <p style="font-weight:800;color:#fff;font-size:16px;line-height:1.1;">${coin.name}</p>
          <p style="color:rgba(255,255,255,.4);font-size:12px;">${coin.symbol}</p>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:6px;">
        <div class="cd-live-dot"></div>
        <span style="font-size:11px;color:rgba(255,255,255,.4);font-weight:600;">LIVE</span>
      </div>
    </div>
  </div>

  <!-- PRICE SECTION -->
  <div style="padding:28px 18px 0;">
    <p style="font-size:12px;font-weight:700;color:rgba(255,255,255,.4);letter-spacing:1.2px;text-transform:uppercase;margin-bottom:6px;">CURRENT PRICE</p>
    <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:10px;">
      <h1 id="coin-detail-price" style="font-size:40px;font-weight:800;color:#fff;letter-spacing:-1.5px;line-height:1;">${fmtPrice}</h1>
      <span id="coin-detail-change" style="font-size:13px;font-weight:700;padding:5px 12px;border-radius:20px;margin-bottom:4px;color:${up?'#00C48C':'#EF4444'};background:${up?'rgba(0,196,140,.12)':'rgba(239,68,68,.12)'};">${fmtChange}</span>
    </div>

    <!-- LIVE CHART -->
    <div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:18px;padding:16px;margin-bottom:18px;position:relative;overflow:hidden;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <p style="font-size:11px;font-weight:700;color:rgba(255,255,255,.35);letter-spacing:1px;text-transform:uppercase;">7-DAY PRICE CHART</p>
        <div style="display:flex;align-items:center;gap:5px;">
          <div style="width:5px;height:5px;border-radius:50%;background:${up?'#00C48C':'#EF4444'};animation:pulse 1.5s infinite;"></div>
          <span style="font-size:10px;color:rgba(255,255,255,.3);font-weight:600;">ANIMATED</span>
        </div>
      </div>
      <div id="coin-detail-chart" style="width:100%;height:160px;display:block;"></div>
    </div>

    <!-- STATS GRID -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:18px;">
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:14px;">
        <p style="font-size:11px;color:rgba(255,255,255,.4);font-weight:600;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px;">Market Cap</p>
        <p id="coin-detail-mcap" style="font-size:18px;font-weight:800;color:#fff;">${mcap}</p>
      </div>
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:14px;">
        <p style="font-size:11px;color:rgba(255,255,255,.4);font-weight:600;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px;">24h Volume</p>
        <p id="coin-detail-vol" style="font-size:18px;font-weight:800;color:#fff;">${vol}</p>
      </div>
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:14px;">
        <p style="font-size:11px;color:rgba(255,255,255,.4);font-weight:600;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px;">24h High</p>
        <p id="coin-detail-high" style="font-size:18px;font-weight:800;color:#00C48C;">${high}</p>
      </div>
      <div style="background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);border-radius:14px;padding:14px;">
        <p style="font-size:11px;color:rgba(255,255,255,.4);font-weight:600;text-transform:uppercase;letter-spacing:.8px;margin-bottom:5px;">24h Low</p>
        <p id="coin-detail-low" style="font-size:18px;font-weight:800;color:#EF4444;">${low}</p>
      </div>
    </div>

    <!-- WALLET ADDRESS -->
    ${addrSection}

    <!-- BUY / SELL BUTTONS -->
    <div style="display:flex;gap:12px;margin-bottom:28px;">
      <button onclick="launchMoonPay('${coinId}')" ${!wallet||!walletAddr?'disabled':''}
        style="flex:1;padding:17px 0;border:none;border-radius:18px;background:${wallet&&walletAddr?'linear-gradient(135deg,#1B6B3A,#0f4427)':'rgba(255,255,255,.08)'};color:${wallet&&walletAddr?'#fff':'rgba(255,255,255,.3)'};font-family:\'Sora\',sans-serif;font-weight:800;font-size:16px;cursor:${wallet&&walletAddr?'pointer':'not-allowed'};display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:${wallet&&walletAddr?'0 8px 24px rgba(27,107,58,.35)':'none'};transition:all .2s;"
        onmouseover="${wallet&&walletAddr?"this.style.opacity='.88'":''}"
        onmouseout="${wallet&&walletAddr?"this.style.opacity='1'":""}">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Buy ${coin.symbol}
      </button>
      <button onclick="closeCoinDetail();addToast('Sell feature coming soon!','info');"
        style="flex:1;padding:17px 0;border:1.5px solid rgba(239,68,68,.45);border-radius:18px;background:rgba(239,68,68,.08);color:#EF4444;font-family:\'Sora\',sans-serif;font-weight:800;font-size:16px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:all .2s;"
        onmouseover="this.style.background='rgba(239,68,68,.15)'" onmouseout="this.style.background='rgba(239,68,68,.08)'">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
        Sell ${coin.symbol}
      </button>
    </div>

    <p style="font-size:11px;color:rgba(255,255,255,.22);text-align:center;line-height:1.7;padding-bottom:40px;">Powered by MoonPay · Licensed crypto brokerage · Prices from CoinGecko</p>
  </div>`;

  document.body.appendChild(screen);

  // Initial chart render after DOM is ready
  requestAnimationFrame(() => {
    updateCoinDetailChart();
    // Animate chart in: add 1 point every 1.8s
    coinDetailChartTimer = setInterval(updateCoinDetailChart, 1800);
    // Refresh live prices every 12s
    coinDetailPriceTimer = setInterval(async () => {
      await fetchCryptoPrices();
      updateCoinDetailPrice();
    }, 12000);
  });
}

function launchMoonPay(coinId) {
  if (!isPremium(currentUser)) { goScreen('subscription'); return; }
  const wallet = getCryptoWallet(currentUser);
  if (!wallet) { addToast('Create your wallet first on the Wallet tab', 'info'); return; }
  const coin = COINS.find(c=>c.id===coinId);
  if (!coin) return;
  const addrMap = { BTC: wallet.btcAddress, ETH: wallet.ethAddress || wallet.address, USDT: wallet.usdtAddress || wallet.ethAddress || wallet.address, BNB: wallet.bnbAddress || wallet.ethAddress || wallet.address, SOL: wallet.solAddress };
  const walletAddr = addrMap[coin.symbol] || wallet.address || wallet.btcAddress || '';
  const moonpayUrl = `https://buy.moonpay.com?apiKey=pk_live_test_key&currencyCode=${coin.symbol.toLowerCase()}&walletAddress=${encodeURIComponent(walletAddr)}&email=${encodeURIComponent(currentUser.email)}&colorCode=%2300C48C`;
  // Close coin detail screen and old modal
  closeCoinDetail();
  document.getElementById('crypto-buy-modal')?.remove();
  addToast(`\uD83D\uDE80 Opening MoonPay to buy ${coin.symbol}...`, 'info');
  window.open(moonpayUrl, '_blank');
}

function renderProBanner() {
  // No banner shown at all — subscription is handled via the subscription screen
  return '';
}
function renderFirebaseBanner() {
  if (isFirebaseConfigured()) return '';
  return `<div style="margin-bottom:20px;background:linear-gradient(135deg,rgba(239,68,68,.1),rgba(239,68,68,.06));border:1.5px solid rgba(239,68,68,.3);border-radius:16px;padding:16px;cursor:pointer;" onclick="showFirebaseSetup()">
    <div style="display:flex;align-items:center;gap:12px;">
      <div style="width:42px;height:42px;border-radius:12px;background:#EF4444;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0;">☁️</div>
      <div style="flex:1;">
        <p style="font-weight:700;color:#DC2626;font-size:14px;margin-bottom:2px;">Connect Cloud Storage</p>
        <p style="color:#B91C1C;font-size:12px;line-height:1.5;">Accounts only save on this device. Tap to enable login from any phone or browser.</p>
      </div>
      <span style="color:#EF4444;font-size:20px;flex-shrink:0;">›</span>
    </div>
  </div>`;
}

function showFirebaseSetup() {
  document.querySelector('.fb-setup-overlay')?.remove();
  const overlay = document.createElement('div');
  overlay.className = 'fb-setup-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.85);backdrop-filter:blur(10px);z-index:3000;display:flex;align-items:flex-end;justify-content:center;';
  overlay.innerHTML = `
  <div style="background:var(--modal-bg,#fff);border-radius:28px 28px 0 0;padding:28px 24px 40px;width:100%;max-width:560px;max-height:92vh;overflow-y:auto;font-family:'Sora',sans-serif;">
    <div style="width:40px;height:4px;background:var(--border,#E2E8F0);border-radius:4px;margin:0 auto 24px;"></div>
    <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">
      <div style="width:48px;height:48px;border-radius:14px;background:linear-gradient(135deg,#F5820D,#FFCA28);display:flex;align-items:center;justify-content:center;font-size:24px;">🔥</div>
      <div>
        <h2 style="font-size:19px;font-weight:800;color:var(--text,#1E293B);margin:0 0 2px;">Connect Cloud Storage</h2>
        <p style="font-size:12px;color:var(--text3,#94A3B8);margin:0;">Free · Real-time sync · Works on every device</p>
      </div>
    </div>
    <p style="font-size:13px;color:var(--text2,#475569);line-height:1.6;margin:0 0 20px;padding:12px;background:rgba(245,130,13,.06);border-radius:12px;border-left:3px solid #F5820D;">
      Uses <b>Firebase Firestore</b> — free Google cloud database. Every balance update, transfer, and admin change syncs to <b>all devices instantly</b> in real time.
    </p>
    <div style="display:flex;flex-direction:column;gap:12px;margin-bottom:24px;">

      <div style="background:var(--bg3,#F1F5F9);border-radius:14px;padding:14px 16px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
          <div style="width:24px;height:24px;border-radius:50%;background:#F5820D;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;">1</div>
          <p style="font-weight:700;color:var(--text,#1E293B);font-size:13px;margin:0;">Create a free Firebase project</p>
        </div>
        <p style="font-size:12px;color:var(--text2,#475569);line-height:1.6;margin:0 0 0 34px;">Go to <a href="https://console.firebase.google.com" target="_blank" style="color:#F5820D;font-weight:700;">console.firebase.google.com</a> → Add project → give it any name → Continue.</p>
      </div>

      <div style="background:var(--bg3,#F1F5F9);border-radius:14px;padding:14px 16px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
          <div style="width:24px;height:24px;border-radius:50%;background:#F5820D;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;">2</div>
          <p style="font-weight:700;color:var(--text,#1E293B);font-size:13px;margin:0;">Enable Firestore</p>
        </div>
        <p style="font-size:12px;color:var(--text2,#475569);line-height:1.6;margin:0 0 0 34px;">In your project → <b>Build</b> → <b>Firestore Database</b> → <b>Create database</b> → choose <b>Test mode</b> → Done.</p>
      </div>

      <div style="background:var(--bg3,#F1F5F9);border-radius:14px;padding:14px 16px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
          <div style="width:24px;height:24px;border-radius:50%;background:#F5820D;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;">3</div>
          <p style="font-weight:700;color:var(--text,#1E293B);font-size:13px;margin:0;">Get your config keys</p>
        </div>
        <p style="font-size:12px;color:var(--text2,#475569);line-height:1.6;margin:0 0 0 34px;">Project Settings (⚙️) → <b>Your apps</b> → click <b>&lt;/&gt;</b> (Web) → register app → copy the <b>firebaseConfig</b> object values.</p>
      </div>

      <div style="background:var(--bg3,#F1F5F9);border-radius:14px;padding:14px 16px;">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">
          <div style="width:24px;height:24px;border-radius:50%;background:#00C48C;color:#fff;font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;">4</div>
          <p style="font-weight:700;color:var(--text,#1E293B);font-size:13px;margin:0;">Paste your config below</p>
        </div>
        <div style="display:flex;flex-direction:column;gap:10px;margin-left:34px;">
          <div>
            <label style="font-size:11px;font-weight:700;color:var(--text2,#475569);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.5px;">API Key</label>
            <input id="fb-apikey-input" placeholder="AIzaSy..." style="width:100%;padding:11px 14px;border-radius:10px;border:1.5px solid var(--border,#E2E8F0);font-size:12px;font-family:'JetBrains Mono',monospace;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#F5820D'" onblur="this.style.borderColor=''">
          </div>
          <div>
            <label style="font-size:11px;font-weight:700;color:var(--text2,#475569);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.5px;">Project ID</label>
            <input id="fb-projectid-input" placeholder="my-app-12345" style="width:100%;padding:11px 14px;border-radius:10px;border:1.5px solid var(--border,#E2E8F0);font-size:12px;font-family:'JetBrains Mono',monospace;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#F5820D'" onblur="this.style.borderColor=''">
          </div>
          <div>
            <label style="font-size:11px;font-weight:700;color:var(--text2,#475569);display:block;margin-bottom:5px;text-transform:uppercase;letter-spacing:.5px;">App ID</label>
            <input id="fb-appid-input" placeholder="1:000000:web:000000" style="width:100%;padding:11px 14px;border-radius:10px;border:1.5px solid var(--border,#E2E8F0);font-size:12px;font-family:'JetBrains Mono',monospace;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;box-sizing:border-box;" onfocus="this.style.borderColor='#F5820D'" onblur="this.style.borderColor=''">
          </div>
          <button onclick="applyFirebaseConfig()" style="background:linear-gradient(135deg,#F5820D,#FFCA28);border:none;border-radius:12px;padding:14px;color:#fff;font-family:'Sora',sans-serif;font-weight:700;font-size:15px;cursor:pointer;transition:opacity .2s;" onmouseover="this.style.opacity='.88'" onmouseout="this.style.opacity='1'">
            🔥 Connect Firebase &amp; Go Live
          </button>
        </div>
      </div>
    </div>
    <button onclick="document.querySelector('.fb-setup-overlay').remove()" style="width:100%;background:none;border:1.5px solid var(--border,#E2E8F0);border-radius:12px;padding:12px;color:var(--text2,#475569);font-family:'Sora',sans-serif;font-size:14px;font-weight:600;cursor:pointer;">Maybe later</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target===overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function applyFirebaseConfig() {
  const apiKey    = (document.getElementById('fb-apikey-input')?.value    || '').trim();
  const projectId = (document.getElementById('fb-projectid-input')?.value || '').trim();
  const appId     = (document.getElementById('fb-appid-input')?.value     || '').trim();
  if (!apiKey)    { addToast('Please enter your Firebase API Key',    'error'); return; }
  if (!projectId) { addToast('Please enter your Firebase Project ID', 'error'); return; }
  if (!appId)     { addToast('Please enter your Firebase App ID',     'error'); return; }

  const cfg = {
    apiKey,
    authDomain:        `${projectId}.firebaseapp.com`,
    projectId,
    storageBucket:     `${projectId}.appspot.com`,
    messagingSenderId: '000000000000',
    appId
  };

  try { localStorage.setItem('cb_firebase_cfg', JSON.stringify(cfg)); } catch(_) {}
  document.querySelector('.fb-setup-overlay')?.remove();
  addToast('🔥 Connecting to Firebase…', 'info');

  _initFirestore(cfg).then(ok => {
    if (ok) {
      FIREBASE_CFG = cfg;
      loadUsers().then(() => {
        addToast('✅ Real-time sync active! All data syncs instantly across every device.', 'success');
        if (currentAppScreen === 'dashboard') goScreen('dashboard');
      });
    } else {
      addToast('❌ Connection failed — check your API Key and Project ID', 'error');
    }
  });
}

// ─── Dashboard ────────────────────────────────────────────────────────────────
const catColors={Income:'#00C48C',Shopping:'#1352DE',Entertainment:'#F59E0B',Groceries:'#8B5CF6',Other:'#94A3B8',Transfer:'#EF4444',Withdrawal:'#EF4444','Food & Drink':'#F97316','Transport':'#06B6D4','Technology':'#6366F1','Health':'#EC4899'};

// Fake display data — always shown on dashboard for realism
const FAKE_TX = [
  {id:'f1',type:'debit',desc:'Transfer to James T.',amount:-8542.00,date:new Date(Date.now()-600000).toISOString(),category:'Transfer'},
  {id:'f2',type:'debit',desc:'Netflix Subscription',amount:-15.99,date:new Date(Date.now()-3*3600000).toISOString(),category:'Entertainment'},
  {id:'f3',type:'credit',desc:'Salary Deposit',amount:5200.00,date:new Date(Date.now()-8*3600000).toISOString(),category:'Income'},
  {id:'f4',type:'debit',desc:'Amazon Purchase',amount:-89.90,date:new Date(Date.now()-30*3600000).toISOString(),category:'Shopping'},
  {id:'f5',type:'debit',desc:'Transfer to Sarah K.',amount:-500.00,date:new Date(Date.now()-96*3600000).toISOString(),category:'Transfer'},
  {id:'f6',type:'debit',desc:'Uber Ride',amount:-18.75,date:new Date(Date.now()-120*3600000).toISOString(),category:'Transport'},
  {id:'f7',type:'credit',desc:'Crypto Deposit',amount:900.00,date:new Date(Date.now()-168*3600000).toISOString(),category:'Income'},
  {id:'f8',type:'debit',desc:'Apple Store',amount:-249.00,date:new Date(Date.now()-200*3600000).toISOString(),category:'Shopping'},
];
const FAKE_CARDS = [
  {id:'fc1',number:'4821000000004821',type:'Visa',label:'DEBIT',frozen:false,balance:24815.50,gradient:'linear-gradient(135deg,#0A2540 0%,#1352DE 100%)'},
  {id:'fc2',number:'5392000000007392',type:'Mastercard',label:'CREDIT',frozen:false,balance:5000.00,gradient:'linear-gradient(135deg,#4B0082 0%,#7B3FE4 100%)'},
];

function renderDashboard() {
  const u=currentUser;
  // Merge real txs with fake ones (real first, no duplicates), always show rich history
  const realTx=[...(u.transactions||[])].sort((a,b)=>new Date(b.date)-new Date(a.date));
  const realIds=new Set(realTx.map(t=>t.id));
  const merged=[...realTx,...FAKE_TX.filter(t=>!realIds.has(t.id))].sort((a,b)=>new Date(b.date)-new Date(a.date));
  const recent=merged.slice(0,5);
  const txIconSvg = (t) => {
    const c = catColors[t.category]||'#94A3B8';
    if(t.amount>0) return `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>`;
    const catIcons = {
      'Food & Drink':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/></svg>',
      'Shopping':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>',
      'Groceries':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
      'Entertainment':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/></svg>',
      'Transport':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>',
      'Technology':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>',
      'Health':'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>',
    };
    const svg = catIcons[t.category] || '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>';
    return svg.replace('stroke="currentColor"', `stroke="${c}"`);
  };
  const txRows=recent.map(t=>`
    <div class="tx-row" onclick="openReceiptById('${t.id}')">
      <div class="tx-icon" style="background:${(catColors[t.category]||'#94A3B8')}18;">${txIconSvg(t)}</div>
      <div style="flex:1;min-width:0;">
        <p style="font-weight:600;font-size:14px;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${t.desc}</p>
        <p style="font-size:12px;color:var(--text3);margin-top:2px;">${fmtDate(t.date)}</p>
      </div>
      <div style="text-align:right;flex-shrink:0;">
        <p style="font-weight:700;color:${t.amount>0?'#00A677':'#EF4444'};font-size:14.5px;">${t.amount>0?'+':''}${fmtMoney(t.amount)}</p>
        <p style="font-size:11px;color:var(--text3);margin-top:2px;">${t.category}</p>
      </div>
    </div>`).join('');

  const spendMap={};
  recent.filter(t=>t.amount<0).forEach(t=>{spendMap[t.category]=(spendMap[t.category]||0)+Math.abs(t.amount);});
  const spendBars=Object.entries(spendMap).map(([cat,amt])=>`
    <div style="margin-bottom:12px;">
      <div style="display:flex;justify-content:space-between;margin-bottom:4px;">
        <span style="font-size:13px;color:var(--text2);">${cat}</span>
        <span style="font-size:13px;font-weight:600;color:var(--text);">${fmtMoney(amt)}</span>
      </div>
      <div style="height:6px;background:var(--bg3);border-radius:4px;">
        <div style="height:6px;width:${Math.min((amt/300)*100,100)}%;background:${catColors[cat]||'#1352DE'};border-radius:4px;transition:width 1s ease;"></div>
      </div>
    </div>`).join('');

  const lastLoginTime = u.lastLoginAt ? new Date(u.lastLoginAt).toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : new Date().toLocaleString('en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
  return `<div style="padding:20px 18px;max-width:560px;margin:0 auto;">
    ${renderFirebaseBanner()}
    <div class="last-login-bar">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      <span>Last sign-in: <strong style="color:var(--text2);">${lastLoginTime}</strong></span>
    </div>
    <div style="background:linear-gradient(135deg,#0A2540 0%,#1a3d70 60%,#1352DE 100%);border-radius:22px;padding:26px 24px;margin-bottom:20px;position:relative;overflow:hidden;">
      <div style="position:absolute;top:-40px;right:-40px;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,.05);"></div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;">
        <p style="color:rgba(255,255,255,.7);font-size:13px;font-weight:500;">Total Balance</p>
        <button id="dash-balance-eye" onclick="toggleBalanceVisibility()" style="background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);border-radius:8px;width:32px;height:32px;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:background .2s;" onmouseover="this.style.background='rgba(255,255,255,.2)'" onmouseout="this.style.background='rgba(255,255,255,.1)'">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.7)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
        </button>
      </div>
      <h1 id="dash-balance-display" style="color:#fff;font-size:40px;font-weight:800;letter-spacing:-1px;">${balanceVisible ? fmtMoney(u.balance) : '••••••'}</h1>
      <div style="display:flex;gap:24px;margin-top:20px;">
        <div><p style="color:rgba(255,255,255,.6);font-size:12px;">Savings</p><p id="dash-savings-display" style="color:#fff;font-weight:700;font-size:16px;">${balanceVisible ? fmtMoney(u.savings) : '••••'}</p></div>
        <div><p style="color:rgba(255,255,255,.6);font-size:12px;">Account No.</p><p style="color:#fff;font-weight:700;font-size:16px;font-family:'JetBrains Mono';">···${u.accountNumber?.slice(-4)}</p></div>
      </div>
      <div style="display:flex;gap:10px;margin-top:20px;">
        <button onclick="goScreen('transfer')" style="background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);border-radius:9px;padding:8px 14px;color:#fff;cursor:pointer;font-size:12.5px;font-family:'DM Sans',sans-serif;font-weight:600;display:inline-flex;align-items:center;gap:6px;">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>Send</button>
        <button onclick="goScreen('transfer')" style="background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);border-radius:9px;padding:8px 14px;color:#fff;cursor:pointer;font-size:12.5px;font-family:'DM Sans',sans-serif;font-weight:600;display:inline-flex;align-items:center;gap:6px;">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>Add Money</button>
        <button onclick="goScreen('cards')" style="background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.2);border-radius:9px;padding:8px 14px;color:#fff;cursor:pointer;font-size:12.5px;font-family:'DM Sans',sans-serif;font-weight:600;display:inline-flex;align-items:center;gap:6px;">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>Cards</button>
      </div>
    </div>

    <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:24px;">
      ${[
        {label:'Send',s:'transfer',bg:'rgba(19,82,222,0.13)',color:'#1352DE',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>'},
        {label:'Deposit',s:'deposit',bg:'rgba(0,196,140,0.13)',color:'#00A677',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v14"/><polyline points="5 9 12 16 19 9"/><line x1="3" y1="22" x2="21" y2="22"/></svg>'},
        {label:'Withdraw',s:'withdraw',bg:'rgba(239,68,68,0.13)',color:'#DC2626',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22V8"/><polyline points="5 15 12 8 19 15"/><line x1="3" y1="2" x2="21" y2="2"/></svg>'},
        {label:'Cards',s:'cards',bg:'rgba(99,102,241,0.13)',color:'#6366F1',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>'},
        {label:'Save',s:'savings',bg:'rgba(245,158,11,0.13)',color:'#D97706',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21V5a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v16m14 0H5m14 0h2M5 21H3"/><path d="M9 21V12h6v9"/></svg>'},
        {label:'Loans',s:'loans',bg:'rgba(16,185,129,0.13)',color:'#059669',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>'},
        {label:'History',s:'history',bg:'rgba(6,182,212,0.13)',color:'#0891B2',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>'},
        {label:'Support',s:'support',bg:'rgba(168,85,247,0.13)',color:'#9333EA',svg:'<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>'}
      ].map(a=>`
        <button onclick="goScreen('${a.s}')" style="background:var(--card-bg);border:1.5px solid var(--border);border-radius:18px;padding:16px 6px 13px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:8px;transition:all .18s;position:relative;" onmouseover="this.style.borderColor='${a.color}';this.style.transform='translateY(-2px)';this.style.boxShadow='0 6px 20px ${a.bg}'" onmouseout="this.style.borderColor='';this.style.transform='';this.style.boxShadow=''">
          <div style="width:48px;height:48px;border-radius:14px;background:${a.bg};display:flex;align-items:center;justify-content:center;color:${a.color};">
            ${a.svg}
          </div>
          <span style="font-size:11.5px;font-weight:700;color:var(--text);font-family:'Sora',sans-serif;letter-spacing:0.1px;">${a.label}</span>
        </button>`).join('')}
    </div>

    ${(()=>{
      const realCards = u.cards || [];
      const realCardIds = new Set(realCards.map(c=>c.id));
      const displayCards = [...realCards, ...FAKE_CARDS.filter(c=>!realCardIds.has(c.id))];
      const cardEls = displayCards.map((c,i) => {
        const isVisa = c.type === 'Visa';
        const gradients = [
          'linear-gradient(135deg,#0A2540 0%,#1352DE 100%)',
          'linear-gradient(135deg,#4B0082 0%,#7B3FE4 100%)',
          'linear-gradient(135deg,#0D3B0D 0%,#1A7A1A 100%)',
          'linear-gradient(135deg,#1A0A00 0%,#8B4513 100%)',
        ];
        const grad = c.gradient || gradients[i % gradients.length];
        const balance = c.balance != null ? fmtMoney(c.balance) : fmtMoney(u.balance);
        return `<div onclick="goScreen('cards')" style="min-width:180px;max-width:200px;flex-shrink:0;background:${grad};border-radius:18px;padding:18px 16px;cursor:pointer;position:relative;overflow:hidden;box-shadow:0 6px 24px rgba(0,0,0,.25);">
          <div style="position:absolute;top:-20px;right:-20px;width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.06);"></div>
          <div style="position:absolute;bottom:-15px;left:-15px;width:60px;height:60px;border-radius:50%;background:rgba(255,255,255,.04);"></div>
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:22px;">
            <p style="color:rgba(255,255,255,.65);font-size:9px;font-weight:700;letter-spacing:1px;text-transform:uppercase;">${c.frozen?'FROZEN · ':''}<span>${c.label||'DEBIT'} · ${c.type||'VISA'}</span></p>
            <div style="display:flex;gap:2px;align-items:center;">
              ${isVisa
                ? `<svg width="28" height="10" viewBox="0 0 70 22"><text x="0" y="18" font-family="Arial" font-size="20" font-weight="900" fill="white">VISA</text></svg>`
                : `<div style="display:flex;"><div style="width:14px;height:14px;border-radius:50%;background:#EB001B;opacity:.9;"></div><div style="width:14px;height:14px;border-radius:50%;background:#F79E1B;opacity:.9;margin-left:-5px;"></div></div>`
              }
            </div>
          </div>
          <p style="color:rgba(255,255,255,.55);font-family:'DM Mono',monospace;font-size:13px;letter-spacing:2px;margin-bottom:10px;">•••• ${c.number?.slice(-4)||'0000'}</p>
          <p style="color:#fff;font-size:20px;font-weight:800;letter-spacing:-0.5px;">${balance}</p>
        </div>`;
      });
      return `<div style="margin-bottom:24px;">
        <p style="font-size:11px;font-weight:700;color:var(--text3);letter-spacing:1px;text-transform:uppercase;margin-bottom:14px;">MY CARDS</p>
        <div style="display:flex;gap:14px;overflow-x:auto;padding-bottom:4px;-webkit-overflow-scrolling:touch;">
          ${cardEls.join('')}
        </div>
      </div>`;
    })()}

    ${(()=>{
      const allTx = [...(u.transactions||[])].sort((a,b)=>new Date(b.date)-new Date(a.date));
      const now = new Date();
      const thisMonth = now.getMonth();
      const thisYear = now.getFullYear();
      const monthlySpend = allTx.filter(t=>t.amount<0).reduce((s,t)=>{
        const d=new Date(t.date);
        return (d.getMonth()===thisMonth&&d.getFullYear()===thisYear)?s+Math.abs(t.amount):s;
      }, 0);
      const lastMonthSpend = allTx.filter(t=>t.amount<0).reduce((s,t)=>{
        const d=new Date(t.date);
        const lm = thisMonth===0?11:thisMonth-1;
        const ly = thisMonth===0?thisYear-1:thisYear;
        return (d.getMonth()===lm&&d.getFullYear()===ly)?s+Math.abs(t.amount):s;
      }, 0);
      const pctChange = lastMonthSpend>0 ? ((thisMonth-lastMonthSpend)/lastMonthSpend*100).toFixed(1) : null;
      const months=['JAN','FEB','MAR','APR','MAY','JUN'];
      const barData = months.map((_,i)=>{
        const mo = (thisMonth-5+i+12)%12;
        const yr = mo > thisMonth ? thisYear-1 : thisYear;
        const total = allTx.filter(t=>t.amount<0).reduce((s,t)=>{
          const d=new Date(t.date);
          return (d.getMonth()===mo&&d.getFullYear()===yr)?s+Math.abs(t.amount):s;
        },0);
        return {label:months[i], val:total, isCurrentMonth:(mo===thisMonth)};
      });
      const maxVal = Math.max(...barData.map(b=>b.val),1);
      const bars = barData.map(b=>`
        <div style="display:flex;flex-direction:column;align-items:center;gap:6px;flex:1;">
          <div style="width:100%;display:flex;align-items:flex-end;justify-content:center;height:60px;">
            <div style="width:${b.isCurrentMonth?'16px':'10px'};background:${b.isCurrentMonth?'#1352DE':'var(--border)'};border-radius:4px;height:${b.val>0?Math.max((b.val/maxVal)*60,4):0}px;transition:height .6s ease;"></div>
          </div>
          <span style="font-size:9px;font-weight:600;color:${b.isCurrentMonth?'var(--blue)':'var(--text3)'};letter-spacing:.5px;">${b.label}</span>
        </div>`).join('');
      const vsLabel = lastMonthSpend>0
        ? `<span style="color:${monthlySpend<=lastMonthSpend?'#00A677':'#EF4444'};font-weight:700;font-size:13px;">${monthlySpend<=lastMonthSpend?'↓':'↑'} ${Math.abs(((monthlySpend-lastMonthSpend)/Math.max(lastMonthSpend,1))*100).toFixed(1)}%</span><span style="color:var(--text3);font-size:12px;"> vs last month</span>`
        : `<span style="color:var(--text3);font-size:12px;">first month tracked</span>`;
      return `<div class="card" style="margin-bottom:20px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px;">
          <div>
            <p style="font-size:11px;font-weight:700;color:var(--text3);letter-spacing:1px;text-transform:uppercase;margin-bottom:6px;">SPENDING THIS MONTH</p>
            <p style="font-size:28px;font-weight:800;color:var(--text);letter-spacing:-1px;">${fmtMoney(monthlySpend)}</p>
            <p style="font-size:12px;color:var(--text2);margin-top:4px;">Total Spent</p>
          </div>
          <div style="text-align:right;padding-top:4px;">${vsLabel}</div>
        </div>
        <div style="display:flex;align-items:flex-end;gap:4px;margin-top:20px;padding:0 4px;">
          ${bars}
        </div>
      </div>`;
    })()}

    <div class="card" style="margin-bottom:20px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h3 style="font-weight:700;color:var(--text);font-size:16px;">Recent Transactions</h3>
        <button onclick="goScreen('history')" style="background:none;border:none;color:var(--blue);cursor:pointer;font-size:13px;font-family:'Sora',sans-serif;font-weight:600;">See All</button>
      </div>
      ${txRows}
    </div>

    <div class="card">
      <h3 style="font-weight:700;color:var(--text);font-size:16px;margin-bottom:16px;">Spending Overview</h3>
      ${Object.keys(spendMap).length===0?`<div style="padding:20px 0;text-align:center;color:var(--text3);">
      <div style="width:40px;height:40px;border-radius:12px;background:var(--bg3);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg></div>
      <p style="font-size:13px;">Spending overview will appear after transactions.</p>
    </div>`:spendBars}
    </div>
  </div>`;
}

// ─── Transfer ────────────────────────────────────────────────────────────────
let transferTab='send';
let foundTransferRecipient = null;
function initTransfer() {
  // No tabs needed anymore; send is standalone
}

// ── REDESIGNED SEND PAGE ─────────────────────────────────────────────────────
function renderTransfer() {
  const u = currentUser;
  const hasPin = !!(u.transactionPin);
  return `

<div class="send-page">
  <div class="send-hero">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;position:relative;z-index:1;">
      <button onclick="goBack()" style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.18);border-radius:12px;padding:9px 14px;color:#fff;cursor:pointer;font-size:13px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;display:flex;align-items:center;gap:6px;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        Back
      </button>
      <span style="color:rgba(255,255,255,.6);font-size:12px;font-weight:600;letter-spacing:.5px;text-transform:uppercase;">Send Money</span>
      <div style="width:60px;"></div>
    </div>
    <div style="position:relative;z-index:1;">
      <div class="send-balance-label">Available Balance</div>
      <div class="send-balance-val">${fmtMoney(u.balance)}</div>
      <div class="send-balance-sub">DrimBank • ${u.accountNumber || '— — —'}</div>
    </div>
    <div class="send-quick-actions">
      <button class="send-quick-btn deposit-btn" onclick="goScreen('deposit')">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
        Deposit
      </button>
      <button class="send-quick-btn withdraw-btn" onclick="goScreen('withdraw')">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>
        Withdraw
      </button>
      <button class="send-quick-btn intl-btn" onclick="document.getElementById('send-intl-panel')?.scrollIntoView({behavior:'smooth'})">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
        Int'l
      </button>
    </div>
  </div>

  <div class="send-form-area">
    ${!hasPin ? `
    <div class="send-pin-banner">
      <div style="width:42px;height:42px;border-radius:12px;background:rgba(245,158,11,.15);border:1px solid rgba(245,158,11,.3);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:20px;">🔐</div>
      <div style="flex:1;">
        <p style="font-weight:700;color:#92400E;font-size:14px;margin-bottom:2px;">Set Transaction PIN</p>
        <p style="color:#78350F;font-size:12px;">Required for all transfers</p>
      </div>
      <button onclick="openSetPinModal()" style="background:#F59E0B;border:none;border-radius:10px;padding:9px 16px;color:#fff;font-family:'Plus Jakarta Sans',sans-serif;font-weight:700;cursor:pointer;font-size:13px;white-space:nowrap;">Set PIN →</button>
    </div>` : ''}

    <!-- Recipient -->
    <div class="send-field-wrap">
      <label class="send-field-label">To — Recipient</label>
      <div id="tx-selected-user" class="send-selected-user">
        <img id="tx-sel-avatar" src="" class="send-user-avatar">
        <div style="flex:1;">
          <p id="tx-sel-name" style="font-weight:700;color:var(--text);font-size:15px;margin-bottom:2px;"></p>
          <p id="tx-sel-acct" style="font-size:12px;color:var(--text3);font-family:'DM Mono',monospace;"></p>
        </div>
        <button onclick="clearTransferUser()" style="background:var(--bg3);border:none;width:30px;height:30px;border-radius:50%;cursor:pointer;color:var(--text3);font-size:16px;display:flex;align-items:center;justify-content:center;">✕</button>
      </div>
      <input id="tx-recipient" class="send-input" placeholder="Name or 10-digit account number" oninput="searchTransferUser(this.value)">
      <div id="tx-user-results" class="send-search-results"></div>
    </div>

    <!-- Amount -->
    <div class="send-field-wrap">
      <label class="send-field-label">Amount</label>
      <div class="send-quick-amounts">
        ${[50,100,250,500].map(v=>`<button class="send-quick-amt" onclick="document.getElementById('tx-amount-send').value=${v}">$${v}</button>`).join('')}
      </div>
      <div class="send-amount-wrap">
        <span class="send-amount-currency">$</span>
        <input id="tx-amount-send" type="number" class="send-input amount-input" placeholder="0.00">
      </div>
    </div>

    <!-- Note -->
    <div class="send-field-wrap">
      <label class="send-field-label">Note <span style="font-weight:400;text-transform:none;letter-spacing:0;">(optional)</span></label>
      <input id="tx-note" class="send-input" placeholder="What's this for?">
    </div>

    <button class="send-btn-main" id="tx-send-btn" onclick="initiateSend()">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
      Send Money
    </button>

    <!-- International Transfer -->
    <div id="send-intl-panel" style="margin-top:36px;">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;">
        <div style="flex:1;height:1px;background:var(--border);"></div>
        <span style="font-size:12px;font-weight:700;color:var(--text3);letter-spacing:.5px;text-transform:uppercase;">International</span>
        <div style="flex:1;height:1px;background:var(--border);"></div>
      </div>
      <div style="background:rgba(19,82,222,.06);border:1px solid rgba(19,82,222,.15);border-radius:16px;padding:16px 18px;margin-bottom:20px;">
        <p style="font-size:13px;color:#1352DE;font-weight:700;margin-bottom:4px;">🌍 SWIFT / Wire Transfer</p>
        <p style="font-size:12px;color:var(--text2);">BIC: CHSBUSXX &nbsp;·&nbsp; Routing: 021000021</p>
      </div>
      <div class="send-field-wrap">
        <label class="send-field-label">Recipient Name</label>
        <input id="tx-intl-name" class="send-input" placeholder="Full legal name">
      </div>
      <div class="send-field-wrap">
        <label class="send-field-label">IBAN / Account</label>
        <input id="tx-intl-iban" class="send-input" placeholder="IBAN or account number">
      </div>
      <div class="send-field-wrap">
        <label class="send-field-label">Amount (USD)</label>
        <div class="send-amount-wrap">
          <span class="send-amount-currency">$</span>
          <input id="tx-intl-amt" type="number" class="send-input amount-input" placeholder="0.00">
        </div>
      </div>
      <button id="tx-intl-btn" onclick="doIntl()" style="width:100%;padding:16px;border:none;border-radius:16px;cursor:pointer;font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:15px;background:linear-gradient(135deg,#6366f1,#4f46e5);color:#fff;letter-spacing:.2px;box-shadow:0 6px 24px rgba(99,102,241,.3);display:flex;align-items:center;justify-content:center;gap:8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
        Send Internationally
      </button>
    </div>
  </div>
</div>`;
}

// ── REDESIGNED DEPOSIT PAGE ──────────────────────────────────────────────────
function renderDeposit() {
  const u = currentUser;
  return `

<div class="dep-page">
  <div class="dep-hero">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;position:relative;z-index:1;">
      <button onclick="goBack()" style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:12px;padding:9px 14px;color:#fff;cursor:pointer;font-size:13px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;display:flex;align-items:center;gap:6px;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        Back
      </button>
    </div>
    <div class="dep-icon-wrap">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#00C48C" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
    </div>
    <div class="dep-title">Deposit Funds</div>
    <div class="dep-subtitle">Add money to your DrimBank account</div>
    <div class="dep-balance-chip">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.7)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
      <span style="color:rgba(255,255,255,.8);font-size:13px;font-weight:600;">Current: <strong style="color:#fff;">${fmtMoney(u.balance)}</strong></span>
    </div>
  </div>

  <div class="dep-body">
    <!-- Account card -->
    <div class="dep-acct-card">
      <div style="position:relative;z-index:1;">
        <p style="color:rgba(255,255,255,.7);font-size:11px;font-weight:700;letter-spacing:.8px;text-transform:uppercase;margin-bottom:6px;">Your Account Number</p>
        <p style="color:#fff;font-size:22px;font-weight:800;letter-spacing:3px;font-family:'DM Mono',monospace;">${u.accountNumber || '— — —'}</p>
        <p style="color:rgba(255,255,255,.6);font-size:12px;margin-top:6px;">${u.firstName} ${u.lastName} &nbsp;·&nbsp; DrimBank</p>
      </div>
    </div>

    <!-- Amount presets -->
    <div style="margin-bottom:20px;">
      <label class="dep-field-label">Quick Amounts</label>
      <div class="dep-presets">
        ${[100,500,1000,2000].map(v=>`<button class="dep-preset-btn" onclick="document.getElementById('tx-amount-dep').value=${v}">$${v >= 1000 ? (v/1000)+'k' : v}</button>`).join('')}
      </div>
    </div>

    <!-- Amount input -->
    <div style="margin-bottom:24px;">
      <label class="dep-field-label">Deposit Amount (USD)</label>
      <div class="dep-amount-wrap">
        <span class="dep-currency">$</span>
        <input id="tx-amount-dep" type="number" class="dep-input amount-input" placeholder="0.00">
      </div>
      <p style="font-size:12px;color:var(--text3);margin-top:8px;">Free members: max $2,000 per deposit. <span onclick="goScreen('subscription')" style="color:#00C48C;cursor:pointer;font-weight:600;">Upgrade for unlimited →</span></p>
    </div>

    <button class="dep-submit-btn" id="tx-dep-btn" onclick="doDeposit()">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
      Deposit Now
    </button>

    <!-- Info section -->
    <div style="margin-top:36px;">
      <p style="font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:14px;">How it works</p>
      <div style="background:var(--card-bg);border:1px solid var(--border);border-radius:18px;padding:4px 18px;">
        <div class="dep-info-row">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(0,196,140,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00C48C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
          </div>
          <div>
            <p style="font-weight:700;color:var(--text);font-size:14px;margin-bottom:2px;">Instant processing</p>
            <p style="font-size:12px;color:var(--text3);">Funds appear in your balance immediately</p>
          </div>
        </div>
        <div class="dep-info-row">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(0,196,140,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00C48C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          </div>
          <div>
            <p style="font-weight:700;color:var(--text);font-size:14px;margin-bottom:2px;">256-bit encryption</p>
            <p style="font-size:12px;color:var(--text3);">Every deposit is protected end-to-end</p>
          </div>
        </div>
        <div class="dep-info-row">
          <div style="width:36px;height:36px;border-radius:10px;background:rgba(0,196,140,.1);display:flex;align-items:center;justify-content:center;flex-shrink:0;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00C48C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div>
            <p style="font-weight:700;color:var(--text);font-size:14px;margin-bottom:2px;">Email confirmation</p>
            <p style="font-size:12px;color:var(--text3);">Receipt sent to your registered email</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>`;
}

// ── REDESIGNED WITHDRAW PAGE ─────────────────────────────────────────────────
function renderWithdraw() {
  const u = currentUser;
  const isPro = typeof window.isPro === 'function' ? window.isPro(u) : false;
  return `

<div class="wd-page">
  <div class="wd-hero">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;position:relative;z-index:1;">
      <button onclick="goBack()" style="background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.18);border-radius:12px;padding:9px 14px;color:#fff;cursor:pointer;font-size:13px;font-weight:600;font-family:'Plus Jakarta Sans',sans-serif;display:flex;align-items:center;gap:6px;">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
        Back
      </button>
      <div style="width:60px;"></div>
    </div>
    <div class="wd-icon-wrap">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#F87171" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>
    </div>
    <div style="font-size:30px;font-weight:800;color:#fff;letter-spacing:-1px;line-height:1;position:relative;z-index:1;">Withdraw Funds</div>
    <div style="color:rgba(255,255,255,.5);font-size:13px;margin-top:8px;position:relative;z-index:1;">Transfer money out of your account</div>
    <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12);border-radius:20px;padding:6px 14px;margin-top:16px;position:relative;z-index:1;">
      <span style="color:rgba(255,255,255,.7);font-size:13px;font-weight:600;">Balance: <strong style="color:#fff;">${fmtMoney(u.balance)}</strong></span>
    </div>
  </div>

  <div style="padding:32px 20px 100px;max-width:560px;margin:0 auto;">
    ${!isPro ? `
    <div class="wd-pro-gate">
      <div style="width:64px;height:64px;border-radius:20px;background:linear-gradient(135deg,rgba(19,82,222,.15),rgba(19,82,222,.08));border:1.5px solid rgba(19,82,222,.3);display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:28px;">🔒</div>
      <h3 style="font-size:20px;font-weight:800;color:var(--text);margin-bottom:8px;">Pro Feature</h3>
      <p style="font-size:14px;color:var(--text2);margin-bottom:20px;line-height:1.6;">Withdrawals require DrimBank Pro. Upgrade to transfer money out anytime with no restrictions.</p>
      <div style="background:var(--bg3);border-radius:14px;padding:14px 16px;margin-bottom:20px;text-align:left;">
        ${[['📤','Unlimited withdrawals'],['⚡','Instant processing'],['💳','Bank & card transfers'],['🔐','PIN-protected security']].map(([ico,t])=>`<div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-bottom:1px solid var(--border);"><span style="font-size:16px;">${ico}</span><span style="font-size:13px;color:var(--text2);font-weight:500;">${t}</span></div>`).join('')}
      </div>
      <button onclick="goScreen('subscription')" style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Plus Jakarta Sans',sans-serif;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 6px 24px rgba(19,82,222,.3);">👑 Upgrade to Pro</button>
    </div>
    ` : `
    <!-- Balance stats -->
    <div class="wd-balance-stat">
      <div>
        <p style="font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.5px;text-transform:uppercase;margin-bottom:4px;">Available</p>
        <p style="font-size:22px;font-weight:800;color:var(--text);letter-spacing:-.5px;">${fmtMoney(u.balance)}</p>
      </div>
      <div style="width:48px;height:48px;border-radius:14px;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);display:flex;align-items:center;justify-content:center;">
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#EF4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>
      </div>
    </div>

    <!-- Presets -->
    <div style="margin-bottom:20px;">
      <label class="wd-field-label">Quick Amounts</label>
      <div class="wd-presets">
        ${[50,100,200,500].map(v=>`<button class="wd-preset-btn" onclick="document.getElementById('tx-amount-wd').value=${v}">$${v}</button>`).join('')}
      </div>
    </div>

    <!-- Amount -->
    <div style="margin-bottom:24px;">
      <label class="wd-field-label">Withdrawal Amount (USD)</label>
      <div class="wd-amount-wrap">
        <span class="wd-currency">$</span>
        <input id="tx-amount-wd" type="number" class="wd-input amount-input" placeholder="0.00">
      </div>
    </div>

    <button class="wd-submit-btn" id="tx-wd-btn" onclick="doWithdraw()">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
      Withdraw Funds
    </button>

    <div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);border-radius:14px;padding:14px 16px;margin-top:20px;display:flex;gap:12px;align-items:flex-start;">
      <span style="font-size:18px;flex-shrink:0;">⚡</span>
      <p style="font-size:13px;color:#92400E;font-weight:500;line-height:1.5;">Withdrawals are processed instantly. Funds are typically available within 1–3 business days depending on your bank.</p>
    </div>
    `}
  </div>
</div>`;
}

function searchTransferUser(query) {
  const resultsEl = document.getElementById('tx-user-results');
  const selEl = document.getElementById('tx-selected-user');
  if (!query || query.length < 2) { if(resultsEl) resultsEl.style.display='none'; return; }
  // Search all registered users (by name or account number), exclude self
  const q = query.toLowerCase().trim();
  const matches = users.filter(u => {
    if (u.id === currentUser.id) return false;
    const fullName = (u.firstName + ' ' + u.lastName).toLowerCase();
    const acct = (u.accountNumber || '').toLowerCase();
    return fullName.includes(q) || acct.includes(q);
  });
  if (!resultsEl) return;
  if (matches.length === 0) {
    resultsEl.style.display = 'block';
    resultsEl.innerHTML = `<div style="padding:12px;text-align:center;color:var(--text3);font-size:13px;">No users found for "${query}"</div>`;
    return;
  }
  resultsEl.style.display = 'block';
  resultsEl.innerHTML = matches.slice(0, 5).map(u => `
    <div class="user-search-result" onclick="selectTransferUser('${u.id}')">
      <img src="${u.avatar}" style="width:42px;height:42px;border-radius:50%;object-fit:cover;flex-shrink:0;">
      <div style="flex:1;">
        <p style="font-weight:700;color:var(--text);font-size:14px;">${u.firstName} ${u.lastName}</p>
        <p style="font-size:12px;color:var(--text3);font-family:'JetBrains Mono',monospace;">${u.accountNumber}</p>
      </div>
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
    </div>`).join('');
}

function selectTransferUser(userId) {
  const u = users.find(x => x.id === userId);
  if (!u) return;
  foundTransferRecipient = u;
  const inp = document.getElementById('tx-recipient');
  const res = document.getElementById('tx-user-results');
  const sel = document.getElementById('tx-selected-user');
  const selAvatar = document.getElementById('tx-sel-avatar');
  const selName = document.getElementById('tx-sel-name');
  const selAcct = document.getElementById('tx-sel-acct');
  if (inp) inp.style.display = 'none';
  if (res) res.style.display = 'none';
  if (sel) sel.style.display = 'block';
  if (selAvatar) selAvatar.src = u.avatar;
  if (selName) selName.textContent = u.firstName + ' ' + u.lastName;
  if (selAcct) selAcct.textContent = 'Account: ' + u.accountNumber;
}

function clearTransferUser() {
  foundTransferRecipient = null;
  const inp = document.getElementById('tx-recipient');
  const sel = document.getElementById('tx-selected-user');
  if (inp) { inp.style.display = ''; inp.value = ''; }
  if (sel) sel.style.display = 'none';
}

function initiateSend() {
  const u = currentUser;
  // Check PIN exists
  if (!u.transactionPin) { openSetPinModal(); return; }
  // Validate
  const a = parseFloat(document.getElementById('tx-amount-send')?.value);
  const note = document.getElementById('tx-note')?.value || '';
  if (!a || a <= 0) { addToast('Enter a valid amount', 'error'); return; }
  if (a > u.balance) { addToast('Insufficient funds', 'error'); return; }
  // Must have a recipient
  let recipientLabel = document.getElementById('tx-recipient')?.value?.trim() || '';
  if (foundTransferRecipient) recipientLabel = foundTransferRecipient.firstName + ' ' + foundTransferRecipient.lastName;
  if (!recipientLabel && !foundTransferRecipient) { addToast('Enter a recipient name or account number', 'error'); return; }
  // Open payment confirmation
  openPaymentConfirm({ amount: a, recipient: recipientLabel, recipientUser: foundTransferRecipient, note });
}

// ─── Payment Confirmation Modal ───────────────────────────────────────────────
let pendingTransfer = null;
function openPaymentConfirm(details) {
  pendingTransfer = details;
  document.getElementById('pay-confirm-overlay')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'pay-confirm-overlay';
  overlay.className = 'pay-confirm-overlay';
  overlay.innerHTML = `
  <div class="pay-confirm-sheet" onclick="event.stopPropagation()">
    <div style="width:40px;height:4px;border-radius:4px;background:var(--border);margin:0 auto 24px;"></div>
    <!-- Bank-style header -->
    <div style="text-align:center;margin-bottom:24px;">
      <div style="width:68px;height:68px;border-radius:50%;background:linear-gradient(135deg,#1352DE,#00C48C);display:flex;align-items:center;justify-content:center;margin:0 auto 12px;box-shadow:0 8px 24px rgba(19,82,222,.3);">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
      </div>
      <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:var(--text);font-size:20px;margin-bottom:4px;">Confirm Transfer</h3>
      <p style="color:var(--text3);font-size:13px;">Review your payment details before confirming</p>
    </div>
    <!-- Amount -->
    <div style="background:linear-gradient(135deg,rgba(19,82,222,.06),rgba(0,196,140,.04));border:1.5px solid rgba(19,82,222,.15);border-radius:16px;padding:20px;text-align:center;margin-bottom:20px;">
      <p style="font-size:13px;color:var(--text3);font-weight:600;margin-bottom:4px;">TRANSFER AMOUNT</p>
      <p style="font-size:36px;font-weight:800;color:var(--text);font-family:'DM Mono',monospace;">${fmtMoney(details.amount)}</p>
    </div>
    <!-- Details rows -->
    <div style="display:flex;flex-direction:column;gap:0;border:1px solid var(--border);border-radius:14px;overflow:hidden;margin-bottom:20px;">
      <div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid var(--border);">
        <span style="font-size:13px;color:var(--text3);">From</span>
        <span style="font-weight:600;color:var(--text);font-size:13px;">${currentUser.firstName} ${currentUser.lastName}</span>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid var(--border);">
        <span style="font-size:13px;color:var(--text3);">To</span>
        <div style="display:flex;align-items:center;gap:8px;">
          ${details.recipientUser ? `<img src="${details.recipientUser.avatar}" style="width:24px;height:24px;border-radius:50%;object-fit:cover;">` : ''}
          <span style="font-weight:600;color:var(--text);font-size:13px;">${details.recipient}</span>
        </div>
      </div>
      ${details.recipientUser ? `<div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid var(--border);">
        <span style="font-size:13px;color:var(--text3);">Account No.</span>
        <span style="font-weight:600;color:var(--text);font-size:13px;font-family:'JetBrains Mono',monospace;">${details.recipientUser.accountNumber}</span>
      </div>` : ''}
      ${details.note ? `<div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;border-bottom:1px solid var(--border);">
        <span style="font-size:13px;color:var(--text3);">Note</span>
        <span style="font-weight:600;color:var(--text);font-size:13px;">${details.note}</span>
      </div>` : ''}
      <div style="display:flex;justify-content:space-between;align-items:center;padding:13px 16px;">
        <span style="font-size:13px;color:var(--text3);">New Balance</span>
        <span style="font-weight:700;color:#EF4444;font-size:13px;">${fmtMoney(currentUser.balance - details.amount)}</span>
      </div>
    </div>
    <!-- Security notice -->
    <div style="display:flex;align-items:center;gap:8px;padding:12px 14px;background:rgba(0,196,140,.07);border:1px solid rgba(0,196,140,.2);border-radius:10px;margin-bottom:20px;">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#00A677" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      <p style="font-size:12px;color:#00A677;font-weight:600;">Your transaction is secured by DrimBank 256-bit encryption</p>
    </div>
    <!-- Action buttons -->
    <button onclick="openPinVerifyModal()" style="width:100%;padding:16px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:16px;cursor:pointer;box-shadow:0 6px 20px rgba(19,82,222,.4);margin-bottom:10px;">
      🔐 Enter PIN to Confirm
    </button>
    <button onclick="document.getElementById('pay-confirm-overlay')?.remove();pendingTransfer=null;" style="width:100%;padding:14px;border:none;background:none;color:var(--text3);font-family:'Sora',sans-serif;font-weight:600;font-size:14px;cursor:pointer;">
      Cancel
    </button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target===overlay){overlay.remove();pendingTransfer=null;} });
  document.body.appendChild(overlay);
}

// ─── PIN Verification Modal ────────────────────────────────────────────────────
function openPinVerifyModal() {
  document.getElementById('pin-verify-overlay')?.remove();
  let enteredPin = '';
  const overlay = document.createElement('div');
  overlay.id = 'pin-verify-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.9);backdrop-filter:blur(16px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg);border-radius:28px;padding:32px;max-width:360px;width:100%;text-align:center;">
    <div style="font-size:48px;margin-bottom:12px;">🔐</div>
    <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:var(--text);font-size:20px;margin-bottom:6px;">Enter Transaction PIN</h3>
    <p style="color:var(--text3);font-size:13px;margin-bottom:6px;">Enter your 4-digit PIN to authorize payment</p>
    <div style="display:inline-flex;align-items:center;gap:5px;margin-bottom:6px;background:rgba(0,196,140,0.08);border:1px solid rgba(0,196,140,0.2);border-radius:20px;padding:4px 12px;">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#00A677" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      <span style="font-size:11px;font-weight:600;color:#00A677;">Works on all your devices</span>
    </div>
    ${hasBiometricEnrolled() ? `<div id="biometric-tx-btn-wrap" style="margin-bottom:10px;">
      <button onclick="doBiometricTransactionApproval()" style="width:100%;padding:13px;border:none;border-radius:14px;background:linear-gradient(135deg,rgba(19,82,222,.12),rgba(19,82,222,.06));border:1.5px solid rgba(19,82,222,.25);color:var(--blue);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8 2 4.5 5 4 9"/><path d="M4 13c.5 3.5 3.5 6.5 8 7"/><path d="M20 9c-.5-4-4-7-8-7"/><path d="M20 13c-.5 3.5-3.5 6.5-8 7"/><path d="M9 9a3 3 0 0 1 6 0v3a3 3 0 0 1-6 0V9z"/></svg>
        Use Face ID / Fingerprint
      </button>
    </div>` : ''}
    <div id="pin-error" style="display:none;color:#EF4444;font-size:13px;font-weight:600;margin:8px 0;"></div>
    <div class="pin-dots" id="verify-dots">
      <div class="pin-dot" id="vd0"></div>
      <div class="pin-dot" id="vd1"></div>
      <div class="pin-dot" id="vd2"></div>
      <div class="pin-dot" id="vd3"></div>
    </div>
    <div class="pin-pad">
      ${[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k => `
        <button class="pin-key" onclick="verifyPinKey('${k}')" ${k===''?'style="background:transparent;border:none;cursor:default;"':''}>
          ${k}
        </button>`).join('')}
    </div>
    <button onclick="document.getElementById('pin-verify-overlay')?.remove()" style="margin-top:16px;background:none;border:none;color:var(--text3);font-family:'Sora',sans-serif;font-weight:600;font-size:13px;cursor:pointer;">Cancel</button>
  </div>`;
  document.body.appendChild(overlay);

  window._verifyPin = '';
  window.verifyPinKey = function(k) {
    if (k === '⌫') { window._verifyPin = window._verifyPin.slice(0,-1); }
    else if (k !== '' && window._verifyPin.length < 4) { window._verifyPin += k; }
    // Update dots
    for(let i=0;i<4;i++){
      const d=document.getElementById('vd'+i);
      if(d) d.classList.toggle('filled', i < window._verifyPin.length);
    }
    if(window._verifyPin.length === 4) {
      setTimeout(() => {
        if(window._verifyPin === currentUser.transactionPin) {
          document.getElementById('pin-verify-overlay')?.remove();
          document.getElementById('pay-confirm-overlay')?.remove();
          executeTransfer(pendingTransfer);
        } else {
          window._verifyPin = '';
          for(let i=0;i<4;i++){const d=document.getElementById('vd'+i);if(d)d.classList.remove('filled');}
          const err = document.getElementById('pin-error');
          if(err){err.style.display='block';err.textContent='❌ Incorrect PIN. Try again.';}
        }
      }, 200);
    }
  };
}

async function executeTransfer(details) {
  if (!details) return;
  const { amount, recipient, recipientUser, note } = details;
  // Debit sender
  const txDebit = {id:uid(),type:'debit',desc:`Transfer to ${recipient}`,amount:-amount,date:new Date().toISOString(),category:'Transfer',note:note||''};
  await updateCurrentUser(u=>({...u,balance:u.balance-amount,transactions:[txDebit,...(u.transactions||[])]}));
  // Credit recipient if they're a registered user
  if (recipientUser) {
    const idx = users.findIndex(x=>x.id===recipientUser.id);
    if (idx>=0) {
      const txCredit = {id:uid(),type:'credit',desc:`Transfer from ${currentUser.firstName} ${currentUser.lastName}`,amount:amount,date:new Date().toISOString(),category:'Transfer',note:note||''};
      users[idx] = {...users[idx], balance:(users[idx].balance||0)+amount, transactions:[txCredit,...(users[idx].transactions||[])]};
      saveUsers();
    }
  }
  sendTransactionEmail({
    to:              currentUser.email,
    userName:        currentUser.firstName + ' ' + currentUser.lastName,
    eventTitle:      'Money Sent!',
    eventSubtitle:   'Your transfer has been processed successfully.',
    eventMessage:    'Your transfer has been completed. Here are the details of your transaction below.',
    transactionType: 'Transfer',
    amount:          fmtMoney(amount),
    recipientName:   recipient,
    newBalance:      fmtMoney(currentUser.balance - amount),
    date:            _fmtDate(txDebit.date),
  });
  addToast(`✅ ${fmtMoney(amount)} sent to ${recipient}!`,'success');
  pendingTransfer = null;
  foundTransferRecipient = null;
  goScreen('dashboard');
  setTimeout(()=>goScreen('transfer'),150);
}

// ─── Set Transaction PIN ───────────────────────────────────────────────────────
function openSetPinModal() {
  document.getElementById('set-pin-overlay')?.remove();
  let newPin = '';
  let confirmPin = '';
  let step = 1;
  const overlay = document.createElement('div');
  overlay.id = 'set-pin-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.9);backdrop-filter:blur(16px);z-index:4000;display:flex;align-items:center;justify-content:center;padding:20px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg);border-radius:28px;padding:32px;max-width:360px;width:100%;text-align:center;">
    <div style="font-size:48px;margin-bottom:12px;">🔐</div>
    <h3 id="set-pin-title" style="font-family:'Sora',sans-serif;font-weight:800;color:var(--text);font-size:20px;margin-bottom:6px;">Create Transaction PIN</h3>
    <p id="set-pin-sub" style="color:var(--text3);font-size:13px;margin-bottom:4px;">Choose a secure 4-digit PIN for transfers</p>
    <div style="display:inline-flex;align-items:center;gap:5px;margin-bottom:8px;background:rgba(0,196,140,0.08);border:1px solid rgba(0,196,140,0.2);border-radius:20px;padding:4px 12px;">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#00A677" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      <span style="font-size:11px;font-weight:600;color:#00A677;">Synced across all your devices</span>
    </div>
    <div id="set-pin-err" style="display:none;color:#EF4444;font-size:13px;font-weight:600;margin:8px 0;"></div>
    <div class="pin-dots" id="set-dots">
      <div class="pin-dot" id="sd0"></div>
      <div class="pin-dot" id="sd1"></div>
      <div class="pin-dot" id="sd2"></div>
      <div class="pin-dot" id="sd3"></div>
    </div>
    <div class="pin-pad">
      ${[1,2,3,4,5,6,7,8,9,'',0,'⌫'].map(k=>`
        <button class="pin-key" onclick="setPinKey('${k}')" ${k===''?'style="background:transparent;border:none;cursor:default;"':''}>
          ${k}
        </button>`).join('')}
    </div>
    <button onclick="document.getElementById('set-pin-overlay')?.remove()" style="margin-top:16px;background:none;border:none;color:var(--text3);font-family:'Sora',sans-serif;font-weight:600;font-size:13px;cursor:pointer;">Cancel</button>
  </div>`;
  document.body.appendChild(overlay);

  window._newPin = '';
  window._confirmPin = '';
  window._pinStep = 1;

  window.setPinKey = function(k) {
    const dots = [document.getElementById('sd0'),document.getElementById('sd1'),document.getElementById('sd2'),document.getElementById('sd3')];
    if (k==='⌫') {
      if(window._pinStep===1) window._newPin = window._newPin.slice(0,-1);
      else window._confirmPin = window._confirmPin.slice(0,-1);
    } else if(k!=='') {
      if(window._pinStep===1 && window._newPin.length < 4) window._newPin += k;
      else if(window._pinStep===2 && window._confirmPin.length < 4) window._confirmPin += k;
    }
    const cur = window._pinStep===1 ? window._newPin : window._confirmPin;
    dots.forEach((d,i)=>{if(d)d.classList.toggle('filled', i<cur.length);});
    // Step complete
    if(cur.length===4) {
      if(window._pinStep===1) {
        setTimeout(()=>{
          window._pinStep = 2;
          window._confirmPin = '';
          dots.forEach(d=>{if(d)d.classList.remove('filled');});
          document.getElementById('set-pin-title').textContent = 'Confirm Your PIN';
          document.getElementById('set-pin-sub').textContent = 'Re-enter your 4-digit PIN to confirm';
        },300);
      } else {
        setTimeout(()=>{
          if(window._newPin === window._confirmPin) {
            updateCurrentUser(u=>({...u, transactionPin: window._newPin}));
            document.getElementById('set-pin-overlay')?.remove();
            addToast('✅ Transaction PIN created successfully!','success');
            goScreen('transfer');
          } else {
            window._newPin=''; window._confirmPin=''; window._pinStep=1;
            dots.forEach(d=>{if(d)d.classList.remove('filled');});
            document.getElementById('set-pin-title').textContent = 'Create Transaction PIN';
            document.getElementById('set-pin-sub').textContent = 'Choose a secure 4-digit PIN for transfers';
            const err=document.getElementById('set-pin-err');
            if(err){err.style.display='block';err.textContent='❌ PINs don\'t match. Try again.';}
          }
        },300);
      }
    }
  };
}

function showTxDone(ref) {
  const el=$('tx-done');
  if(el){el.style.display='block';el.innerHTML=`<p style="color:#00C48C;font-weight:700;">✅ Transaction completed! Ref: ${ref}</p>`;}
}
function setLoading(btn, loading, label) {
  const el=$(btn);
  if(!el)return;
  el.disabled=loading;
  el.innerHTML=loading?'<span class="spinner"></span>Processing...':label;
}
async function doSend() { initiateSend(); }
async function doDeposit() {
  const a = parseFloat($('tx-amount-dep')?.value);
  if (!a || a <= 0) { addToast('Enter valid amount', 'error'); return; }
  if (a > 2000 && !isPro(currentUser)) {
    goScreen('subscription');
    addToast('💰 Deposits over $2,000 require DrimBank Pro', 'info');
    return;
  }
  const btn = $('tx-dep-btn');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span>Processing...'; }

  await new Promise(r => setTimeout(r, 1200));

  const tx = { id: uid(), type: 'credit', desc: 'Deposit', amount: a, date: new Date().toISOString(), category: 'Income' };
  currentUser = { ...currentUser, balance: currentUser.balance + a, transactions: [tx, ...(currentUser.transactions || [])] };
  const idx = users.findIndex(u => u.id === currentUser.id);
  if (idx >= 0) users[idx] = currentUser;

  // Save to localStorage immediately (instant, never fails)
  try { localStorage.setItem('drimbank_users_cache', JSON.stringify(users)); } catch(_) {}

  // ── Save via saveUsers (handles Firestore + localStorage, awaited) ──
  if (btn) { btn.innerHTML = '<span class="spinner"></span>Syncing...'; }
  await saveUsers();

  // Fire email in background — never blocks UI
  sendTransactionEmail({
    to:              currentUser.email,
    userName:        currentUser.firstName + ' ' + currentUser.lastName,
    eventTitle:      'Deposit Successful!',
    eventSubtitle:   'Your account balance has been updated.',
    eventMessage:    'A deposit has been recorded on your DrimBank account. Please review the details below.',
    transactionType: 'Deposit',
    amount:          fmtMoney(a),
    recipientName:   'Self',
    newBalance:      fmtMoney(currentUser.balance),
    date:            _fmtDate(new Date().toISOString()),
  });

  addToast('✅ Deposit successful!', 'success');
  if (btn) { btn.disabled = false; btn.innerHTML = 'Deposit Now'; }
  if ($('tx-amount-dep')) $('tx-amount-dep').value = '';
}

async function doWithdraw() {
  if(!isPro(currentUser)) {
    goScreen('subscription');
    return;
  }
  openWithdrawalModal();
}
async function doIntl() {
  const name=$('tx-intl-name')?.value, iban=$('tx-intl-iban')?.value, a=parseFloat($('tx-intl-amt')?.value);
  if(!name||!iban||!a||a<=0){addToast('Fill all fields','error');return;}
  if(a>currentUser.balance){addToast('Insufficient funds','error');return;}
  setLoading('tx-intl-btn',true,'');
  await new Promise(r=>setTimeout(r,1600));
  const tx={id:uid(),type:'debit',desc:`Intl Transfer to ${name}`,amount:-a,date:new Date().toISOString(),category:'Transfer'};
  await updateCurrentUser(u=>({...u,balance:u.balance-a,transactions:[tx,...(u.transactions||[])]}));
  addToast('International transfer sent!','success');
  setLoading('tx-intl-btn',false,'Send Internationally 🌍');
}

// ─── Cards ───────────────────────────────────────────────────────────────────
function buildDrimCard(c) {
  const isVisa = c.type === 'Visa';
  const isMC   = c.type === 'Mastercard';
  const frozen = c.frozen;

  /* ══════════════════════════════════════════════════════════════════════════
     DRIM LOGO MARK
     Top-left & bottom-right = solid lighter blue; top-right & bottom-left = same
     The distinctive "C" octagon with interior quadrant shading
  ══════════════════════════════════════════════════════════════════════════ */
  const drimLogoMark = (size=40, color='rgba(100,185,255,0.92)') => `
    <svg width="${size}" height="${size}" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <!-- Octagon outline path -->
      <path d="M20 1 L39 9 V31 L20 39 L1 31 V9 Z" fill="none"/>
      <!-- Four quadrant squares arranged in a 2x2 grid — outer two solid, inner two transparent -->
      <!-- Top-left solid -->
      <rect x="5" y="5" width="13" height="13" rx="1.5" fill="${color}"/>
      <!-- Top-right transparent (gap) -->
      <rect x="22" y="5" width="13" height="13" rx="1.5" fill="rgba(255,255,255,0.0)"/>
      <!-- Bottom-left transparent (gap) -->
      <rect x="5" y="22" width="13" height="13" rx="1.5" fill="rgba(255,255,255,0.0)"/>
      <!-- Bottom-right solid -->
      <rect x="22" y="22" width="13" height="13" rx="1.5" fill="${color}"/>
    </svg>`;

  /* DrimBank logo: "CHASE ◫" text + the actual 4-square octagon mark side by side */
  const drimLogoVisa = `
    <div style="display:flex;align-items:center;gap:6px;">
      <span style="color:#fff;font-family:Arial,sans-serif;font-weight:700;font-size:15px;letter-spacing:0.5px;text-shadow:0 1px 3px rgba(0,0,0,0.3);">CHASE</span>
      ${drimLogoMark(28,'rgba(130,200,255,0.9)')}
    </div>`;

  const drimLogoMC = `
    <div style="display:flex;align-items:center;gap:6px;">
      <span style="color:#fff;font-family:Arial,sans-serif;font-weight:700;font-size:15px;letter-spacing:0.5px;text-shadow:0 1px 3px rgba(0,0,0,0.4);">CHASE</span>
      ${drimLogoMark(28,'rgba(130,200,255,0.88)')}
    </div>`;

  /* ══════════════════════════════════════════════════════════════════════════
     EMV CHIP — detailed gold chip matching reference photo
  ══════════════════════════════════════════════════════════════════════════ */
  const chip = `<svg width="44" height="35" viewBox="0 0 44 35" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect width="44" height="35" rx="5" fill="url(#chipGrad)"/>
    <defs>
      <linearGradient id="chipGrad" x1="0" y1="0" x2="44" y2="35" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stop-color="#D4AA50"/>
        <stop offset="40%" stop-color="#C8983C"/>
        <stop offset="100%" stop-color="#A07828"/>
      </linearGradient>
    </defs>
    <!-- outer border -->
    <rect x="1" y="1" width="42" height="33" rx="4" fill="none" stroke="#8A6010" stroke-width="0.6"/>
    <!-- horizontal grooves -->
    <line x1="0" y1="11.5" x2="44" y2="11.5" stroke="#8A6010" stroke-width="0.8"/>
    <line x1="0" y1="23.5" x2="44" y2="23.5" stroke="#8A6010" stroke-width="0.8"/>
    <!-- vertical grooves -->
    <line x1="14.5" y1="0" x2="14.5" y2="35" stroke="#8A6010" stroke-width="0.8"/>
    <line x1="29.5" y1="0" x2="29.5" y2="35" stroke="#8A6010" stroke-width="0.8"/>
    <!-- center module highlight -->
    <rect x="15.5" y="12.5" width="13" height="10" rx="1.5" fill="#B88820"/>
    <rect x="17" y="13.8" width="10" height="7.4" rx="1" fill="#D4AA50"/>
    <rect x="18.5" y="15" width="7" height="5" rx="0.5" fill="#C09030"/>
  </svg>`;

  /* ══════════════════════════════════════════════════════════════════════════
     NFC SYMBOL — matching reference photo (3 curved arcs)
  ══════════════════════════════════════════════════════════════════════════ */
  const nfc = `<svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M10 13 Q13 9.5 16 13" stroke="rgba(255,255,255,0.9)" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <path d="M7 13 Q13 5.5 19 13" stroke="rgba(255,255,255,0.72)" stroke-width="1.8" fill="none" stroke-linecap="round"/>
    <path d="M4 13 Q13 1.5 22 13" stroke="rgba(255,255,255,0.5)" stroke-width="1.8" fill="none" stroke-linecap="round"/>
  </svg>`;

  /* ══════════════════════════════════════════════════════════════════════════
     VISA LOGO — italic serif block matching real Visa card typography
  ══════════════════════════════════════════════════════════════════════════ */
  const visaLogo = `<svg width="70" height="24" viewBox="0 0 70 24" xmlns="http://www.w3.org/2000/svg">
    <text x="0" y="21" font-family="Times New Roman,serif" font-weight="900" font-size="26"
      fill="white" font-style="italic" letter-spacing="-1">VISA</text>
  </svg>`;

  /* ══════════════════════════════════════════════════════════════════════════
     MASTERCARD LOGO — two overlapping circles + "MasterCard" text below
     Exact match: large red left circle, orange right circle, overlap = orange-red
  ══════════════════════════════════════════════════════════════════════════ */
  const mcLogo = `<svg width="80" height="52" viewBox="0 0 80 52" xmlns="http://www.w3.org/2000/svg">
    <circle cx="27" cy="20" r="18" fill="#EB001B"/>
    <circle cx="53" cy="20" r="18" fill="#F79E1B"/>
    <!-- overlap blend -->
    <path d="M40 5.2 Q52 12 52 20 Q52 28 40 34.8 Q28 28 28 20 Q28 12 40 5.2Z" fill="#FF5F00"/>
    <!-- MasterCard text -->
    <text x="40" y="48" font-family="Arial,sans-serif" font-weight="800" font-size="9.5"
      fill="white" text-anchor="middle" letter-spacing="0.3">MasterCard</text>
  </svg>`;

  /* ══════════════════════════════════════════════════════════════════════════
     AMEX LOGO
  ══════════════════════════════════════════════════════════════════════════ */
  const amexLogo = `<svg width="60" height="20" viewBox="0 0 60 20" xmlns="http://www.w3.org/2000/svg">
    <text x="0" y="15" font-family="Arial,sans-serif" font-weight="900" font-size="14"
      fill="white" letter-spacing="1.5">AMEX</text>
  </svg>`;

  /* ══════════════════════════════════════════════════════════════════════════
     VISA CARD DESIGN
     Reference: solid cobalt/royal blue, horizontal fine brushed-metal lines
     CHASE + logo top-left, octagon mark top-right large
     Chip + NFC mid-left, embossed number below
     Name bottom-left, GOOD THRU center, DEBIT + VISA bottom-right
  ══════════════════════════════════════════════════════════════════════════ */
  if (isVisa) {
    return `
    <div style="position:relative;border-radius:16px;overflow:hidden;aspect-ratio:1.586;margin-bottom:8px;box-shadow:0 12px 40px rgba(0,0,0,0.45),0 3px 10px rgba(0,0,0,0.25),inset 0 1px 0 rgba(255,255,255,0.15);${frozen?'filter:grayscale(.6) brightness(.65);':''}" >

      <!-- BASE: cobalt blue background -->
      <div style="position:absolute;inset:0;background:linear-gradient(175deg,#2060c8 0%,#1752be 20%,#1248aa 50%,#0e3d98 75%,#0b3285 100%);"></div>

      <!-- TEXTURE: fine horizontal brushed-metal lines (matching reference photo exactly) -->
      <div style="position:absolute;inset:0;background:repeating-linear-gradient(
        180deg,
        rgba(255,255,255,0.000) 0px,
        rgba(255,255,255,0.000) 2px,
        rgba(255,255,255,0.028) 2px,
        rgba(255,255,255,0.028) 3px
      );pointer-events:none;"></div>

      <!-- SHEEN: diagonal highlight sweep top-left to mid -->
      <div style="position:absolute;inset:0;background:linear-gradient(120deg,rgba(255,255,255,0.12) 0%,rgba(255,255,255,0.04) 40%,transparent 65%);pointer-events:none;"></div>

      <!-- FROZEN overlay -->
      ${frozen ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,0.35);z-index:10;display:flex;align-items:center;justify-content:center;"><span style="background:rgba(239,68,68,0.9);color:#fff;font-size:12px;font-weight:700;padding:6px 16px;border-radius:20px;font-family:\'Sora\',sans-serif;letter-spacing:1px;">🔒 FROZEN</span></div>' : ''}

      <!-- CARD CONTENT -->
      <div style="position:relative;z-index:1;padding:18px 22px;height:100%;display:flex;flex-direction:column;justify-content:space-between;">

        <!-- TOP ROW: "CHASE ◫" left, large octagon mark right -->
        <div style="display:flex;justify-content:space-between;align-items:flex-start;">
          ${drimLogoVisa}
          <!-- Large standalone DrimBank octagon mark (top-right) -->
          ${drimLogoMark(44,'rgba(120,195,255,0.88)')}
        </div>

        <!-- MIDDLE: chip + NFC, then embossed card number -->
        <div>
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
            ${chip}
            ${nfc}
          </div>
          <!-- Embossed card number — raised look matching reference -->
          <p style="color:#fff;font-family:'JetBrains Mono',monospace;font-size:20px;letter-spacing:4px;font-weight:500;margin:0;text-shadow:0 2px 6px rgba(0,0,0,0.5),0 -1px 0 rgba(255,255,255,0.15);">${c.number}</p>
        </div>

        <!-- BOTTOM ROW -->
        <div style="display:flex;justify-content:space-between;align-items:flex-end;">
          <!-- Left: cardholder name -->
          <div>
            <p style="color:#fff;font-family:Arial,sans-serif;font-weight:700;font-size:13px;letter-spacing:1.5px;text-transform:uppercase;text-shadow:0 1px 4px rgba(0,0,0,0.4);margin:0 0 4px 0;">${c.name}</p>
            <div style="display:flex;align-items:center;gap:16px;">
              <div>
                <p style="color:rgba(255,255,255,0.6);font-size:7px;font-family:Arial,sans-serif;letter-spacing:0.5px;margin:0 0 1px 0;">GOOD<br>THRU</p>
              </div>
              <p style="color:#fff;font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:600;text-shadow:0 1px 3px rgba(0,0,0,0.4);margin:0;">${c.expiry}</p>
            </div>
          </div>
          <!-- Right: DEBIT label + VISA italic -->
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;">
            <span style="color:rgba(255,255,255,0.85);font-size:10px;font-family:Arial,sans-serif;font-weight:700;letter-spacing:2px;">DEBIT</span>
            ${visaLogo}
          </div>
        </div>

      </div>
    </div>
    <div style="display:flex;gap:10px;margin-bottom:8px;">
      <button onclick="toggleCardFreeze('${c.id}')" style="flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:9px 0;color:var(--text2);cursor:pointer;font-size:13px;font-family:'Sora',sans-serif;font-weight:600;">${c.frozen?'🔓 Unfreeze Card':'🔒 Freeze Card'}</button>
    </div>
    <div style="display:flex;align-items:center;justify-content:space-between;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:10px 16px;margin-bottom:20px;">
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="font-size:12px;font-weight:700;color:var(--text2);letter-spacing:.5px;">CVV</span>
        <span id="cvv-val-${c.id}" style="font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:700;color:var(--text);letter-spacing:3px;">•••</span>
      </div>
      <button onclick="toggleCVV('${c.id}','${c.cvv}')" id="cvv-btn-${c.id}" style="background:var(--blue);color:#fff;border:none;border-radius:7px;padding:5px 12px;font-size:12px;font-family:'Sora',sans-serif;font-weight:700;cursor:pointer;">Show</button>
    </div>`;
  }

  /* ══════════════════════════════════════════════════════════════════════════
     MASTERCARD CARD DESIGN
     Reference: dark navy/teal, large cyan circular orb upper-right quadrant
     CHASE + logo top-right (right-aligned), no EMV chip visible
     Large embossed number center, GOOD THRU center-left
     "Debit" text + MasterCard overlapping circles logo bottom-right
  ══════════════════════════════════════════════════════════════════════════ */
  if (isMC) {
    return `
    <div style="position:relative;border-radius:16px;overflow:hidden;aspect-ratio:1.586;margin-bottom:8px;box-shadow:0 12px 40px rgba(0,0,0,0.5),0 3px 10px rgba(0,0,0,0.3),inset 0 1px 0 rgba(255,255,255,0.08);${frozen?'filter:grayscale(.6) brightness(.65);':''}" >

      <!-- BASE: deep navy background -->
      <div style="position:absolute;inset:0;background:linear-gradient(155deg,#0d2d4e 0%,#0f3560 30%,#0b2a4c 60%,#081e38 100%);"></div>

      <!-- LARGE TEAL/CYAN SPHERE — top-right quadrant, the defining feature of this card -->
      <div style="position:absolute;top:-55%;right:-20%;width:90%;height:200%;border-radius:50%;background:radial-gradient(circle at 38% 38%,
        rgba(40,175,210,0.75) 0%,
        rgba(25,145,185,0.60) 25%,
        rgba(15,110,160,0.40) 50%,
        rgba(10,70,120,0.18) 70%,
        transparent 85%
      );pointer-events:none;"></div>

      <!-- SUBTLE TEXTURE: very fine vertical lines matching reference -->
      <div style="position:absolute;inset:0;background:repeating-linear-gradient(
        90deg,
        rgba(255,255,255,0.000) 0px,
        rgba(255,255,255,0.000) 4px,
        rgba(255,255,255,0.015) 4px,
        rgba(255,255,255,0.015) 5px
      );pointer-events:none;"></div>

      <!-- FROZEN overlay -->
      ${frozen ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,0.35);z-index:10;display:flex;align-items:center;justify-content:center;"><span style="background:rgba(239,68,68,0.9);color:#fff;font-size:12px;font-weight:700;padding:6px 16px;border-radius:20px;font-family:\'Sora\',sans-serif;letter-spacing:1px;">🔒 FROZEN</span></div>' : ''}

      <!-- CARD CONTENT -->
      <div style="position:relative;z-index:1;padding:18px 22px;height:100%;display:flex;flex-direction:column;justify-content:space-between;">

        <!-- TOP ROW: right-aligned CHASE logo (matching reference photo) -->
        <div style="display:flex;justify-content:flex-end;align-items:flex-start;">
          ${drimLogoMC}
        </div>

        <!-- MIDDLE: large embossed card number (no chip on MC reference) -->
        <div>
          <p style="color:#fff;font-family:'JetBrains Mono',monospace;font-size:21px;letter-spacing:4px;font-weight:500;margin:0 0 6px 0;text-shadow:0 2px 8px rgba(0,0,0,0.6),0 -1px 0 rgba(255,255,255,0.1);">${c.number}</p>
          <!-- Sub-line: first 4 digits repeated (matching reference's second row) -->
          <p style="color:rgba(255,255,255,0.5);font-family:'JetBrains Mono',monospace;font-size:10px;letter-spacing:2px;margin:0;">${c.number.split(' ')[0]}</p>
        </div>

        <!-- BOTTOM ROW -->
        <div style="display:flex;justify-content:space-between;align-items:flex-end;">
          <!-- Left: cardholder name + GOOD THRU + expiry -->
          <div>
            <p style="color:#fff;font-family:Arial,sans-serif;font-weight:700;font-size:12px;letter-spacing:1.5px;text-transform:uppercase;text-shadow:0 1px 4px rgba(0,0,0,0.4);margin:0 0 5px 0;">${c.name}</p>
            <div style="display:flex;align-items:center;gap:8px;">
              <div style="text-align:right;">
                <p style="color:rgba(255,255,255,0.55);font-size:6.5px;font-family:Arial,sans-serif;letter-spacing:0.3px;margin:0;line-height:1.3;">GOOD<br>THRU</p>
              </div>
              <p style="color:#fff;font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:600;text-shadow:0 1px 4px rgba(0,0,0,0.5);margin:0;">${c.expiry}</p>
            </div>
          </div>
          <!-- Right: Debit label + MasterCard logo -->
          <div style="display:flex;flex-direction:column;align-items:flex-end;gap:0;">
            <span style="color:rgba(255,255,255,0.85);font-size:10px;font-family:Arial,sans-serif;font-weight:700;letter-spacing:1.5px;margin-bottom:-4px;">Debit</span>
            ${mcLogo}
          </div>
        </div>

      </div>
    </div>
    <div style="display:flex;gap:10px;margin-bottom:8px;">
      <button onclick="toggleCardFreeze('${c.id}')" style="flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:9px 0;color:var(--text2);cursor:pointer;font-size:13px;font-family:'Sora',sans-serif;font-weight:600;">${c.frozen?'🔓 Unfreeze Card':'🔒 Freeze Card'}</button>
    </div>
    <div style="display:flex;align-items:center;justify-content:space-between;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:10px 16px;margin-bottom:20px;">
      <div style="display:flex;align-items:center;gap:8px;">
        <span style="font-size:12px;font-weight:700;color:var(--text2);letter-spacing:.5px;">CVV</span>
        <span id="cvv-val-${c.id}" style="font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:700;color:var(--text);letter-spacing:3px;">•••</span>
      </div>
      <button onclick="toggleCVV('${c.id}','${c.cvv}')" id="cvv-btn-${c.id}" style="background:var(--blue);color:#fff;border:none;border-radius:7px;padding:5px 12px;font-size:12px;font-family:'Sora',sans-serif;font-weight:700;cursor:pointer;">Show</button>
    </div>`;
  }

  /* ══════════════════════════════════════════════════════════════════════════
     AMEX CARD DESIGN (fallback for Amex type)
  ══════════════════════════════════════════════════════════════════════════ */
  return `
  <div style="position:relative;border-radius:16px;overflow:hidden;aspect-ratio:1.586;margin-bottom:8px;box-shadow:0 12px 40px rgba(0,0,0,0.45),0 3px 10px rgba(0,0,0,0.25);${frozen?'filter:grayscale(.6) brightness(.65);':''}" >
    <div style="position:absolute;inset:0;background:linear-gradient(145deg,#1c2f42 0%,#253a52 50%,#1c2e40 100%);"></div>
    <div style="position:absolute;top:-30%;right:-20%;width:70%;height:120%;border-radius:50%;background:radial-gradient(circle,rgba(80,180,200,0.18) 0%,transparent 70%);pointer-events:none;"></div>
    ${frozen ? '<div style="position:absolute;inset:0;background:rgba(0,0,0,0.35);z-index:10;display:flex;align-items:center;justify-content:center;"><span style="background:rgba(239,68,68,0.9);color:#fff;font-size:12px;font-weight:700;padding:6px 16px;border-radius:20px;font-family:\'Sora\',sans-serif;">🔒 FROZEN</span></div>' : ''}
    <div style="position:relative;z-index:1;padding:18px 22px;height:100%;display:flex;flex-direction:column;justify-content:space-between;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        ${drimLogoVisa}
        ${drimLogoMark(38,'rgba(120,195,255,0.85)')}
      </div>
      <div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">${chip}${nfc}</div>
        <p style="color:#fff;font-family:'JetBrains Mono',monospace;font-size:20px;letter-spacing:4px;font-weight:500;margin:0;text-shadow:0 2px 6px rgba(0,0,0,0.5);">${c.number}</p>
      </div>
      <div style="display:flex;justify-content:space-between;align-items:flex-end;">
        <div>
          <p style="color:#fff;font-family:Arial,sans-serif;font-weight:700;font-size:13px;letter-spacing:1.5px;text-transform:uppercase;margin:0 0 4px 0;">${c.name}</p>
          <div style="display:flex;align-items:center;gap:10px;">
            <p style="color:rgba(255,255,255,0.55);font-size:7px;font-family:Arial,sans-serif;margin:0;">GOOD THRU</p>
            <p style="color:#fff;font-family:'JetBrains Mono',monospace;font-size:13px;font-weight:600;margin:0;">${c.expiry}</p>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:3px;">
          <span style="color:rgba(255,255,255,0.8);font-size:10px;font-family:Arial,sans-serif;font-weight:700;letter-spacing:2px;">DEBIT</span>
          ${amexLogo}
        </div>
      </div>
    </div>
  </div>
  <div style="display:flex;gap:10px;margin-bottom:8px;">
    <button onclick="toggleCardFreeze('${c.id}')" style="flex:1;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:9px 0;color:var(--text2);cursor:pointer;font-size:13px;font-family:'Sora',sans-serif;font-weight:600;">${c.frozen?'🔓 Unfreeze Card':'🔒 Freeze Card'}</button>
  </div>
  <div style="display:flex;align-items:center;justify-content:space-between;background:var(--bg3);border:1px solid var(--border);border-radius:10px;padding:10px 16px;margin-bottom:20px;">
    <div style="display:flex;align-items:center;gap:8px;">
      <span style="font-size:12px;font-weight:700;color:var(--text2);letter-spacing:.5px;">CVV</span>
      <span id="cvv-val-${c.id}" style="font-family:'JetBrains Mono',monospace;font-size:14px;font-weight:700;color:var(--text);letter-spacing:3px;">•••</span>
    </div>
    <button onclick="toggleCVV('${c.id}','${c.cvv}')" id="cvv-btn-${c.id}" style="background:var(--blue);color:#fff;border:none;border-radius:7px;padding:5px 12px;font-size:12px;font-family:'Sora',sans-serif;font-weight:700;cursor:pointer;">Show</button>
  </div>`;
}

function renderCards() {
  const u=currentUser;
  const cardItems=(u.cards||[]).map(c=>buildDrimCard(c)).join('');

  return `<div style="padding:24px 20px;max-width:560px;margin:0 auto;">
    ${backBtn()}
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
      <div><h2 style="font-size:22px;font-weight:800;color:var(--text);">My Cards</h2><p style="color:var(--text3);font-size:14px;">${u.cards?.length||0} active cards</p></div>
      <button class="btn btn-primary btn-sm" onclick="openAddCardModal()">+ Add Card</button>
    </div>
    ${(u.cards||[]).length===0?`<div style="text-align:center;padding:60px;color:var(--text3);"><div style="font-size:48px;">💳</div><p style="margin-top:12px;font-weight:600;">No cards yet</p><p style="font-size:14px;margin-top:4px;">Add a virtual card to get started</p></div>`:cardItems}

    <!-- Add Card Modal -->
    <div id="add-card-modal" style="display:none;" class="modal-overlay" onclick="closeAddCardModal()">
      <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
          <span class="modal-title">Add Card</span>
          <button class="modal-close" onclick="closeAddCardModal()">×</button>
        </div>
        <!-- Card mode toggle -->
        <div style="display:flex;gap:8px;margin-bottom:20px;">
          <button id="card-mode-new" onclick="setCardMode('new')" style="flex:1;padding:10px;border-radius:10px;border:2px solid var(--blue);background:rgba(19,82,222,.08);cursor:pointer;font-family:'Sora',sans-serif;font-weight:600;color:var(--blue);font-size:13px;">🆕 New Virtual</button>
          <button id="card-mode-existing" onclick="${isPro(currentUser) ? "setCardMode('existing')" : 'goScreen(\'subscription\')'}" style="flex:1;padding:10px;border-radius:10px;border:2px solid var(--border);background:var(--bg3);cursor:pointer;font-family:'Sora',sans-serif;font-weight:600;color:var(--text2);font-size:13px;">${isPro(currentUser) ? '💳 Add Existing' : '🔒 Add Existing'}</button>
        </div>

        <!-- New Virtual Card form -->
        <div id="card-form-new" style="display:flex;flex-direction:column;gap:16px;">
          <div class="input-group"><label>Cardholder Name</label><input id="card-name" value="${u.firstName} ${u.lastName}"></div>
          <div>
            <label style="font-size:13px;font-weight:600;color:var(--text2);margin-bottom:6px;display:block;">Card Network</label>
            <div style="display:flex;gap:10px;" id="card-type-btns">
              ${['Visa','Mastercard','Amex'].map((t,i)=>`<button onclick="selectCardType('${t}')" id="ct-${t}" style="flex:1;padding:10px;border-radius:10px;border:2px solid ${i===0?'#1352DE':'var(--border)'};background:${i===0?'rgba(19,82,222,.06)':'var(--bg3)'};cursor:pointer;font-family:'Sora',sans-serif;font-weight:600;color:${i===0?'#1352DE':'var(--text2)'};font-size:13px;">${t}</button>`).join('')}
            </div>
          </div>
          <div style="padding:14px;background:var(--bg3);border-radius:12px;">
            <p style="font-size:12px;color:var(--text3);">Card details will be emailed to <strong>${u.email}</strong></p>
          </div>
          <button class="btn btn-primary btn-full" id="create-card-btn" onclick="createCard()">Create Card 💳</button>
        </div>

        <!-- Add Existing Card form -->
        <div id="card-form-existing" style="display:none;flex-direction:column;gap:16px;">
          <div class="input-group"><label>Cardholder Name</label><input id="exist-card-name" value="${u.firstName} ${u.lastName}"></div>
          <div class="input-group"><label>Card Number (16 digits)</label><input id="exist-card-number" type="text" maxlength="19" placeholder="0000 0000 0000 0000" oninput="fmtCardInput(this)"></div>
          <div style="display:flex;gap:12px;">
            <div class="input-group" style="flex:1;"><label>Expiry (MM/YY)</label><input id="exist-card-expiry" maxlength="5" placeholder="MM/YY" oninput="fmtExpiryInput(this)"></div>
            <div class="input-group" style="flex:1;"><label>CVV</label><input id="exist-card-cvv" type="password" maxlength="4" placeholder="•••"></div>
          </div>
          <div>
            <label style="font-size:13px;font-weight:600;color:var(--text2);margin-bottom:6px;display:block;">Card Network</label>
            <div style="display:flex;gap:10px;">
              ${['Visa','Mastercard','Amex'].map((t,i)=>`<button onclick="selectExistCardType('${t}')" id="ect-${t}" style="flex:1;padding:10px;border-radius:10px;border:2px solid ${i===0?'#1352DE':'var(--border)'};background:${i===0?'rgba(19,82,222,.06)':'var(--bg3)'};cursor:pointer;font-family:'Sora',sans-serif;font-weight:600;color:${i===0?'#1352DE':'var(--text2)'};font-size:13px;">${t}</button>`).join('')}
            </div>
          </div>
          <div style="padding:14px;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.25);border-radius:12px;">
            <p style="font-size:12px;color:#92400E;">⚠️ This card starts with $0 balance. Use Deposit to add funds.</p>
          </div>
          <button class="btn btn-primary btn-full" id="add-exist-card-btn" onclick="addExistingCard()">Add Card 💳</button>
        </div>
      </div>
    </div>
  </div>`;
}

let selectedCardType='Visa';
let selectedExistCardType='Visa';

function setCardMode(mode) {
  const isNew = mode==='new';
  $('card-form-new').style.display = isNew ? 'flex' : 'none';
  $('card-form-existing').style.display = isNew ? 'none' : 'flex';
  $('card-mode-new').style.borderColor = isNew ? '#1352DE' : 'var(--border)';
  $('card-mode-new').style.background = isNew ? 'rgba(19,82,222,.08)' : 'var(--bg3)';
  $('card-mode-new').style.color = isNew ? '#1352DE' : 'var(--text2)';
  $('card-mode-existing').style.borderColor = !isNew ? '#1352DE' : 'var(--border)';
  $('card-mode-existing').style.background = !isNew ? 'rgba(19,82,222,.08)' : 'var(--bg3)';
  $('card-mode-existing').style.color = !isNew ? '#1352DE' : 'var(--text2)';
}
function fmtCardInput(el) {
  let v=el.value.replace(/\D/g,'').slice(0,16);
  el.value=v.replace(/(.{4})/g,'$1 ').trim();
}
function fmtExpiryInput(el) {
  let v=el.value.replace(/\D/g,'').slice(0,4);
  if(v.length>=3) v=v.slice(0,2)+'/'+v.slice(2);
  el.value=v;
}
function selectExistCardType(t) {
  selectedExistCardType=t;
  ['Visa','Mastercard','Amex'].forEach(ct=>{
    const btn=$(`ect-${ct}`);
    if(btn){btn.style.borderColor=ct===t?'#1352DE':'var(--border)';btn.style.background=ct===t?'rgba(19,82,222,.06)':'var(--bg3)';btn.style.color=ct===t?'#1352DE':'var(--text2)';}
  });
}
async function addExistingCard() {
  if(!isPro(currentUser)) {
    goScreen('subscription');
    addToast('💳 Adding personal cards requires DrimBank Pro','info');
    return;
  }
  const name=$('exist-card-name')?.value.trim();
  const number=$('exist-card-number')?.value.trim();
  const expiry=$('exist-card-expiry')?.value.trim();
  const cvv=$('exist-card-cvv')?.value.trim();
  if(!name||!number||!expiry||!cvv){addToast('Please fill all card fields','error');return;}
  const digits=number.replace(/\s/g,'');
  if(digits.length<15){addToast('Enter a valid card number','error');return;}
  if(!/^\d{2}\/\d{2}$/.test(expiry)){addToast('Expiry format: MM/YY','error');return;}
  const btn=$('add-exist-card-btn');
  btn.disabled=true;btn.innerHTML='<span class="spinner"></span>';
  await new Promise(r=>setTimeout(r,1200));
  const colors=['#1352DE','#0A2540','#00C48C','#7C3AED','#DC2626'];
  const card={
    id:uid(), number:digits.replace(/(.{4})/g,'$1 ').trim(),
    cvv, expiry, name, type:selectedExistCardType,
    frozen:false, limit:5000, spent:0, balance:0,
    color:colors[Math.floor(Math.random()*colors.length)],
    isExisting:true
  };
  updateCurrentUser(u=>({...u,cards:[...(u.cards||[]),card]}));
  addToast('Card added successfully! 💳','success');
  btn.disabled=false;btn.innerHTML='Add Card 💳';
  closeAddCardModal();
  goScreen('cards');
}
function selectCardType(t) {
  selectedCardType=t;
  const root=document.documentElement;
  const borderVal=getComputedStyle(root).getPropertyValue('--border').trim()||'#E2E8F0';
  const bgVal=getComputedStyle(root).getPropertyValue('--bg3').trim()||'#F1F5F9';
  const textVal=getComputedStyle(root).getPropertyValue('--text2').trim()||'#475569';
  ['Visa','Mastercard','Amex'].forEach(ct=>{
    const btn=$(`ct-${ct}`);
    if(btn){btn.style.borderColor=ct===t?'#1352DE':borderVal;btn.style.background=ct===t?'rgba(19,82,222,.06)':bgVal;btn.style.color=ct===t?'#1352DE':textVal;}
  });
}
function openAddCardModal(){const m=$('add-card-modal');if(m)m.style.display='flex';}
function closeAddCardModal(){const m=$('add-card-modal');if(m)m.style.display='none';}
async function createCard() {
  const name=$('card-name')?.value;
  if(!name){addToast('Enter cardholder name','error');return;}
  const btn=$('create-card-btn');
  btn.disabled=true;btn.innerHTML='<span class="spinner"></span>';
  await new Promise(r=>setTimeout(r,1500));
  const colors=['#1352DE','#0A2540','#00C48C'];
  const card={id:uid(),number:genCardNumber(),cvv:genCVV(),expiry:genExpiry(),name,type:selectedCardType,frozen:false,limit:5000,spent:0,color:colors[Math.floor(Math.random()*3)]};
  updateCurrentUser(u=>({...u,cards:[...(u.cards||[]),card]}));
  sendEmail(currentUser.email,'DrimBank – Your New Virtual Card',`Hi ${currentUser.firstName},<br>Your new ${card.type} card is ready.<br><br>Card: <b>${card.number}</b><br>Expiry: <b>${card.expiry}</b><br>CVV: <b>${card.cvv}</b>`);
  addToast('Card created! Details sent to your email.','success');
  btn.disabled=false;btn.innerHTML='Create Card 💳';
  closeAddCardModal();
  goScreen('cards');
}
function toggleCVV(cardId, cvv) {
  const val = document.getElementById('cvv-val-' + cardId);
  const btn = document.getElementById('cvv-btn-' + cardId);
  if (!val || !btn) return;
  const hidden = val.textContent === '•••';
  val.textContent = hidden ? cvv : '•••';
  btn.textContent = hidden ? 'Hide' : 'Show';
  if (hidden) {
    // Auto-hide after 10 seconds
    setTimeout(() => {
      if (val.textContent !== '•••') { val.textContent = '•••'; btn.textContent = 'Show'; }
    }, 10000);
  }
}

function toggleCardFreeze(cardId) {
  updateCurrentUser(u=>({...u,cards:(u.cards||[]).map(c=>c.id===cardId?{...c,frozen:!c.frozen}:c)}));
  addToast('Card status updated','success');
  goScreen('cards');
}

// ─── Savings ─────────────────────────────────────────────────────────────────
function renderSavings() {
  const u=currentUser;
  const plans=(u.savingsPlans||[]).map(p=>`
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:flex-start;">
        <div>
          <span class="badge" style="background:rgba(0,196,140,.13);color:#00C48C;">${p.type}</span>
          <p style="font-weight:700;color:var(--text);font-size:16px;margin-top:8px;">${fmtMoney(p.amount)}</p>
          <p style="color:var(--text3);font-size:13px;">${p.duration} · ${p.rate}% p.a.</p>
          <p style="color:#00C48C;font-size:13px;font-weight:600;margin-top:4px;">Maturity: ${p.maturity}</p>
        </div>
        <span class="badge" style="background:rgba(19,82,222,.13);color:#1352DE;">${p.status}</span>
      </div>
    </div>`).join('');

  return `<div style="padding:24px 20px;max-width:560px;margin:0 auto;">
    ${backBtn()}
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
      <div><h2 style="font-size:22px;font-weight:800;color:var(--text);">Savings</h2><p style="color:var(--text3);font-size:14px;">Total savings: ${fmtMoney(u.savings)}</p></div>
      <button class="btn btn-primary btn-sm" onclick="openSavingsModal()">+ New Plan</button>
    </div>
    <div class="card" style="background:linear-gradient(135deg,#00C48C,#00A677);border:none;margin-bottom:20px;">
      <p style="color:rgba(255,255,255,.7);font-size:13px;">Total Savings Balance</p>
      <h2 style="color:#fff;font-size:32px;font-weight:800;">${fmtMoney(u.savings)}</h2>
      <p style="color:rgba(255,255,255,.7);font-size:12px;margin-top:6px;">Interest earned this month: ${fmtMoney(u.savings*0.004)}</p>
    </div>
    ${(u.savingsPlans||[]).length===0?`<div style="text-align:center;padding:40px;color:var(--text3);"><div style="font-size:48px;">🏦</div><p style="margin-top:12px;font-weight:600;">No savings plans</p><p style="font-size:14px;margin-top:4px;">Start earning interest today</p></div>`:plans}

    <div id="savings-modal" style="display:none;" class="modal-overlay" onclick="closeSavingsModal()">
      <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
          <span class="modal-title">New Savings Plan</span>
          <button class="modal-close" onclick="closeSavingsModal()">×</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div>
            <label style="font-size:13px;font-weight:600;color:var(--text2);margin-bottom:6px;display:block;">Plan Type</label>
            <div style="display:flex;flex-direction:column;gap:8px;">
              ${[['Fixed Deposit','5.2%','Locked for term'],['Target Savings','3.8%','Flexible withdrawals'],['Auto Save','4.5%','Automated savings']].map(([t,r,d])=>`
                <button onclick="selectSavingsPlan('${t}')" id="sp-${t.replace(' ','-')}" style="display:flex;justify-content:space-between;align-items:center;padding:14px;border-radius:12px;border:2px solid ${t==='Fixed Deposit'?'#00C48C':'var(--border)'};background:${t==='Fixed Deposit'?'rgba(0,196,140,.08)':'var(--bg3)'};cursor:pointer;">
                  <div style="text-align:left;"><p style="font-family:'Sora',sans-serif;font-weight:600;color:var(--text);font-size:14px;">${t}</p><p style="font-family:'Sora',sans-serif;color:var(--text3);font-size:12px;">${d}</p></div>
                  <span style="color:#00C48C;font-weight:700;font-family:'Sora',sans-serif;">${r}</span>
                </button>`).join('')}
            </div>
          </div>
          <div class="input-group"><label>Amount (USD)</label><input id="sp-amount" type="number" placeholder="1000"></div>
          <div class="input-group">
            <label>Duration</label>
            <select id="sp-duration">
              ${['3','6','12','24','36'].map(d=>`<option value="${d}">${d} months</option>`).join('')}
            </select>
          </div>
          <div style="padding:14px;background:var(--bg3);border-radius:12px;">
            <p style="font-size:13px;color:var(--text2);">Est. returns: <strong style="color:#00C48C;" id="sp-est">$0.00</strong></p>
          </div>
          <button class="btn btn-emerald btn-full" id="sp-create-btn" onclick="createSavingsPlan()">Create Plan 🏦</button>
        </div>
      </div>
    </div>
  </div>`;
}

let selectedSavingsPlan='Fixed Deposit';
function selectSavingsPlan(t) {
  selectedSavingsPlan=t;
  [['Fixed Deposit','Fixed-Deposit'],['Target Savings','Target-Savings'],['Auto Save','Auto-Save']].forEach(([name,id])=>{
    const btn=$('sp-'+id);
    const root=document.documentElement;
    const borderVar = getComputedStyle(root).getPropertyValue('--border').trim();
    const bgVar = getComputedStyle(root).getPropertyValue('--bg3').trim();
    if(btn){btn.style.borderColor=name===t?'#00C48C':borderVar||'#E2E8F0';btn.style.background=name===t?'rgba(0,196,140,.08)':bgVar||'#F1F5F9';}
  });
}
function openSavingsModal(){const m=$('savings-modal');if(m)m.style.display='flex';}
function closeSavingsModal(){const m=$('savings-modal');if(m)m.style.display='none';}
async function createSavingsPlan() {
  const amt=parseFloat($('sp-amount')?.value), dur=$('sp-duration')?.value;
  if(!amt||amt<=0){addToast('Enter valid amount','error');return;}
  if(amt>currentUser.balance){addToast('Insufficient balance','error');return;}
  const rates={'Fixed Deposit':5.2,'Target Savings':3.8,'Auto Save':4.5};
  const rate=rates[selectedSavingsPlan]||4;
  const interest=amt*(rate/100)*(parseInt(dur)/12);
  const btn=$('sp-create-btn');
  btn.disabled=true;btn.innerHTML='<span class="spinner"></span>';
  await new Promise(r=>setTimeout(r,1300));
  const plan={id:uid(),type:selectedSavingsPlan,amount:amt,duration:dur+' months',rate,interest:interest.toFixed(2),maturity:fmtMoney(amt+interest),startDate:new Date().toISOString(),status:'Active'};
  updateCurrentUser(u=>({...u,balance:u.balance-amt,savings:u.savings+amt,savingsPlans:[...(u.savingsPlans||[]),plan]}));
  sendEmail(currentUser.email,'DrimBank – Savings Plan Created',`Your ${selectedSavingsPlan} of ${fmtMoney(amt)} at ${rate}% for ${dur} months is active.`);
  addToast('Savings plan created!','success');
  btn.disabled=false;btn.innerHTML='Create Plan 🏦';
  closeSavingsModal();
  goScreen('savings');
}

// ─── Loans ───────────────────────────────────────────────────────────────────
function renderLoans() {
  const u=currentUser;
  const totalBalance=(u.loans||[]).reduce((s,l)=>s+l.balance,0);
  const loanItems=(u.loans||[]).map(l=>`
    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;">
        <span class="badge" style="background:${l.status==='Approved'?'rgba(0,196,140,.13)':l.status==='Under Review'?'rgba(245,158,11,.13)':'rgba(239,68,68,.13)'};color:${l.status==='Approved'?'#00C48C':l.status==='Under Review'?'#F59E0B':'#EF4444'};">${l.status}</span>
        <span style="font-size:12px;color:var(--text3);">${fmtDate(l.appliedDate)}</span>
      </div>
      <h3 style="font-size:22px;font-weight:800;color:var(--text);margin-top:12px;">${fmtMoney(l.amount)}</h3>
      <p style="color:var(--text3);font-size:13px;">${l.purpose} Loan · ${l.term} · ${l.rate}% p.a.</p>
      <div style="display:flex;justify-content:space-between;margin-top:16px;padding:14px;background:var(--bg3);border-radius:10px;">
        <div><p style="font-size:12px;color:var(--text3);">Monthly EMI</p><p style="font-weight:700;color:var(--text);">${fmtMoney(l.monthlyPayment)}</p></div>
        <div><p style="font-size:12px;color:var(--text3);">Balance</p><p style="font-weight:700;color:var(--text);">${fmtMoney(l.balance)}</p></div>
      </div>
    </div>`).join('');

  const loanProducts=[{name:'Personal Loan',rate:'12.5%',max:'$50,000',icon:'👤'},{name:'Home Loan',rate:'7.2%',max:'$500,000',icon:'🏠'},{name:'Auto Loan',rate:'9.8%',max:'$75,000',icon:'🚗'},{name:'Business Loan',rate:'14.0%',max:'$200,000',icon:'💼'}];

  return `<div style="padding:24px 20px;max-width:560px;margin:0 auto;">
    ${backBtn()}
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:24px;">
      <div><h2 style="font-size:22px;font-weight:800;color:var(--text);">Loans</h2><p style="color:var(--text3);font-size:14px;">Total outstanding: ${fmtMoney(totalBalance)}</p></div>
      <button class="btn btn-primary btn-sm" onclick="openLoanModal()">Apply Now</button>
    </div>
    ${(u.loans||[]).length===0?`<div class="card" style="text-align:center;padding:40px;margin-bottom:20px;"><div style="font-size:48px;">📋</div><p style="font-weight:700;color:var(--text);margin-top:12px;">No active loans</p><p style="color:var(--text3);font-size:14px;margin-top:4px;">Apply for a personal loan in minutes</p><button class="btn btn-primary" style="margin-top:20px;" onclick="openLoanModal()">Apply for Loan</button></div>`:loanItems}
    <h3 style="font-weight:700;color:var(--text);margin-bottom:16px;margin-top:8px;">Loan Products</h3>
    ${loanProducts.map(p=>`
      <div class="card" style="display:flex;align-items:center;gap:16px;margin-bottom:12px;padding:18px;">
        <div style="font-size:28px;">${p.icon}</div>
        <div style="flex:1;"><p style="font-weight:700;color:var(--text);">${p.name}</p><p style="color:var(--text3);font-size:13px;">From ${p.rate} · Up to ${p.max}</p></div>
        <button class="btn btn-primary btn-sm" onclick="openLoanModalWith('${p.name.split(' ')[0]}')">Apply</button>
      </div>`).join('')}

    <div id="loan-modal" style="display:none;" class="modal-overlay" onclick="closeLoanModal()">
      <div class="modal-box" onclick="event.stopPropagation()">
        <div class="modal-header">
          <span class="modal-title">Loan Application</span>
          <button class="modal-close" onclick="closeLoanModal()">×</button>
        </div>
        <div style="display:flex;flex-direction:column;gap:16px;">
          <div class="input-group"><label>Loan Amount (USD)</label><input id="loan-amt" type="number" placeholder="5000" oninput="updateLoanEst()"></div>
          <div class="input-group">
            <label>Loan Purpose</label>
            <select id="loan-purpose">${['Personal','Home','Auto','Business','Education','Medical'].map(p=>`<option>${p}</option>`).join('')}</select>
          </div>
          <div class="input-group">
            <label>Repayment Term</label>
            <select id="loan-term" onchange="updateLoanEst()">${['6','12','24','36','48','60'].map(t=>`<option value="${t}">${t} months</option>`).join('')}</select>
          </div>
          <div style="padding:14px;background:var(--bg3);border-radius:12px;">
            <p style="font-size:13px;color:var(--text2);">Est. monthly: <strong style="color:var(--text);" id="loan-est">$—</strong></p>
          </div>
          <button class="btn btn-primary btn-full" id="loan-submit-btn" onclick="applyLoan()">Submit Application 📋</button>
        </div>
      </div>
    </div>
  </div>`;
}

function updateLoanEst() {
  const amt=parseFloat($('loan-amt')?.value||0), term=parseInt($('loan-term')?.value||12);
  if(amt>0){
    const monthly=(amt*(12.5/1200))/(1-Math.pow(1+12.5/1200,-term));
    const el=$('loan-est');
    if(el)el.textContent=fmtMoney(monthly);
  }
}
function openLoanModal(){const m=$('loan-modal');if(m)m.style.display='flex';}
function openLoanModalWith(purpose){
  openLoanModal();
  const el=$('loan-purpose');
  if(el){for(let i=0;i<el.options.length;i++){if(el.options[i].text===purpose){el.selectedIndex=i;break;}}}
}
function closeLoanModal(){const m=$('loan-modal');if(m)m.style.display='none';}
async function applyLoan() {
  const amt=parseFloat($('loan-amt')?.value), term=$('loan-term')?.value, purpose=$('loan-purpose')?.value;
  if(!amt||amt<=0||amt>50000){addToast('Amount must be $1–$50,000','error');return;}
  const btn=$('loan-submit-btn');
  btn.disabled=true;btn.innerHTML='<span class="spinner"></span>';
  await new Promise(r=>setTimeout(r,1500));
  const rate=12.5;
  const monthly=(amt*(rate/1200))/(1-Math.pow(1+rate/1200,-parseInt(term)));
  const loan={id:uid(),amount:amt,term:term+' months',rate,monthlyPayment:monthly.toFixed(2),purpose,status:'Under Review',appliedDate:new Date().toISOString(),balance:amt};
  updateCurrentUser(u=>({...u,loans:[...(u.loans||[]),loan]}));
  sendEmail(currentUser.email,'DrimBank – Loan Application Received',`Hi ${currentUser.firstName}, your loan application of ${fmtMoney(amt)} is under review. Decision in 2–3 business days.`);
  addToast('Loan application submitted!','success');
  btn.disabled=false;btn.innerHTML='Submit Application 📋';
  closeLoanModal();
  goScreen('loans');
}

// ─── History ─────────────────────────────────────────────────────────────────
let txFilter='all', txSearch='';
function renderHistory() {
  const u=currentUser;
  const allTxs=[...(u.transactions||[])].sort((a,b)=>new Date(b.date)-new Date(a.date));
  const filtered=allTxs.filter(t=>{
    if(txFilter==='credit'&&t.amount<0)return false;
    if(txFilter==='debit'&&t.amount>0)return false;
    if(txSearch&&!t.desc.toLowerCase().includes(txSearch.toLowerCase()))return false;
    return true;
  });
  const rows=filtered.map((t,i)=>`
    <div onclick="openReceiptById('${t.id}')" style="display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:${i<filtered.length-1?'1px solid #F1F5F9':'none'};cursor:pointer;transition:background .15s;border-radius:10px;" onmouseover="this.style.background='var(--bg3)'" onmouseout="this.style.background='transparent'">
      <div style="width:44px;height:44px;border-radius:12px;background:${t.amount>0?'rgba(0,196,140,.13)':'rgba(239,68,68,.09)'};display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;">${t.amount>0?'📈':'📉'}</div>
      <div style="flex:1;">
        <p style="font-weight:600;font-size:14px;color:var(--text);">${t.desc}</p>
        <p style="font-size:12px;color:var(--text3);">${fmtDate(t.date)} · <span style="font-family:'JetBrains Mono';font-size:11px;">#${t.id}</span></p>
        <span class="badge" style="background:rgba(148,163,184,.13);color:var(--text3);margin-top:4px;">${t.category}</span>
      </div>
      <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">
        <p style="font-weight:700;color:${t.amount>0?'#00C48C':'#EF4444'};font-size:15px;">${t.amount>0?'+':''}${fmtMoney(t.amount)}</p>
        <span style="font-size:10px;color:var(--text3);font-weight:600;">VIEW ›</span>
      </div>
    </div>`).join('');

  return `<div style="padding:24px 20px;max-width:560px;margin:0 auto;">
    ${backBtn()}
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:20px;">
      <h2 style="font-size:22px;font-weight:800;color:var(--text);">Transaction History</h2>
      <button onclick="shareAllTransactions()" style="background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;border:none;border-radius:10px;padding:8px 14px;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:6px;">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
        Share / Export
      </button>
    </div>
    <div class="input-group" style="margin-bottom:16px;">
      <input id="tx-search-input" placeholder="🔍 Search transactions..." value="${txSearch}" oninput="txSearch=this.value;goScreen('history')">
    </div>
    <div class="tab-bar" style="margin-bottom:20px;">
      <button class="tab-btn ${txFilter==='all'?'active':''}" onclick="txFilter='all';goScreen('history')">All</button>
      <button class="tab-btn ${txFilter==='credit'?'active':''}" onclick="txFilter='credit';goScreen('history')">Credits</button>
      <button class="tab-btn ${txFilter==='debit'?'active':''}" onclick="txFilter='debit';goScreen('history')">Debits</button>
    </div>
    <div style="font-size:12px;color:var(--text3);margin-bottom:12px;font-weight:600;">${filtered.length} transaction${filtered.length!==1?'s':''} found</div>
    <div class="card">
      ${filtered.length===0?'<p style="color:var(--text3);font-size:14px;text-align:center;padding:24px;">No transactions found.</p>':rows}
    </div>
  </div>`;
}

// ─── Share All Transactions ───────────────────────────────────────────────────
async function shareAllTransactions() {
  const u = currentUser;
  const allTxs = [...(u.transactions||[])].sort((a,b)=>new Date(b.date)-new Date(a.date));
  if (allTxs.length === 0) { addToast('No transactions to share', 'info'); return; }
  // Build text summary
  const header = `DrimBank Transaction Statement\n${u.firstName} ${u.lastName} · Acct: ****${(u.accountNumber||'').slice(-4)}\nGenerated: ${new Date().toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})}\n${'─'.repeat(44)}\n`;
  const rows = allTxs.map(t=>`${new Date(t.date).toLocaleDateString()} · ${t.desc.padEnd(28,' ')} ${t.amount>0?'+':''}${fmtMoney(t.amount)}`).join('\n');
  const footer = `\n${'─'.repeat(44)}\nTotal Credits: ${fmtMoney(allTxs.filter(t=>t.amount>0).reduce((s,t)=>s+t.amount,0))}\nTotal Debits: ${fmtMoney(Math.abs(allTxs.filter(t=>t.amount<0).reduce((s,t)=>s+t.amount,0)))}\nCurrent Balance: ${fmtMoney(u.balance)}`;
  const text = header + rows + footer;

  const sheet = document.createElement('div');
  sheet.style.cssText = 'position:fixed;inset:0;z-index:3000;display:flex;align-items:flex-end;justify-content:center;background:rgba(10,37,64,.7);backdrop-filter:blur(10px);';
  sheet.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg);border-radius:28px 28px 0 0;width:100%;max-width:520px;padding:28px 24px 40px;font-family:'Sora',sans-serif;">
    <div style="width:40px;height:4px;border-radius:4px;background:var(--border);margin:0 auto 24px;"></div>
    <h3 style="font-weight:800;color:var(--text);font-size:18px;margin-bottom:6px;">Share Statement</h3>
    <p style="color:var(--text3);font-size:13px;margin-bottom:24px;">${allTxs.length} transactions · ${u.firstName} ${u.lastName}</p>
    <div style="display:flex;flex-direction:column;gap:10px;">
      <button onclick="copyTxStatement()" style="width:100%;padding:14px;border:1.5px solid var(--border);border-radius:14px;background:var(--bg3);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:var(--text);cursor:pointer;display:flex;align-items:center;gap:12px;">
        <span style="font-size:20px;">📋</span> Copy Statement Text
      </button>
      <button onclick="downloadTxCsv()" style="width:100%;padding:14px;border:1.5px solid rgba(19,82,222,.3);border-radius:14px;background:rgba(19,82,222,.06);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:#1352DE;cursor:pointer;display:flex;align-items:center;gap:12px;">
        <span style="font-size:20px;">📊</span> Download as CSV
      </button>
      ${navigator.share ? `<button onclick="nativeShareTx()" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;color:#fff;cursor:pointer;display:flex;align-items:center;gap:12px;">
        <span style="font-size:20px;">↗️</span> Share via Phone
      </button>` : ''}
    </div>
    <button onclick="this.closest('[style*=\"fixed\"]').remove()" style="width:100%;padding:13px;border:none;background:none;color:var(--text3);font-family:'Sora',sans-serif;font-weight:600;font-size:14px;cursor:pointer;margin-top:10px;">Cancel</button>
  </div>`;
  sheet.addEventListener('click', e=>{ if(e.target===sheet) sheet.remove(); });
  document.body.appendChild(sheet);

  window._txStatementText = text;
  window.copyTxStatement = function() {
    navigator.clipboard?.writeText(window._txStatementText).then(()=>{
      addToast('Statement copied to clipboard! 📋', 'success');
      sheet.remove();
    }).catch(()=>{ addToast('Copy not supported in this browser', 'error'); });
  };
  window.downloadTxCsv = function() {
    const csvRows = ['Date,Description,Amount,Category,Type', ...allTxs.map(t=>`"${new Date(t.date).toLocaleDateString()}","${t.desc}","${(t.amount>0?'+':'')+Math.abs(t.amount).toFixed(2)}","${t.category||''}","${t.amount>0?'Credit':'Debit'}"`)];
    const blob = new Blob([csvRows.join('\n')], {type:'text/csv'});
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `DrimBank-Statement-${u.accountNumber?.slice(-4)}.csv`;
    link.click();
    addToast('CSV downloaded! 📊', 'success');
    sheet.remove();
  };
  window.nativeShareTx = async function() {
    try {
      await navigator.share({ title: 'DrimBank Statement', text: window._txStatementText });
      addToast('Statement shared! ↗️', 'success');
    } catch(e) { if(!e.message?.includes('cancel')) addToast('Share failed', 'error'); }
    sheet.remove();
  };
}

// ─── Notifications ───────────────────────────────────────────────────────────
function renderNotifications() {
  const items=[...alerts].reverse().map(a=>`
    <div class="card" style="margin-bottom:16px;border-left:4px solid #1352DE;">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;">
        <div class="logo" style="scale:.7;transform-origin:left;">
          <div class="logo-icon" style="width:16px;height:16px;font-size:7px;">C</div>
          <span class="logo-text" style="font-size:10px;">Drim<span>Bank</span></span>
        </div>
        <span class="badge" style="background:rgba(19,82,222,.13);color:#1352DE;">Email Alert</span>
      </div>
      <p style="font-weight:700;color:var(--text);font-size:15px;margin-bottom:6px;">${a.subject}</p>
      <div style="font-size:13px;color:var(--text2);line-height:1.6;">${a.body}</div>
      <p style="font-size:11px;color:var(--text3);margin-top:12px;font-family:'JetBrains Mono';">${fmtDate(a.time)}</p>
    </div>`).join('');

  return `<div style="padding:24px 20px;max-width:560px;margin:0 auto;">
    ${backBtn()}
    <h2 style="font-size:22px;font-weight:800;color:var(--text);margin-bottom:20px;">Alerts & Notifications</h2>
    ${alerts.length===0?`<div style="text-align:center;padding:60px;color:var(--text3);"><div style="font-size:48px;">🔔</div><p style="margin-top:12px;font-weight:600;">No notifications yet</p></div>`:items}
  </div>`;
}

// ─── Support Chat ─────────────────────────────────────────────────────────────
let supportMessages=[];
let supportInitDone=false;
// ─── AI Support Chat (Claude API powered) ────────────────────────────────────
let aiSupportBusy = false;

function buildMayaSystemPrompt(u) {
  return `You are Maya, a warm, professional, and knowledgeable customer support AI for DrimBank — a modern digital banking app. Your job is to assist users with any questions about their account, finances, app features, or general banking topics.

CURRENT USER ACCOUNT CONTEXT (use this to give personalised answers):
- Name: ${u.firstName} ${u.lastName}
- Email: ${u.email}
- Account Number: ${u.accountNumber}
- Current Balance: $${u.balance.toFixed(2)}
- Savings Balance: $${u.savings.toFixed(2)}
- Account Type: ${u.isPro ? 'DrimBank Pro 👑 (all features unlocked)' : 'Free Account (limited features)'}
- Member Since: ${new Date(u.createdAt).toLocaleDateString('en-US',{year:'numeric',month:'long'})}
- Recent Transactions: ${(u.transactions||[]).slice(0,5).map(t=>`${t.desc} (${t.amount>0?'+':''}$${Math.abs(t.amount).toFixed(2)})`).join(', ') || 'None yet'}

APP FEATURES YOU CAN HELP WITH:
- Dashboard: shows balance, recent transactions, quick actions
- Transfer: send money locally, deposit funds, withdraw, international SWIFT transfers
- Cards: create and manage virtual Visa/Mastercard debit cards
- Savings: create savings plans and goals
- Loans: apply for personal loans (2-3 business day decisions)
- History: view all transactions and download receipts as PDF/image
- Profile: update personal info, change avatar, manage security settings
- Support: this AI chat (you!)

TONE & BEHAVIOUR RULES:
- Be warm, concise, and professional — like a real bank's live chat agent
- Always address the user by their first name (${u.firstName})
- Give specific, actionable answers — never vague
- If asked about balance or transactions, use the real data provided above
- For sensitive issues you cannot resolve (e.g. disputes, fraud), say you are escalating to a human specialist and ask for their email
- Never make up account numbers, transactions, or policy details you don't know
- Keep replies under 120 words unless the question genuinely needs more detail
- Use line breaks to make longer answers easy to read on mobile
- Do not use markdown headers or bullet symbols like * or # — plain text only
- You may use emojis sparingly to stay friendly`;
}

function initSupport() {
  if(!supportInitDone) {
    supportInitDone=true;
    supportMessages=[{
      id:1, from:'agent',
      text:`Hi ${currentUser.firstName}! 👋 I'm Maya, your DrimBank AI assistant. I can help with your balance, transfers, cards, loans, account settings, and any other questions. What can I help you with today?`,
      time:new Date().toISOString()
    }];
  }
  renderSupportMessages();
  const inp=$('support-input');
  if(inp) {
    inp.addEventListener('keydown', e => { if(e.key==='Enter' && !e.shiftKey) { e.preventDefault(); sendSupportMsg(); } });
    setTimeout(() => inp.focus(), 100);
  }
}

function renderSupportMessages() {
  const container=$('support-msgs');
  if(!container) return;
  container.innerHTML = supportMessages.map(m => {
    const isUser = m.from === 'user';
    const timeStr = new Date(m.time).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'});
    return `<div style="display:flex;justify-content:${isUser?'flex-end':'flex-start'};margin-bottom:16px;align-items:flex-end;gap:8px;">
      ${!isUser ? `<div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#1352DE,#00C48C);display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;">🤖</div>` : ''}
      <div style="max-width:78%;">
        <div style="padding:12px 16px;border-radius:${isUser?'20px 20px 4px 20px':'20px 20px 20px 4px'};background:${isUser?'linear-gradient(135deg,#1352DE,#2D6BE4)':'var(--bg3)'};color:${isUser?'#fff':'var(--text)'};border:${!isUser?'1px solid var(--border)':'none'};font-size:14px;line-height:1.6;white-space:pre-wrap;word-break:break-word;">${m.text}</div>
        <p style="font-size:10px;color:var(--text3);margin-top:4px;text-align:${isUser?'right':'left'};padding:0 4px;">${timeStr}</p>
      </div>
      ${isUser ? `<div style="width:32px;height:32px;border-radius:50%;background:#1352DE22;display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;">👤</div>` : ''}
    </div>`;
  }).join('');
  container.scrollTop = container.scrollHeight;
}

const QUICK_PROMPTS = [
  { label: '💰 My Balance', text: 'What is my current balance?' },
  { label: '💸 How to Transfer', text: 'How do I send money to someone?' },
  { label: '💳 Get a Card', text: 'How do I get a virtual card?' },
  { label: '📋 Apply for Loan', text: 'How do I apply for a loan?' },
];

function renderSupport() {
  return `<div style="display:flex;flex-direction:column;height:calc(100vh - 140px);max-width:560px;margin:0 auto;background:var(--bg);">
    <!-- Header -->
    <div style="padding:16px 20px;border-bottom:1px solid var(--border);background:var(--card-bg);box-shadow:0 2px 12px var(--shadow);">
      <div style="display:flex;align-items:center;gap:12px;">
        <div style="position:relative;">
          <div style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#1352DE,#00C48C);display:flex;align-items:center;justify-content:center;font-size:22px;">🤖</div>
          <div style="position:absolute;bottom:1px;right:1px;width:11px;height:11px;background:#00C48C;border-radius:50%;border:2px solid var(--card-bg);"></div>
        </div>
        <div style="flex:1;">
          <h3 style="font-weight:700;color:var(--text);font-size:16px;margin-bottom:1px;">Maya — AI Support</h3>
          <p style="font-size:12px;color:#00C48C;font-weight:600;">● Online · Replies instantly</p>
        </div>
        <div style="text-align:right;">
          <p style="font-size:10px;color:var(--text3);font-weight:500;">Powered by</p>
          <p style="font-size:11px;color:var(--blue);font-weight:700;">Claude AI</p>
        </div>
      </div>
    </div>

    <!-- Messages -->
    <div id="support-msgs" style="flex:1;overflow-y:auto;padding:20px 16px 8px;scroll-behavior:smooth;"></div>

    <!-- Typing indicator -->
    <div id="support-typing" style="display:none;padding:0 16px 8px;align-items:center;gap:8px;">
      <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,#1352DE,#00C48C);display:flex;align-items:center;justify-content:center;font-size:15px;">🤖</div>
      <div style="background:var(--bg3);border:1px solid var(--border);border-radius:20px 20px 20px 4px;padding:12px 18px;display:flex;gap:5px;align-items:center;">
        <div class="typing-dot" style="width:7px;height:7px;border-radius:50%;background:var(--text3);animation:pulse 1.2s infinite;"></div>
        <div class="typing-dot" style="width:7px;height:7px;border-radius:50%;background:var(--text3);animation:pulse 1.2s infinite;animation-delay:.2s;"></div>
        <div class="typing-dot" style="width:7px;height:7px;border-radius:50%;background:var(--text3);animation:pulse 1.2s infinite;animation-delay:.4s;"></div>
      </div>
    </div>

    <!-- Quick prompts -->
    <div id="support-quick-prompts" style="padding:8px 16px;display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;">
      ${QUICK_PROMPTS.map(q=>`<button onclick="sendQuickPrompt('${q.text}')" style="white-space:nowrap;padding:8px 14px;border-radius:20px;border:1.5px solid var(--border);background:var(--card-bg);color:var(--text2);font-family:'Sora',sans-serif;font-size:12px;font-weight:600;cursor:pointer;transition:all .2s;flex-shrink:0;" onmouseover="this.style.borderColor='#1352DE';this.style.color='#1352DE'" onmouseout="this.style.borderColor='';this.style.color=''">${q.label}</button>`).join('')}
    </div>

    <!-- Input bar -->
    <div style="padding:12px 16px 16px;border-top:1px solid var(--border);background:var(--card-bg);display:flex;gap:10px;align-items:flex-end;">
      <textarea id="support-input" placeholder="Ask Maya anything…" rows="1" style="flex:1;padding:12px 16px;border-radius:20px;border:1.5px solid var(--border);background:var(--input-bg);color:var(--text);font-size:14px;font-family:'Sora',sans-serif;outline:none;resize:none;max-height:100px;overflow-y:auto;line-height:1.5;transition:border .2s;" onfocus="this.style.borderColor='#1352DE'" onblur="this.style.borderColor=''" oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'"></textarea>
      <button id="support-send-btn" onclick="sendSupportMsg()" style="width:46px;height:46px;border-radius:50%;background:linear-gradient(135deg,#1352DE,#2D6BE4);border:none;color:#fff;font-size:20px;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:opacity .2s;box-shadow:0 4px 14px rgba(19,82,222,.4);" onmouseover="this.style.opacity='.85'" onmouseout="this.style.opacity='1'">➤</button>
    </div>
  </div>`;
}

function sendQuickPrompt(text) {
  const inp = $('support-input');
  if(inp) { inp.value = text; inp.style.height = 'auto'; }
  sendSupportMsg();
  // Hide quick prompts after first use
  const qp = $('support-quick-prompts');
  if(qp) qp.style.display = 'none';
}

async function sendSupportMsg() {
  if(aiSupportBusy) return;
  const inp = $('support-input');
  if(!inp || !inp.value.trim()) return;
  const text = inp.value.trim();
  inp.value = '';
  inp.style.height = 'auto';

  // Hide quick prompts once conversation starts
  const qp = $('support-quick-prompts');
  if(qp) qp.style.display = 'none';

  supportMessages.push({ id: Date.now(), from: 'user', text, time: new Date().toISOString() });
  renderSupportMessages();

  // Show typing
  const typing = $('support-typing');
  if(typing) typing.style.display = 'flex';
  const sendBtn = $('support-send-btn');
  if(sendBtn) { sendBtn.disabled = true; sendBtn.style.opacity = '.4'; }
  aiSupportBusy = true;

  // Scroll to show typing indicator
  const msgs = $('support-msgs');
  if(msgs) setTimeout(() => { msgs.scrollTop = msgs.scrollHeight; }, 50);

  try {
    // Build conversation history for the API (exclude system greeting id=1 content, use as history)
    const history = supportMessages.slice(1).map(m => ({
      role: m.from === 'user' ? 'user' : 'assistant',
      content: m.text
    }));

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1000,
        system: buildMayaSystemPrompt(currentUser),
        messages: history
      })
    });

    const data = await response.json();
    const reply = (data.content || []).map(b => b.text || '').join('').trim()
      || "I'm sorry, I couldn't process that just now. Please try again in a moment.";

    if(typing) typing.style.display = 'none';
    supportMessages.push({ id: Date.now() + 1, from: 'agent', text: reply, time: new Date().toISOString() });
    renderSupportMessages();
  } catch(err) {
    if(typing) typing.style.display = 'none';
    supportMessages.push({
      id: Date.now() + 1, from: 'agent',
      text: `I'm having trouble connecting right now, ${currentUser.firstName}. Please check your internet connection and try again, or contact us at support@drimbank.com.`,
      time: new Date().toISOString()
    });
    renderSupportMessages();
  } finally {
    aiSupportBusy = false;
    if(sendBtn) { sendBtn.disabled = false; sendBtn.style.opacity = '1'; }
    if(inp) inp.focus();
  }
}

// ─── Profile ─────────────────────────────────────────────────────────────────
let profileEditMode=false;
function renderProfile() {
  const u=currentUser;
  const editForm=profileEditMode?`
    <div style="display:flex;flex-direction:column;gap:14px;">
      <!-- Avatar picker in edit mode -->
      <div style="text-align:center;margin-bottom:4px;">
        <div class="avatar-upload-ring" onclick="triggerAvatarUpload()">
          <img src="${u.avatar}" alt="avatar" id="prof-avatar-preview">
          <div class="avatar-upload-overlay">📷</div>
        </div>
        <p style="font-size:12px;color:var(--text3);margin-top:4px;">Tap to change photo</p>
      </div>
      <div style="display:flex;gap:12px;">
        <div class="input-group" style="flex:1;"><label>First Name</label><input id="prof-fname" value="${u.firstName}"></div>
        <div class="input-group" style="flex:1;"><label>Last Name</label><input id="prof-lname" value="${u.lastName}"></div>
      </div>
      <div class="input-group"><label>Phone</label><input id="prof-phone" value="${u.phone||''}"></div>
      <div class="input-group"><label>Email Address</label><input id="prof-email" type="email" value="${u.email}"></div>
      <div class="input-group"><label>Date of Birth</label><input id="prof-dob" type="date" value="${u.dob||''}"></div>
      <div style="display:flex;gap:10px;">
        <button class="btn btn-primary" style="flex:1;" onclick="saveProfile()">Save Changes</button>
        <button class="btn btn-ghost" style="flex:1;" onclick="profileEditMode=false;goScreen('profile')">Cancel</button>
      </div>
    </div>` :
    [
      ['Full Name', u.firstName + ' ' + (u.lastName ? u.lastName[0] + '*'.repeat(Math.max(0,u.lastName.length-1)) : '')],
      ['Email', u.email ? maskEmail(u.email) : '—'],
      ['Phone', u.phone ? maskPhone(u.phone) : '—'],
      ['Account No.', '•••• •••• ' + (u.accountNumber||'').slice(-4)],
      ['Verification', 'Identity Verified'],
    ].map(([l,v])=>`
      <div style="display:flex;justify-content:space-between;padding:12px 0;border-bottom:1px solid var(--border);">
        <span style="color:var(--text3);font-size:14px;">${l}</span>
        <span style="font-weight:600;color:var(--text);font-size:14px;" class="${l==='Account No.'?'mono':''}">${
        l==='Verification' ? '<span style=\"display:inline-flex;align-items:center;gap:5px;color:#00A677;font-weight:700;\"><svg width=\"13\" height=\"13\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"#00A677\" stroke-width=\"2.5\"><polyline points=\"20 6 9 17 4 12\"/></svg>'+v+'</span>' :
        l==='Account Type' ? '<span class=\"acct-type-chip\">'+v+'</span>' : v
      }</span>
      </div>`).join('');

  return `<div style="padding:24px 20px;max-width:560px;margin:0 auto;">
    <h2 style="font-size:22px;font-weight:800;color:var(--text);margin-bottom:24px;">Profile</h2>
    <div class="card" style="text-align:center;margin-bottom:20px;background:linear-gradient(135deg,#0A2540,#1a3d70);border:none;">
      <div class="avatar-upload-ring" onclick="triggerAvatarUpload()" style="margin:0 auto 8px;">
        <img src="${u.avatar}" alt="avatar" id="prof-avatar-preview" style="width:96px;height:96px;border-radius:50%;border:3px solid #1352DE;object-fit:cover;">
        <div class="avatar-upload-overlay">📷</div>
      </div>
      <button onclick="triggerAvatarUpload()" style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:8px;padding:5px 14px;color:rgba(255,255,255,.85);font-family:'Sora',sans-serif;font-size:11px;font-weight:600;cursor:pointer;margin-bottom:8px;">📷 Change Photo</button>
      <h3 style="color:#fff;font-weight:800;font-size:20px;margin-top:4px;">${u.firstName} ${u.lastName}</h3>
      <p style="color:rgba(255,255,255,.6);font-size:13px;">${maskEmail(u.email)}</p>
      <div style="margin-top:16px;display:flex;justify-content:center;gap:24px;">
        <div><p style="color:rgba(255,255,255,.6);font-size:12px;">Account No.</p><p style="color:#fff;font-family:'JetBrains Mono';font-size:14px;font-weight:600;">···${(u.accountNumber||'').slice(-4)}</p></div>
      </div>
    </div>

    <div class="card" style="margin-bottom:16px;">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h3 style="font-weight:700;color:var(--text);">Personal Information</h3>
        ${!profileEditMode?`<button class="btn btn-ghost btn-sm" onclick="profileEditMode=true;goScreen('profile')">Edit</button>`:''}
      </div>
      ${editForm}
    </div>

    <div class="card" style="margin-bottom:16px;">
      <h3 style="font-weight:700;color:var(--text);font-size:15px;margin-bottom:4px;">Security</h3>
      <p style="color:var(--text3);font-size:12px;margin-bottom:16px;">Manage your account security settings</p>
      <div class="sec-row" onclick="openChangePasswordModal()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Password</p><p style="color:var(--text3);font-size:12px;">Last changed recently</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
      <div class="sec-row" onclick="openSetPinModal()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${u.transactionPin ? '#00A677' : 'var(--blue)'}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/><circle cx="12" cy="16" r="1"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Transaction PIN</p><p style="color:var(--text3);font-size:12px;">${u.transactionPin ? '4-digit PIN is set ✓ · synced across devices' : 'Not set — required for transfers'}</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
      <div class="sec-row" onclick="addToast('Two-factor authentication is active on your account.','info')">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#00A677" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Two-Factor Authentication</p><p style="color:var(--text3);font-size:12px;">Email OTP verification</p></div>
        <div class="sec-toggle"></div>
      </div>
      <div class="sec-row" onclick="openBiometricSettings()">
        <div class="sec-icon-wrap">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="${hasBiometricEnrolled() ? '#00A677' : 'var(--blue)'}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2C8 2 4.5 5 4 9"/><path d="M4 13c.5 3.5 3.5 6.5 8 7"/><path d="M20 9c-.5-4-4-7-8-7"/><path d="M20 13c-.5 3.5-3.5 6.5-8 7"/><path d="M9 9a3 3 0 0 1 6 0v3a3 3 0 0 1-6 0V9z"/>
          </svg>
        </div>
        <div style="flex:1;">
          <p style="font-weight:600;color:var(--text);font-size:14px;">Biometric Login</p>
          <p style="color:var(--text3);font-size:12px;">${hasBiometricEnrolled() ? 'Face ID / Fingerprint enabled ✓' : 'Tap to set up Face ID or Fingerprint'}</p>
        </div>
        <div class="sec-toggle ${hasBiometricEnrolled() ? '' : 'off'}"></div>
      </div>
      <div class="sec-row" style="border-bottom:none;" onclick="openActiveSessionsModal()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Active Sessions</p><p style="color:var(--text3);font-size:12px;">1 device currently active</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
    </div>
    <div class="card" style="margin-bottom:16px;">
      <h3 style="font-weight:700;color:var(--text);font-size:15px;margin-bottom:16px;">Preferences</h3>
      <div class="sec-row" onclick="openNotificationSettings()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Notifications</p><p style="color:var(--text3);font-size:12px;">Push, SMS, email alerts</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
      <div class="sec-row" onclick="toggleDarkMode()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Appearance</p><p style="color:var(--text3);font-size:12px;">${darkMode?'Dark theme':'Light theme'}</p></div>
        <div class="sec-toggle ${darkMode?'':'off'}"></div>
      </div>
      <div class="sec-row" onclick="openLanguageModal()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Language & Region</p><p style="color:var(--text3);font-size:12px;">English (US)</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
      <div class="sec-row" onclick="openHelpModal()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Help Centre</p><p style="color:var(--text3);font-size:12px;">FAQs, guides, contact</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
      <div class="sec-row" style="border-bottom:none;" onclick="openPrivacyModal()">
        <div class="sec-icon-wrap"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text2)" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div>
        <div style="flex:1;"><p style="font-weight:600;color:var(--text);font-size:14px;">Privacy & Legal</p><p style="color:var(--text3);font-size:12px;">Privacy policy, terms</p></div>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
      </div>
    </div>
    ${isAdminAccount(u) ? `<div style="margin-bottom:16px;">
      <button onclick="goScreen('admin')" style="width:100%;padding:14px;border-radius:12px;background:linear-gradient(135deg,rgba(10,37,64,.08),rgba(19,82,222,.08));border:1.5px solid rgba(19,82,222,.2);color:#1352DE;font-family:'Sora',sans-serif;font-weight:700;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;gap:8px;">🛡️ Admin Dashboard</button>
    </div>` : ''}
    ${!isPro(u) ? `<div style="margin-bottom:16px;">
      <button onclick="openActivationCodeModal()" style="width:100%;padding:14px;border-radius:12px;background:linear-gradient(135deg,rgba(255,215,0,.12),rgba(255,165,0,.08));border:1.5px solid rgba(255,215,0,.4);color:#B45309;font-family:'Sora',sans-serif;font-weight:700;cursor:pointer;font-size:14px;display:flex;align-items:center;justify-content:center;gap:8px;">🔐 Enter Activation Code</button>
    </div>` : ''}
    <button class="btn btn-full" onclick="logout()" style="background:linear-gradient(135deg,#0A2540,#1352DE);color:#fff;font-size:13px;padding:11px 20px;border-radius:12px;border:none;font-weight:600;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:8px;width:100%;">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
      Sign Out
    </button>
  </div>`;
}

function saveProfile() {
  const fn=$('prof-fname')?.value.trim(), ln=$('prof-lname')?.value.trim(), ph=$('prof-phone')?.value.trim();
  const email=$('prof-email')?.value.trim(), dob=$('prof-dob')?.value;
  if(!fn||!ln){addToast('Name fields required','error');return;}
  // Avatar already saved on pick; only regenerate initials avatar if no custom photo
  const newAvatar = currentUser.customAvatar ? currentUser.avatar :
    `https://ui-avatars.com/api/?name=${encodeURIComponent(fn)}+${encodeURIComponent(ln)}&background=1352DE&color=fff&size=128`;
  updateCurrentUser(u=>({...u, firstName:fn, lastName:ln, phone:ph,
    email:email||u.email, dob:dob||u.dob, avatar:newAvatar}));
  $('top-avatar').src=currentUser.avatar;
  addToast('Profile updated! ✅','success');
  profileEditMode=false;
  goScreen('profile');
}

// ─── Admin ───────────────────────────────────────────────────────────────────
let adminTab='users';
function renderAdmin() {
  const allTx=users.flatMap(u=>(u.transactions||[]).map(t=>({...t,user:`${u.firstName} ${u.lastName}`,userEmail:u.email,uid:u.id})));
  allTx.sort((a,b)=>new Date(b.date)-new Date(a.date));
  const totalDeposits=allTx.filter(t=>t.amount>0).reduce((s,t)=>s+t.amount,0);
  const totalTransfers=allTx.filter(t=>t.amount<0).reduce((s,t)=>s+Math.abs(t.amount),0);

  const userRows=users.map(u=>`
    <div style="border-bottom:1px solid var(--border);padding:16px 0;" id="admin-user-row-${u.id}">
      <!-- User info row -->
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
        <img src="${u.avatar}" alt="" style="width:40px;height:40px;border-radius:50%;object-fit:cover;flex-shrink:0;${u.blocked?'filter:grayscale(1);opacity:.5;':''}">
        <div style="flex:1;min-width:0;">
          <p style="font-weight:700;color:var(--text);font-size:14px;margin-bottom:2px;">${u.firstName} ${u.lastName} ${u.frozen?'🔒':''} ${u.blocked?'🚫':''} ${u.isPro?'👑':''} ${u.isPremium?'💎':''}</p>
          <p style="color:var(--text3);font-size:12px;margin-bottom:2px;">${u.email} · #${u.accountNumber?.slice(-6)}</p>
          <p style="color:#00C48C;font-size:13px;font-weight:700;">${fmtMoney(u.balance)}</p>
        </div>
      </div>
      <!-- Status badges -->
      <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;">
        ${u.blocked?'<span style="background:rgba(239,68,68,.12);color:#DC2626;font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;">BLOCKED</span>':''}
        ${u.frozen?'<span style="background:rgba(59,130,246,.12);color:#2563eb;font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;">FROZEN</span>':''}
        ${u.withdrawLink?'<span style="background:rgba(19,82,222,.1);color:#1352DE;font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;">🔗 Link set</span>':'<span style="background:var(--bg3);color:var(--text3);font-size:10px;font-weight:600;padding:2px 9px;border-radius:20px;">🔗 No link</span>'}
        ${(u.adminBtcAddress||u.adminEthAddress||u.adminUsdtAddress||u.adminBnbAddress||u.adminSolAddress)?'<span style="background:rgba(124,58,237,.1);color:#7c3aed;font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;">🔑 Wallet set</span>':'<span style="background:var(--bg3);color:var(--text3);font-size:10px;font-weight:600;padding:2px 9px;border-radius:20px;">🔑 No wallet</span>'}
        ${u.cryptoBalance!=null?'<span style="background:rgba(245,158,11,.1);color:#B45309;font-size:10px;font-weight:700;padding:2px 9px;border-radius:20px;">💎 $'+Number(u.cryptoBalance).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})+'</span>':'<span style="background:var(--bg3);color:var(--text3);font-size:10px;font-weight:600;padding:2px 9px;border-radius:20px;">💎 No crypto</span>'}
      </div>
      <!-- Toggle switches (stage changes — not saved until Save is tapped) -->
      <div style="background:var(--bg3);border-radius:14px;padding:12px 14px;margin-bottom:10px;">
        <p style="font-size:10px;font-weight:700;color:var(--text3);letter-spacing:.6px;text-transform:uppercase;margin-bottom:10px;">Account Controls</p>
        <div style="display:flex;flex-direction:column;gap:8px;">
          <label style="display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
            <span style="font-size:13px;font-weight:600;color:var(--text);">🔒 Freeze Account</span>
            <input type="checkbox" id="chk-frozen-${u.id}" ${u.frozen?'checked':''} onchange="adminMarkDirty('${u.id}')" style="width:18px;height:18px;cursor:pointer;accent-color:#2563eb;">
          </label>
          <label style="display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
            <span style="font-size:13px;font-weight:600;color:var(--text);">🚫 Block Account</span>
            <input type="checkbox" id="chk-blocked-${u.id}" ${u.blocked?'checked':''} onchange="adminMarkDirty('${u.id}')" style="width:18px;height:18px;cursor:pointer;accent-color:#ef4444;">
          </label>
          <label style="display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
            <span style="font-size:13px;font-weight:600;color:var(--text);">👑 Pro Plan</span>
            <input type="checkbox" id="chk-pro-${u.id}" ${u.isPro?'checked':''} onchange="adminMarkDirty('${u.id}')" style="width:18px;height:18px;cursor:pointer;accent-color:#d97706;">
          </label>
          <label style="display:flex;align-items:center;justify-content:space-between;cursor:pointer;">
            <span style="font-size:13px;font-weight:600;color:var(--text);">💎 Premium Plan</span>
            <input type="checkbox" id="chk-premium-${u.id}" ${u.isPremium?'checked':''} onchange="adminMarkDirty('${u.id}')" style="width:18px;height:18px;cursor:pointer;accent-color:#7c3aed;">
          </label>
        </div>
      </div>
      <!-- Save button (initially hidden, shown when a toggle is changed) -->
      <div id="admin-save-bar-${u.id}" style="display:none;margin-bottom:10px;">
        <button onclick="adminSaveToggles('${u.id}')" style="width:100%;padding:13px;border:none;border-radius:13px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;box-shadow:0 4px 16px rgba(19,82,222,.35);">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
          Save & Sync Changes
        </button>
      </div>
      <!-- Modal action buttons -->
      <div style="display:flex;gap:6px;flex-wrap:wrap;">
        <button onclick="adminEditBalance('${u.id}')" style="flex:1;min-width:80px;padding:9px 0;border-radius:10px;border:1px solid rgba(0,196,140,.3);background:rgba(0,196,140,.08);color:#00A677;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">💰 Balance</button>
        <button onclick="adminSetWithdrawLink('${u.id}')" style="flex:1;min-width:80px;padding:9px 0;border-radius:10px;border:1px solid rgba(19,82,222,.25);background:rgba(19,82,222,.08);color:#1352DE;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">🔗 Link</button>
        <button onclick="adminSetCryptoWallet('${u.id}')" style="flex:1;min-width:80px;padding:9px 0;border-radius:10px;border:1px solid rgba(124,58,237,.25);background:rgba(124,58,237,.08);color:#7c3aed;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">🔑 Wallet</button>
        <button onclick="adminSetCryptoBalance('${u.id}')" style="flex:1;min-width:80px;padding:9px 0;border-radius:10px;border:1px solid rgba(245,158,11,.3);background:rgba(245,158,11,.08);color:#B45309;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">💎 Crypto</button>
        ${!u.isAdmin ? `<button onclick="adminDeleteUser('${u.id}')" style="flex:1;min-width:80px;padding:9px 0;border-radius:10px;border:1px solid rgba(239,68,68,.3);background:rgba(239,68,68,.08);color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">🗑️ Delete</button>` : ''}
      </div>
    </div>`).join('');

  const txRows=allTx.slice(0,30).map((t,i)=>`
    <div style="display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);">
      <div style="width:8px;height:8px;border-radius:50%;background:${t.amount>0?'#00C48C':'#EF4444'};flex-shrink:0;"></div>
      <div style="flex:1;">
        <p style="font-size:13px;font-weight:600;color:var(--text);">${t.desc}</p>
        <p style="font-size:11px;color:var(--text3);">${t.user} · ${fmtDate(t.date)}</p>
      </div>
      <p style="font-weight:700;color:${t.amount>0?'#00C48C':'#EF4444'};font-size:14px;">${t.amount>0?'+':''}${fmtMoney(t.amount)}</p>
    </div>`).join('');

  return `<div style="padding:24px 20px;max-width:720px;margin:0 auto;">
    ${backBtn()}
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;">
      <div style="display:flex;align-items:center;gap:12px;">
        <div class="logo-icon" style="width:28px;height:28px;font-size:12px;">C</div>
        <div><h2 style="font-size:22px;font-weight:800;color:var(--text);">Admin Dashboard</h2><span class="badge" style="background:rgba(19,82,222,.13);color:#1352DE;">🛡️ Secure Session</span></div>
      </div>
      <button onclick="lockAdminSession()" style="background:var(--bg3);border:1.5px solid var(--border);border-radius:10px;padding:8px 14px;color:var(--text2);font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:6px;">🔒 Lock</button>
    </div>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin-bottom:24px;">
      ${[{label:'Total Users',value:users.length,icon:'👥',color:'#1352DE'},{label:'Total Transactions',value:allTx.length,icon:'📊',color:'#00C48C'},{label:'Total Deposits',value:fmtMoney(totalDeposits),icon:'📥',color:'#F59E0B'},{label:'Total Transfers',value:fmtMoney(totalTransfers),icon:'💸',color:'#EF4444'}].map(s=>`
        <div class="card" style="padding:18px;">
          <div style="font-size:24px;margin-bottom:6px;">${s.icon}</div>
          <p style="font-size:12px;color:var(--text3);font-weight:600;margin-bottom:2px;">${s.label}</p>
          <p style="font-size:20px;font-weight:800;color:${s.color};">${s.value}</p>
        </div>`).join('')}
    </div>
    <div style="display:flex;gap:8px;margin-bottom:20px;overflow-x:auto;">
      <button class="tab-btn ${adminTab==='users'?'active':''}" onclick="adminTab='users';goScreen('admin')">👥 Users</button>
      <button class="tab-btn ${adminTab==='transactions'?'active':''}" onclick="adminTab='transactions';goScreen('admin')">📊 Transactions</button>
      <button class="tab-btn ${adminTab==='codes'?'active':''}" onclick="adminTab='codes';goScreen('admin')">🔐 Codes</button>
    </div>
    <div class="card">
      ${adminTab==='users'?(users.length===0?'<p style="color:var(--text3);text-align:center;padding:24px;">No users registered yet.</p>':userRows):
        adminTab==='transactions'?(allTx.length===0?'<p style="color:var(--text3);text-align:center;padding:24px;">No transactions yet.</p>':txRows):
        renderAdminCodes()}
    </div>
  </div>`;
}

function adminSetWithdrawLink(id) {
  const u = users.find(u => u.id === id);
  if (!u) return;
  document.getElementById('admin-link-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'admin-link-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.75);backdrop-filter:blur(10px);z-index:5000;display:flex;align-items:center;justify-content:center;padding:20px;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:28px;max-width:420px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);animation:fadeUp .25s ease;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">🔗 Set Redirect Link</h3>
      <button onclick="document.getElementById('admin-link-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    <p style="font-size:13px;color:var(--text3,#94A3B8);margin-bottom:20px;">For <strong style="color:var(--text,#1E293B);">${u.firstName} ${u.lastName}</strong> — paste the personal WhatsApp link or URL they gave you. When they tap <em>UNFREEZE NOW</em>, they'll be sent directly here.</p>
    <div style="background:var(--bg3,#F1F5F9);border-radius:12px;padding:12px;margin-bottom:16px;font-size:12px;color:var(--text2,#475569);">
      <strong>Current link:</strong><br>
      <span style="font-family:'JetBrains Mono',monospace;word-break:break-all;color:${u.withdrawLink?'#1352DE':'#94A3B8'};">${u.withdrawLink || 'Not set'}</span>
    </div>
    <div class="input-group" style="margin-bottom:20px;">
      <label>Personal Link (WhatsApp DM or URL)</label>
      <input id="admin-link-input" type="url" placeholder="https://wa.me/234XXXXXXXXXX" value="${u.withdrawLink || ''}" style="font-size:14px;">
    </div>
    <div style="display:flex;gap:10px;">
      <button onclick="adminSaveWithdrawLink('${u.id}')" style="flex:1;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;">Save & Sync to User</button>
      ${u.withdrawLink ? `<button onclick="adminClearWithdrawLink('${u.id}')" style="padding:14px 16px;border:none;border-radius:14px;background:rgba(239,68,68,.1);color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;border:1px solid rgba(239,68,68,.2);">Clear</button>` : ''}
    </div>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('admin-link-input')?.focus(), 100);
}

function adminSaveWithdrawLink(id) {
  const val = (document.getElementById('admin-link-input')?.value || '').trim();
  if (!val || !val.startsWith('http')) { addToast('Enter a valid URL starting with https://', 'error'); return; }
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  users[idx] = { ...users[idx], withdrawLink: val };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  saveUsers();
  document.getElementById('admin-link-modal')?.remove();
  addToast(`✅ Link saved & synced to ${users[idx].firstName}'s account`, 'success');
  goScreen('admin');
}

function adminClearWithdrawLink(id) {
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  users[idx] = { ...users[idx], withdrawLink: '' };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  saveUsers();
  document.getElementById('admin-link-modal')?.remove();
  addToast('Link cleared', 'info');
  goScreen('admin');
}

// ─── Admin: Set Crypto Wallet Addresses ──────────────────────────────────────
function adminSetCryptoWallet(id) {
  const u = users.find(u => u.id === id);
  if (!u) return;
  document.getElementById('admin-wallet-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'admin-wallet-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.78);backdrop-filter:blur(12px);z-index:5000;display:flex;align-items:center;justify-content:center;padding:20px;overflow-y:auto;';

  const coins = [
    { key:'adminBtcAddress',  label:'BTC Address',  placeholder:'1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa',  hint:'Bitcoin mainnet address' },
    { key:'adminEthAddress',  label:'ETH / ERC-20', placeholder:'0x742d35Cc6634C0532925a3b844Bc454e4438f44e', hint:'Ethereum & USDT/BNB ERC-20' },
    { key:'adminUsdtAddress', label:'USDT (TRC-20)', placeholder:'TN1jJGXVbMfgzLzPWFYa7L1bN2gxK3u4VR', hint:'Tron network USDT address' },
    { key:'adminBnbAddress',  label:'BNB Address',  placeholder:'bnb1grpf0955h0ykzq3ar5nmum7y6gdfl6lxfn46h2', hint:'BNB Beacon Chain address' },
    { key:'adminSolAddress',  label:'SOL Address',  placeholder:'So11111111111111111111111111111111111111112', hint:'Solana mainnet address' },
  ];

  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:28px;max-width:460px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.45);animation:fadeUp .25s ease;max-height:90vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">🔑 Crypto Wallet Addresses</h3>
      <button onclick="document.getElementById('admin-wallet-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    <p style="font-size:13px;color:var(--text3,#94A3B8);margin-bottom:20px;">
      Setting addresses for <strong style="color:var(--text,#1E293B);">${u.firstName} ${u.lastName}</strong>. 
      These will appear as their real wallet addresses when they tap <em>Create My Wallet</em>.
    </p>
    ${coins.map(c => `
      <div style="margin-bottom:16px;">
        <label style="font-size:12px;font-weight:700;color:var(--text2,#475569);display:block;margin-bottom:6px;">${c.label}</label>
        <input id="admin-wallet-${c.key}" type="text"
          placeholder="${c.placeholder}"
          value="${u[c.key] || ''}"
          style="width:100%;padding:11px 14px;border-radius:10px;border:1.5px solid var(--input-border,#E2E8F0);font-size:12px;font-family:'DM Mono',monospace;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;"
          onfocus="this.style.borderColor='#7c3aed'" onblur="this.style.borderColor=''">
        <p style="font-size:11px;color:var(--text3,#94A3B8);margin-top:3px;">${c.hint}</p>
      </div>`).join('')}
    <div style="display:flex;gap:10px;margin-top:8px;">
      <button onclick="adminSaveCryptoWallet('${u.id}')" style="flex:1;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#7c3aed,#6d28d9);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 6px 20px rgba(124,58,237,.35);">💾 Save Wallet Addresses</button>
      <button onclick="adminClearCryptoWallet('${u.id}')" style="padding:14px 16px;border:none;border-radius:14px;background:rgba(239,68,68,.1);color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;border:1px solid rgba(239,68,68,.2);">Clear All</button>
    </div>
    <p style="font-size:11px;color:var(--text3,#94A3B8);text-align:center;margin-top:12px;">Leave any field blank to skip that coin. Only filled addresses will show in user's wallet.</p>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

async function adminSaveCryptoWallet(id) {
  const keys = ['adminBtcAddress','adminEthAddress','adminUsdtAddress','adminBnbAddress','adminSolAddress'];
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  const updates = {};
  keys.forEach(k => {
    const val = (document.getElementById('admin-wallet-'+k)?.value || '').trim();
    updates[k] = val;
  });
  // If user already has a cryptoWallet, update its addresses too so they see changes immediately
  const existingWallet = users[idx].cryptoWallet;
  if (existingWallet) {
    updates.cryptoWallet = {
      ...existingWallet,
      btcAddress:  updates.adminBtcAddress,
      ethAddress:  updates.adminEthAddress,
      address:     updates.adminEthAddress, // keep legacy key in sync
      usdtAddress: updates.adminUsdtAddress,
      bnbAddress:  updates.adminBnbAddress,
      solAddress:  updates.adminSolAddress,
    };
  }
  users[idx] = { ...users[idx], ...updates };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  await saveUsers();
  document.getElementById('admin-wallet-modal')?.remove();
  const hasAny = keys.some(k => updates[k]);
  addToast(hasAny ? `✅ Wallet addresses saved for ${users[idx].firstName}` : `Wallet addresses cleared for ${users[idx].firstName}`, 'success');
  goScreen('admin');
}

async function adminClearCryptoWallet(id) {
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  const cleared = { adminBtcAddress:'', adminEthAddress:'', adminUsdtAddress:'', adminBnbAddress:'', adminSolAddress:'' };
  // Also clear from live wallet if it exists
  if (users[idx].cryptoWallet) {
    cleared.cryptoWallet = { ...users[idx].cryptoWallet, btcAddress:'', ethAddress:'', address:'', usdtAddress:'', bnbAddress:'', solAddress:'' };
  }
  users[idx] = { ...users[idx], ...cleared };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  await saveUsers();
  document.getElementById('admin-wallet-modal')?.remove();
  addToast(`Wallet addresses cleared for ${users[idx].firstName}`, 'info');
  goScreen('admin');
}

// ─── Admin: Set Crypto Balance ───────────────────────────────────────────────
function adminSetCryptoBalance(id) {
  const u = users.find(u => u.id === id);
  if (!u) return;
  document.getElementById('admin-crypto-balance-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'admin-crypto-balance-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.78);backdrop-filter:blur(12px);z-index:5000;display:flex;align-items:center;justify-content:center;padding:20px;overflow-y:auto;';

  const wallet = u.cryptoWallet || {};
  const holdings = wallet.holdings || {};
  const coins = [
    { sym:'BTC',  label:'Bitcoin (BTC)',   color:'#F7931A' },
    { sym:'ETH',  label:'Ethereum (ETH)',  color:'#627EEA' },
    { sym:'USDT', label:'Tether (USDT)',    color:'#26A17B' },
    { sym:'BNB',  label:'BNB',             color:'#F3BA2F' },
    { sym:'SOL',  label:'Solana (SOL)',     color:'#9945FF' },
  ];
  const coinInputs = coins.map(c => `
    <div style="margin-bottom:12px;">
      <label style="font-size:12px;font-weight:700;color:var(--text2,#475569);display:flex;align-items:center;gap:6px;margin-bottom:5px;">
        <span style="width:8px;height:8px;border-radius:50%;background:${c.color};display:inline-block;flex-shrink:0;"></span>${c.label}
      </label>
      <input id="admin-crypto-coin-${c.sym}" type="number" min="0" step="any"
        placeholder="0.00000000" value="${holdings[c.sym] !== undefined ? holdings[c.sym] : ''}"
        style="width:100%;padding:10px 12px;border-radius:10px;border:1.5px solid var(--input-border,#E2E8F0);font-size:13px;font-family:'DM Mono',monospace;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;"
        onfocus="this.style.borderColor='#F59E0B'" onblur="this.style.borderColor=''">
    </div>`).join('');

  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:28px;max-width:440px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.45);animation:fadeUp .25s ease;max-height:92vh;overflow-y:auto;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
      <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:18px;">💎 Set Crypto Balance</h3>
      <button onclick="document.getElementById('admin-crypto-balance-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3,#94A3B8);">×</button>
    </div>
    <p style="font-size:13px;color:var(--text3,#94A3B8);margin-bottom:18px;">Setting crypto balance for <strong style="color:var(--text,#1E293B);">${u.firstName} ${u.lastName}</strong>.</p>
    <div style="background:linear-gradient(135deg,rgba(245,158,11,.08),rgba(245,158,11,.04));border:1.5px solid rgba(245,158,11,.25);border-radius:14px;padding:16px;margin-bottom:20px;">
      <label style="font-size:11px;font-weight:700;color:#B45309;display:block;margin-bottom:8px;letter-spacing:.5px;text-transform:uppercase;">Total Portfolio Value (USD)</label>
      <div style="position:relative;">
        <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);font-size:18px;font-weight:700;color:var(--text2,#475569);">$</span>
        <input id="admin-crypto-total" type="number" min="0" step="0.01" placeholder="0.00"
          value="${u.cryptoBalance !== undefined && u.cryptoBalance !== null ? u.cryptoBalance : ''}"
          style="width:100%;padding:12px 14px 12px 28px;border-radius:10px;border:1.5px solid rgba(245,158,11,.3);font-size:20px;font-weight:800;font-family:'DM Mono',monospace;background:var(--input-bg,#fff);color:var(--text,#1E293B);outline:none;"
          onfocus="this.style.borderColor='#F59E0B'" onblur="this.style.borderColor='rgba(245,158,11,.3)'">
      </div>
      <p style="font-size:11px;color:var(--text3,#94A3B8);margin-top:6px;">This shows as the portfolio total on the user's crypto screen.</p>
    </div>
    <p style="font-size:11px;font-weight:700;color:var(--text2,#475569);margin-bottom:12px;letter-spacing:.5px;text-transform:uppercase;">Per-Coin Holdings (amounts)</p>
    ${coinInputs}
    <div style="display:flex;gap:10px;margin-top:8px;">
      <button onclick="adminSaveCryptoBalance('${u.id}')" style="flex:1;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#F59E0B,#D97706);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;box-shadow:0 6px 20px rgba(245,158,11,.35);">💾 Save</button>
      <button onclick="adminClearCryptoBalance('${u.id}')" style="padding:14px 16px;border:none;border-radius:14px;background:rgba(239,68,68,.1);color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;border:1px solid rgba(239,68,68,.2);">Clear</button>
    </div>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('admin-crypto-total')?.focus(), 100);
}

function adminSaveCryptoBalance(id) {
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  const totalVal = document.getElementById('admin-crypto-total')?.value.trim();
  const cryptoBalance = totalVal !== '' && !isNaN(parseFloat(totalVal)) ? parseFloat(totalVal) : null;
  const coins = ['BTC','ETH','USDT','BNB','SOL'];
  const newHoldings = {};
  coins.forEach(sym => {
    const val = (document.getElementById('admin-crypto-coin-'+sym)?.value || '').trim();
    if (val !== '' && !isNaN(parseFloat(val)) && parseFloat(val) >= 0) newHoldings[sym] = parseFloat(val);
  });
  // Merge into existing wallet or auto-create wallet shell with admin addresses
  let wallet = users[idx].cryptoWallet || null;
  if (wallet) {
    wallet = { ...wallet, holdings: newHoldings };
  } else if (users[idx].adminBtcAddress || users[idx].adminEthAddress ||
             users[idx].adminUsdtAddress || users[idx].adminBnbAddress || users[idx].adminSolAddress) {
    wallet = {
      btcAddress:  users[idx].adminBtcAddress  || '',
      ethAddress:  users[idx].adminEthAddress  || '',
      address:     users[idx].adminEthAddress  || '',
      usdtAddress: users[idx].adminUsdtAddress || '',
      bnbAddress:  users[idx].adminBnbAddress  || '',
      solAddress:  users[idx].adminSolAddress  || '',
      createdAt: new Date().toISOString(),
      holdings: newHoldings
    };
  } else if (Object.keys(newHoldings).length > 0) {
    // No addresses yet but holdings set — create empty shell so balance shows
    wallet = { btcAddress:'', ethAddress:'', address:'', usdtAddress:'', bnbAddress:'', solAddress:'', createdAt: new Date().toISOString(), holdings: newHoldings };
  }
  users[idx] = { ...users[idx], cryptoBalance: cryptoBalance, cryptoWallet: wallet !== null ? wallet : users[idx].cryptoWallet };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  saveUsers();
  document.getElementById('admin-crypto-balance-modal')?.remove();
  const label = cryptoBalance !== null ? '$'+cryptoBalance.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}) : 'holdings only';
  addToast('✅ Crypto balance saved for '+users[idx].firstName, 'success');
  goScreen('admin');
}

function adminClearCryptoBalance(id) {
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  const wallet = users[idx].cryptoWallet;
  users[idx] = { ...users[idx], cryptoBalance: null, cryptoWallet: wallet ? { ...wallet, holdings: {} } : wallet };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  saveUsers();
  document.getElementById('admin-crypto-balance-modal')?.remove();
  addToast('Crypto balance cleared for '+users[idx].firstName, 'info');
  goScreen('admin');
}

function lockAdminSession() {
  adminSessionActive = false;
  addToast('🔒 Admin session locked', 'info');
  goScreen('profile');
}

function createAdminCode(plan) {
  // Generate a unique code like DB-A1B2-C3D4 (DB = DrimBank)
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const part = () => Array.from({length:4}, () => chars[Math.floor(Math.random()*chars.length)]).join('');

  let code;
  let attempts = 0;
  do { code = `DB-${part()}-${part()}`; attempts++; } while (activationCodes[code] && attempts < 100);

  const durationDays = plan === '2weeks' ? 14 : plan === '1month' ? 30 : plan === 'demo' ? 0 : 30;
  const planLabel = plan === '2weeks' ? '2 Weeks · ₦1,000' : plan === '1month' ? '1 Month Pro · ₦2,000' : plan === 'demo' ? 'Demo · 2 Hours' : '1 Month Premium · ₦2,500';
  const codeExpiryMs = plan === 'demo' ? 2 * 3600 * 1000 : 90 * 86400000;
  activationCodes[code] = {
    plan,
    createdAt: new Date().toISOString(),
    expiresAfter: new Date(Date.now() + codeExpiryMs).toISOString(),
    durationDays,
    durationHours: plan === 'demo' ? 2 : null,
    used: false,
    usedBy: null,
    usedAt: null,
  };
  // Persist immediately to localStorage so same-session users can redeem without a cloud round-trip
  try { localStorage.setItem('cb_activation_codes', JSON.stringify(activationCodes)); } catch(_) {}
  saveUsers();

  // Copy to clipboard
  navigator.clipboard?.writeText(code).catch(()=>{});

  // Show prominent modal with the code
  document.getElementById('admin-code-reveal-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'admin-code-reveal-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.88);backdrop-filter:blur(12px);z-index:5000;display:flex;align-items:center;justify-content:center;padding:24px;animation:fadeUp .2s ease;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:36px 32px;max-width:400px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 32px 80px rgba(0,0,0,.5);text-align:center;">
    <div style="font-size:52px;margin-bottom:12px;">\ud83c\udf89</div>
    <h3 style="font-weight:800;color:var(--text,#1E293B);font-size:20px;margin-bottom:6px;">Activation Code Ready!</h3>
    <p style="color:var(--text3,#94A3B8);font-size:13px;margin-bottom:24px;">Plan: <strong style="color:var(--text,#1E293B);">${planLabel}</strong> &middot; ${plan === 'demo' ? 'Expires in <strong style="color:#EF4444;">2 hours</strong>' : `Valid for ${durationDays} days`}</p>
    <div style="background:linear-gradient(135deg,#0A2540,#1352DE);border-radius:16px;padding:24px;margin-bottom:20px;">
      <p style="color:rgba(255,255,255,.65);font-size:11px;font-weight:700;letter-spacing:1px;text-transform:uppercase;margin-bottom:10px;">ACTIVATION CODE</p>
      <p id="reveal-code-text" style="font-family:'JetBrains Mono',monospace;font-size:26px;font-weight:800;color:#fff;letter-spacing:4px;line-height:1.2;">${code}</p>
      <p style="color:rgba(255,255,255,.55);font-size:11px;margin-top:10px;">Copied to clipboard \u2713</p>
    </div>
    <button onclick="const c=document.getElementById('reveal-code-text').textContent.trim();navigator.clipboard?.writeText(c).then(()=>addToast('Copied!','success')).catch(()=>addToast('Code: '+c,'info'));this.textContent='\u2705 Copied!';" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;margin-bottom:10px;">\ud83d\udccb Copy Code</button>
    <button onclick="document.getElementById('admin-code-reveal-modal').remove();goScreen('admin');" style="width:100%;padding:12px;border:1.5px solid var(--border,#E2E8F0);background:none;border-radius:14px;color:var(--text2,#475569);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;">Done \u2014 View All Codes</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) { overlay.remove(); goScreen('admin'); } });
  document.body.appendChild(overlay);
}

function deleteAdminCode(code) {
  delete activationCodes[code];
  saveUsers();
  addToast('Code deleted', 'info');
  goScreen('admin');
}

function renderAdminCodes() {
  const entries = Object.entries(activationCodes).sort((a,b) => new Date(b[1].createdAt) - new Date(a[1].createdAt));

  const rows = entries.map(([code, data]) => {
    const usedByUser = data.used ? users.find(u => u.id === data.usedBy) : null;
    const isExpiredCode = new Date(data.expiresAfter) < new Date();
    return `<div style="padding:14px 0;border-bottom:1px solid var(--border);">
      <div style="display:flex;align-items:flex-start;gap:10px;flex-wrap:wrap;">
        <div style="flex:1;min-width:160px;">
          <p style="font-family:'JetBrains Mono',monospace;font-weight:700;color:var(--text);font-size:15px;letter-spacing:1px;margin-bottom:4px;">${code}</p>
          <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:4px;">
            <span class="badge" style="background:${data.plan==='demo'?'rgba(239,68,68,.13)':data.plan==='2weeks'?'rgba(19,82,222,.13)':data.plan==='1month'?'rgba(255,215,0,.18)':'rgba(124,58,237,.15)'};color:${data.plan==='demo'?'#DC2626':data.plan==='2weeks'?'#1352DE':data.plan==='1month'?'#B45309':'#7c3aed'};">${data.plan==='demo'?'⏱ Demo · 2 Hours':data.plan==='2weeks'?'2 Weeks · ₦1,000':data.plan==='1month'?'1 Month · ₦2,000':'Premium · ₦2,500'}</span>
            <span class="badge" style="background:${data.used?'rgba(239,68,68,.12)':isExpiredCode?'rgba(245,158,11,.12)':'rgba(0,196,140,.12)'};color:${data.used?'#DC2626':isExpiredCode?'#92400E':'#00A677'};">${data.used?'USED':isExpiredCode?'EXPIRED':'AVAILABLE'}</span>
          </div>
          ${data.used ? `<p style="font-size:11px;color:var(--text3);">Used by: ${usedByUser?`${usedByUser.firstName} ${usedByUser.lastName}`:'Unknown'} · ${new Date(data.usedAt).toLocaleDateString()}</p>` : ''}
          <p style="font-size:11px;color:var(--text3);">Created: ${new Date(data.createdAt).toLocaleDateString()}</p>
        </div>
        <div style="display:flex;gap:6px;">
          <button onclick="navigator.clipboard?.writeText('${code}');addToast('Copied!','success')" style="background:rgba(19,82,222,.1);border:1px solid rgba(19,82,222,.2);border-radius:8px;padding:6px 12px;color:#1352DE;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">Copy</button>
          ${!data.used ? `<button onclick="deleteAdminCode('${code}')" style="background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2);border-radius:8px;padding:6px 12px;color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:12px;cursor:pointer;">Delete</button>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');

  return `<div>
    <p style="font-size:13px;color:var(--text2);margin-bottom:16px;line-height:1.6;">Generate unique one-time activation codes to give to users after they pay. Each code works only once and cannot be reused.</p>
    <div style="display:flex;gap:10px;margin-bottom:12px;">
      <button onclick="createAdminCode('2weeks')" style="flex:1;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;">
        <span>⚡ Generate 2-Week Code</span>
        <span style="font-size:11px;opacity:.8;">₦1,000 · 14 days</span>
      </button>
      <button onclick="createAdminCode('1month')" style="flex:1;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#FFD700,#FFA500);color:#7B3F00;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;">
        <span>👑 Generate Pro Code</span>
        <span style="font-size:11px;opacity:.7;">₦2,000 · 30 days</span>
      </button>
      <button onclick="createAdminCode('premium')" style="flex:1;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#7c3aed,#4c1d95);color:#fff;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:4px;">
        <span>💎 Premium Code</span>
        <span style="font-size:11px;opacity:.7;">₦2,500 · Crypto</span>
      </button>
    </div>
    <button onclick="createAdminCode('demo')" style="width:100%;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#7f1d1d,#991b1b);color:#fca5a5;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:24px;border:1px solid rgba(239,68,68,.3);">
      <span>⏱</span>
      <div style="text-align:left;">
        <div>Generate Demo Code (Testing)</div>
        <div style="font-size:11px;opacity:.7;">Full Premium access · Expires in 2 hours · For testing only</div>
      </div>
    </button>
    ${entries.length === 0 ? '<p style="color:var(--text3);text-align:center;padding:24px;">No codes generated yet.</p>' : rows}
  </div>`;
}

function adminEditBalance(id) {
  const u = users.find(u => u.id === id);
  if (!u) return;
  document.getElementById('admin-balance-modal')?.remove();
  const overlay = document.createElement('div');
  overlay.id = 'admin-balance-modal';
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(10,37,64,.75);backdrop-filter:blur(10px);z-index:5000;display:flex;align-items:center;justify-content:center;padding:20px;';
  overlay.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px;padding:28px;max-width:380px;width:100%;font-family:'Sora',sans-serif;box-shadow:0 24px 64px rgba(0,0,0,.4);">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
      <h3 style="font-weight:800;color:var(--text);font-size:18px;">💰 Edit Balance</h3>
      <button onclick="document.getElementById('admin-balance-modal').remove()" style="background:none;border:none;font-size:22px;cursor:pointer;color:var(--text3);">×</button>
    </div>
    <div style="background:var(--bg3);border-radius:12px;padding:14px;margin-bottom:20px;">
      <p style="font-size:13px;color:var(--text3);">Account</p>
      <p style="font-weight:700;color:var(--text);font-size:15px;">${u.firstName} ${u.lastName}</p>
      <p style="font-size:13px;color:#00C48C;font-weight:600;margin-top:4px;">Current: ${fmtMoney(u.balance)}</p>
    </div>
    <div class="input-group" style="margin-bottom:16px;">
      <label>New Balance (USD)</label>
      <input id="admin-new-balance" type="number" placeholder="${u.balance}" value="${u.balance}" style="font-size:18px;font-weight:700;text-align:center;">
    </div>
    <button onclick="adminSetBalance('${u.id}')" style="width:100%;padding:14px;border:none;border-radius:14px;background:linear-gradient(135deg,#00C48C,#00A677);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:15px;cursor:pointer;">Set Balance</button>
  </div>`;
  overlay.addEventListener('click', e => { if(e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
  setTimeout(() => document.getElementById('admin-new-balance')?.focus(), 100);
}

function adminSetBalance(id) {
  const val = parseFloat(document.getElementById('admin-new-balance')?.value);
  if (isNaN(val) || val < 0) { addToast('Enter a valid amount', 'error'); return; }
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;
  const tx = { id: uid(), type: val > users[idx].balance ? 'credit' : 'debit', desc: 'Admin Balance Adjustment', amount: val - users[idx].balance, date: new Date().toISOString(), category: 'Admin' };
  users[idx] = { ...users[idx], balance: val, transactions: [tx, ...(users[idx].transactions || [])] };
  if (currentUser && currentUser.id === id) currentUser = users[idx];
  saveUsers();
  document.getElementById('admin-balance-modal')?.remove();
  addToast(`✅ Balance set to ${fmtMoney(val)}`, 'success');
  goScreen('admin');
}

// ─── Admin: Mark a user row as having unsaved changes ────────────────────────
function adminMarkDirty(id) {
  const bar = document.getElementById('admin-save-bar-' + id);
  if (bar) bar.style.display = 'block';
}

// ─── Admin: Save toggle changes and sync to Firestore ────────────────────────
async function adminSaveToggles(id) {
  const idx = users.findIndex(u => u.id === id);
  if (idx < 0) return;

  const frozen   = document.getElementById('chk-frozen-'  + id)?.checked ?? users[idx].frozen;
  const blocked  = document.getElementById('chk-blocked-' + id)?.checked ?? users[idx].blocked;
  const isPro    = document.getElementById('chk-pro-'     + id)?.checked ?? users[idx].isPro;
  const isPremium= document.getElementById('chk-premium-' + id)?.checked ?? users[idx].isPremium;

  users[idx] = { ...users[idx], frozen, blocked, isPro, isPremium };
  if (currentUser && currentUser.id === id) currentUser = users[idx];

  // Show saving state on the button
  const bar = document.getElementById('admin-save-bar-' + id);
  const btn = bar?.querySelector('button');
  if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Saving…'; }

  await saveUsers();

  addToast('✅ Changes saved & synced for ' + users[idx].firstName, 'success');
  goScreen('admin');
}

function adminDeleteUser(id) {
  const u = users.find(x=>x.id===id);
  if (!u) return;
  if (u.isAdmin) { addToast('Cannot delete admin account', 'error'); return; }
  const confirmed = window.confirm(`⚠️ PERMANENTLY DELETE account of ${u.firstName} ${u.lastName}?\n\nThis cannot be undone. All data will be lost.`);
  if (!confirmed) return;
  const idx = users.findIndex(x=>x.id===id);
  if (idx >= 0) users.splice(idx, 1);
  saveUsers();
  addToast(`🗑️ ${u.firstName}'s account deleted`, 'success');
  goScreen('admin');
}

// ─── Avatar Upload ────────────────────────────────────────────────────────────
let pendingAvatarDataUrl = null;

function triggerAvatarUpload() {
  // Show a small picker: Gallery vs Camera
  showAvatarPicker();
}

function showAvatarPicker() {
  // Remove any old picker
  const old = document.getElementById('avatar-picker-sheet');
  if (old) old.remove();

  const sheet = document.createElement('div');
  sheet.id = 'avatar-picker-sheet';
  sheet.style.cssText = 'position:fixed;inset:0;z-index:2000;display:flex;align-items:flex-end;justify-content:center;background:rgba(10,37,64,.55);backdrop-filter:blur(6px);animation:fadeUp .2s ease;';
  sheet.innerHTML = `
    <div onclick="event.stopPropagation()" style="background:var(--modal-bg,#fff);border-radius:24px 24px 0 0;width:100%;max-width:480px;padding:24px 20px 40px;font-family:'Sora',sans-serif;">
      <div style="width:40px;height:4px;border-radius:4px;background:var(--border,#e2e8f0);margin:0 auto 24px;"></div>
      <p style="font-weight:700;font-size:17px;color:var(--text,#1e293b);margin-bottom:20px;text-align:center;">Change Profile Photo</p>
      <div style="display:flex;flex-direction:column;gap:10px;">
        <button onclick="dismissAvatarPicker();document.getElementById('avatar-camera-input').click();"
          style="width:100%;padding:15px;border-radius:14px;border:1.5px solid var(--border,#e2e8f0);background:var(--bg3,#f1f5f9);font-family:'Sora',sans-serif;font-weight:600;font-size:15px;color:var(--text,#1e293b);cursor:pointer;display:flex;align-items:center;gap:14px;">
          <span style="font-size:22px;">📷</span> Take a Photo
        </button>
        <button onclick="dismissAvatarPicker();document.getElementById('avatar-file-input').click();"
          style="width:100%;padding:15px;border-radius:14px;border:1.5px solid var(--border,#e2e8f0);background:var(--bg3,#f1f5f9);font-family:'Sora',sans-serif;font-weight:600;font-size:15px;color:var(--text,#1e293b);cursor:pointer;display:flex;align-items:center;gap:14px;">
          <span style="font-size:22px;">🖼️</span> Choose from Gallery
        </button>
        <button onclick="dismissAvatarPicker()"
          style="width:100%;padding:15px;border-radius:14px;border:none;background:transparent;font-family:'Sora',sans-serif;font-weight:600;font-size:15px;color:#94a3b8;cursor:pointer;">
          Cancel
        </button>
      </div>
    </div>`;
  sheet.addEventListener('click', dismissAvatarPicker);
  document.body.appendChild(sheet);
}

function dismissAvatarPicker() {
  const sheet = document.getElementById('avatar-picker-sheet');
  if (sheet) sheet.remove();
}

function handleAvatarFile(input) {
  const file = input.files && input.files[0];
  if (!file) return;
  input.value = ''; // reset so same file can be picked again
  if (!file.type.startsWith('image/')) { addToast('Please select an image file', 'error'); return; }
  const reader = new FileReader();
  reader.onload = (e) => {
    const dataUrl = e.target.result;
    // Crop to square using a canvas
    const img = new Image();
    img.onload = () => {
      const size = Math.min(img.width, img.height);
      const canvas = document.createElement('canvas');
      canvas.width = 256; canvas.height = 256;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img,
        (img.width - size) / 2, (img.height - size) / 2, size, size,
        0, 0, 256, 256);
      const cropped = canvas.toDataURL('image/jpeg', 0.85);
      pendingAvatarDataUrl = cropped;
      // Update all profile avatar previews live
      document.querySelectorAll('#prof-avatar-preview').forEach(el => el.src = cropped);
      $('top-avatar').src = cropped;
      // Save immediately regardless of edit mode
      updateCurrentUser(u => ({...u, avatar: cropped, customAvatar: true}));
      pendingAvatarDataUrl = null;
      addToast('Profile photo updated! ✅', 'success');
      // Refresh profile if on that screen
      if (currentAppScreen === 'profile') goScreen('profile');
    };
    img.src = dataUrl;
  };
  reader.readAsDataURL(file);
}

// ─── Receipt Modal ────────────────────────────────────────────────────────────
let currentReceiptTx = null;

// Called from transaction rows — stores the tx object and opens modal
function openReceiptById(txId) {
  const allTx = (currentUser.transactions || []);
  const tx = allTx.find(t => t.id === txId);
  if (!tx) return;
  openReceipt(tx);
}

function openReceipt(tx) {
  currentReceiptTx = tx;
  const isCredit = tx.amount > 0;
  const amtFormatted = (isCredit ? '+' : '') + fmtMoney(tx.amount);

  $('rcpt-direction-icon').textContent = isCredit ? '✅' : '🔴';
  $('rcpt-amount').textContent = amtFormatted;
  $('rcpt-amount').style.color = isCredit ? '#4ade80' : '#f87171';
  $('rcpt-desc').textContent = tx.desc || '';
  $('rcpt-id').textContent = '#' + (tx.id || '').toUpperCase();
  $('rcpt-date').textContent = new Date(tx.date).toLocaleString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
  $('rcpt-category').textContent = tx.category || 'General';
  const typeEl = $('rcpt-type');
  typeEl.textContent = isCredit ? 'Credit / Incoming' : 'Debit / Outgoing';
  typeEl.style.color = isCredit ? '#16a34a' : '#dc2626';
  $('rcpt-acct').textContent = '****' + (currentUser.accountNumber || '').slice(-4);
  $('rcpt-ref').textContent = 'REF-' + (tx.id || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);

  // Show/hide native share button
  const shareBtn = $('rcpt-share-btn');
  if (shareBtn) shareBtn.style.display = (navigator.share && navigator.canShare) ? 'flex' : 'none';

  $('receipt-modal').style.display = 'flex';
}

function closeReceiptModal() {
  $('receipt-modal').style.display = 'none';
}

// Render the receipt capture zone to a canvas using an off-screen clone with resolved colours
async function renderReceiptCanvas() {
  const source = $('receipt-capture');

  // Clone into a fixed-size off-screen container
  const wrapper = document.createElement('div');
  wrapper.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:380px;background:#ffffff;font-family:Arial,Helvetica,sans-serif;';
  const clone = source.cloneNode(true);
  clone.style.cssText = 'width:380px;background:#ffffff;';
  wrapper.appendChild(clone);
  document.body.appendChild(wrapper);

  try {
    const canvas = await html2canvas(wrapper, {
      scale: 2.5,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      width: 380,
      windowWidth: 380,
    });
    return canvas;
  } finally {
    document.body.removeChild(wrapper);
  }
}

async function receiptAction(type) {
  const btns = document.querySelectorAll('#receipt-modal button');
  btns.forEach(b => { b.disabled = true; b.style.opacity = '.6'; });
  addToast(type === 'pdf' ? 'Generating PDF…' : 'Generating image…', 'info');

  try {
    const canvas = await renderReceiptCanvas();
    const txId = (currentReceiptTx?.id || 'receipt').toUpperCase().slice(0, 8);

    if (type === 'image') {
      const link = document.createElement('a');
      link.download = `DrimBank-Receipt-${txId}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
      addToast('Receipt image downloaded! 🖼️', 'success');

    } else if (type === 'pdf') {
      const { jsPDF } = window.jspdf;
      // A4-ish portrait, width 380px worth
      const pxW = canvas.width / 2.5;
      const pxH = canvas.height / 2.5;
      const pdf = new jsPDF({ orientation: 'portrait', unit: 'pt', format: [pxW * 0.75, pxH * 0.75] });
      pdf.addImage(canvas.toDataURL('image/jpeg', 0.92), 'JPEG', 0, 0, pxW * 0.75, pxH * 0.75);
      pdf.save(`DrimBank-Receipt-${txId}.pdf`);
      addToast('Receipt PDF saved! 📄', 'success');

    } else if (type === 'share') {
      if (!navigator.share) { addToast('Sharing not supported in this browser', 'error'); return; }
      const blob = await new Promise(res => canvas.toBlob(res, 'image/png'));
      const file = new File([blob], `DrimBank-Receipt-${txId}.png`, { type: 'image/png' });
      const shareData = { title: 'DrimBank Receipt', text: `Transaction: ${currentReceiptTx?.desc || ''}\nAmount: ${$('rcpt-amount').textContent}`, files: [file] };
      if (navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
        addToast('Receipt shared! ↗️', 'success');
      } else {
        // Fallback: share text only
        await navigator.share({ title: 'DrimBank Receipt', text: shareData.text });
      }
    }
  } catch (err) {
    if (!err.message?.includes('cancel') && !err.message?.includes('abort')) {
      addToast('Action failed — try again', 'error');
    }
  } finally {
    btns.forEach(b => { b.disabled = false; b.style.opacity = '1'; });
  }
}

// ─── Withdrawal Restriction Modal ─────────────────────────────────────────────
function openWithdrawalModal() {
  const el = document.getElementById('withdrawal-restrict-modal');
  if (!el) return;
  el.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}
function closeWithdrawalModal() {
  const el = document.getElementById('withdrawal-restrict-modal');
  if (!el) return;
  el.style.display = 'none';
  document.body.style.overflow = '';
}

function handleUnfreezeNow() {
  const link = currentUser && currentUser.withdrawLink;
  if (link && link.startsWith('http')) {
    closeWithdrawalModal();
    window.open(link, '_blank', 'noopener,noreferrer');
  } else {
    closeWithdrawalModal();
    addToast('Please contact support to resolve this.', 'info');
    goScreen('support');
  }
}

// ─── Init ─────────────────────────────────────────────────────────────────────
window.addEventListener('DOMContentLoaded', async () => {
  await loadDarkPref();
  // Initialize Firebase FIRST so loadUsers() can read from Firestore, not just stale localStorage
  if (FIREBASE_CFG) {
    await _initFirestore(FIREBASE_CFG);
  }
  await loadUsers();

  // Always ensure the admin account exists (upsert — won't overwrite if already there)
  const ADMIN_ACCOUNT = {
    id: 'admin_nifemish',
    firstName: 'Nifemi',
    lastName: 'Admin',
    email: 'nifemish@gmail.com',
    phone: '',
    password: 'olayemi2',
    dob: '',
    accountNumber: genAccountNumber(),
    balance: 0,
    savings: 0,
    transactions: [],
    cards: [],
    loans: [],
    savingsPlans: [],
    isPro: true,
    isAdmin: true,
    createdAt: new Date().toISOString(),
    avatar: 'https://ui-avatars.com/api/?name=Nifemi+Admin&background=0A2540&color=fff&size=128',
  };
  const existing = users.find(u => u.email === ADMIN_ACCOUNT.email);
  if (!existing) {
    // First-ever run: create the admin account in Firestore
    users.push(ADMIN_ACCOUNT);
    await saveUsers();
  }
  // If admin already exists: do NOT touch or re-save it.
  // All admin-set fields (isPro, isPremium, balance, freeze, etc.) must be left
  // exactly as stored in Firestore. Any write here would race with the onSnapshot
  // listener and overwrite changes made from the admin dashboard.

  // Startup complete — allow onSnapshot to update UI from here on
  _appReady = true;

  // Restore session from localStorage (persists across browser closes and tab changes)
  const savedUserId = localStorage.getItem('cb_session_userId');
  const savedScreen = localStorage.getItem('cb_session_screen') || 'dashboard';
  if (savedUserId) {
    const restoredUser = users.find(u => u.id === savedUserId);
    if (restoredUser) {
      $('splash-screen').style.display = 'none';
      loginUser(restoredUser);
      // Override to go to the saved screen after loginUser sets it to 'dashboard'
      setTimeout(() => goScreen(savedScreen, false), 50);
      return;
    }
  }

  setTimeout(() => {
    $('splash-screen').style.display = 'none';
    showScreen('landing');
  }, 2200);
});




/* ===== BALANCE TOGGLE ===== */
let balanceHidden = false;
function toggleBalance(){
  balanceHidden = !balanceHidden;
  document.querySelectorAll('.balance-amount').forEach(el=>{
    if(balanceHidden){
      if(!el.dataset.real) el.dataset.real = el.innerHTML;
      el.innerHTML = '••••••';
    } else {
      if(el.dataset.real) el.innerHTML = el.dataset.real;
    }
  });
  // Update toggle button icons
  document.querySelectorAll('.balance-eye-icon').forEach(el=>{
    el.textContent = balanceHidden ? '🙈' : '👁️';
  });
}

/* ===== MASK EMAILS ===== */
function maskEmail(email){
  if(!email || !email.includes('@')) return email;
  const parts = email.split('@');
  return parts[0][0] + '*****' + parts[0].slice(-2) + '@' + parts[1];
}

/* ===== MASK PHONE ===== */
function maskPhone(phone){
  if(!phone) return '';
  return phone.substring(0,3) + '****' + phone.slice(-3);
}

/* ===== REMOVE REGISTRATION DATE ===== */
document.addEventListener('DOMContentLoaded',()=>{
  document.querySelectorAll('*').forEach(el=>{
    if(el.innerText && el.innerText.toLowerCase().includes('registration date')){
      el.style.display='none';
    }
  });
});

/* ===== ADD REALISTIC TRANSACTIONS ===== */
window.extraTransactions = [
 {name:'Amazon Purchase',amount:'-$84.20',date:'May 14, 2026'},
 {name:'Salary Deposit',amount:'+$4,250.00',date:'May 12, 2026'},
 {name:'Netflix Subscription',amount:'-$15.99',date:'May 11, 2026'},
 {name:'Apple Store',amount:'-$249.00',date:'May 09, 2026'},
 {name:'ATM Withdrawal',amount:'-$120.00',date:'May 08, 2026'},
 {name:'Uber Ride',amount:'-$18.75',date:'May 06, 2026'},
 {name:'Crypto Deposit',amount:'+$900.00',date:'May 05, 2026'}
];

/* ===== PIN LOCK SYSTEM ===== */
window.disableAutoLogout = false;




// ══════════════════════════════════════════════════════════════════
//  APP LOCK — 6-digit, device-local, SMART TRIGGER
//  Locks ONLY when: screen goes hidden for 30s OR window loses focus
//  for 30s (app switch, phone lock). NOT during active use.
// ══════════════════════════════════════════════════════════════════

// Safety: ensure currentUser is always accessible even if referenced before main script
if (typeof currentUser === 'undefined') { window.currentUser = null; }

const PIN_STORAGE_KEY = 'db_apppin_'; // per-user, localStorage only
const PIN_BG_GRACE_MS = 30 * 1000;   // 30s before lock triggers

let pinBuffer     = '';
let pinMode       = '';   // 'setup' | 'confirm' | 'unlock'
let pinSetupFirst = '';
let pinLockTimer  = null;
let pinLocked     = false;
let pinHiddenAt   = null; // timestamp when page went hidden

function getPinKey()  { return currentUser ? PIN_STORAGE_KEY + currentUser.id : null; }
function storedPin()  { const k=getPinKey(); return k ? localStorage.getItem(k) : null; }
function saveAppPin(p){ const k=getPinKey(); if(k) localStorage.setItem(k,p); }
function clearAppPin(){ const k=getPinKey(); if(k) localStorage.removeItem(k); }

function updatePinDots(state) {
  for(let i=0;i<6;i++){
    const d=document.getElementById('pld-'+i);
    if(!d) continue;
    d.className='pin-lock-dot';
    if(state==='error')   d.classList.add('error');
    else if(state==='success') d.classList.add('success');
    else if(i<pinBuffer.length) d.classList.add('filled');
  }
}
function pinSetError(msg){
  const el=document.getElementById('pin-error-msg');
  if(el) el.textContent=msg;
  updatePinDots('error');
  // Shake the dots row
  const dots=document.querySelector('#pin-lock-overlay .pin-lock-dot')?.parentElement;
  if(dots){ dots.style.animation='pinShake .4s ease'; setTimeout(()=>dots.style.animation='',420); }
  setTimeout(()=>{ pinBuffer=''; if(el) el.textContent=''; updatePinDots(); },950);
}

const PIN_TEXTS = {
  setup:   { heading:'Create App Lock PIN',   sub:'6-digit PIN · stored on this device only', badge:'Set Up Security' },
  confirm: { heading:'Confirm Your PIN',       sub:'Re-enter the same 6 digits',               badge:'Confirm PIN' },
  unlock:  { heading:'Enter Your PIN',         sub:'Enter your 6-digit app lock PIN',          badge:'Session Locked' },
};

function showPinOverlay(mode){
  pinMode=mode; pinBuffer=''; pinSetupFirst=''; pinLocked=true;
  const ov=document.getElementById('pin-lock-overlay'); if(!ov) return;
  if(currentUser){
    const av=document.getElementById('pin-avatar');
    const nm=document.getElementById('pin-user-name');
    if(av) av.src=currentUser.avatar||'';
    if(nm) nm.textContent=(currentUser.firstName||'')+' '+(currentUser.lastName||'');
  }
  const txt=PIN_TEXTS[mode]||PIN_TEXTS.unlock;
  const hd=document.getElementById('pin-heading');
  const sh=document.getElementById('pin-subheading');
  const bd=document.getElementById('pin-badge-label');
  if(hd) hd.textContent=txt.heading;
  if(sh) sh.textContent=txt.sub;
  if(bd) bd.textContent=txt.badge;
  updatePinDots();
  const err=document.getElementById('pin-error-msg'); if(err) err.textContent='';
  ov.style.display='flex';
  document.body.style.overflow='hidden';
}
function hidePinOverlay(){
  const ov=document.getElementById('pin-lock-overlay');
  if(ov) ov.style.display='none';
  document.body.style.overflow='';
  pinLocked=false; pinBuffer=''; pinHiddenAt=null;
}
function pinKeyPress(digit){
  if(pinBuffer.length>=6) return;
  pinBuffer+=digit; updatePinDots();
  if(pinBuffer.length===6) setTimeout(processPinEntry,60);
}
function pinBackspace(){
  if(pinBuffer.length>0){ pinBuffer=pinBuffer.slice(0,-1); updatePinDots(); }
}
function processPinEntry(){
  if(pinMode==='setup'){
    pinSetupFirst=pinBuffer; pinBuffer='';
    pinMode='confirm';
    const txt=PIN_TEXTS.confirm;
    const hd=document.getElementById('pin-heading'); if(hd) hd.textContent=txt.heading;
    const sh=document.getElementById('pin-subheading'); if(sh) sh.textContent=txt.sub;
    const bd=document.getElementById('pin-badge-label'); if(bd) bd.textContent=txt.badge;
    updatePinDots();
    const err=document.getElementById('pin-error-msg'); if(err) err.textContent='';
  } else if(pinMode==='confirm'){
    if(pinBuffer===pinSetupFirst){
      saveAppPin(pinBuffer); updatePinDots('success');
      if(currentUser) sendSecurityEmail({
        to:           currentUser.email,
        userName:     currentUser.firstName + ' ' + currentUser.lastName,
        eventType:    'PIN Changed',
        eventTitle:   'PIN Changed',
        eventSubtitle:'Your account PIN has been updated successfully.',
        eventMessage: 'Your DrimBank app PIN has been successfully changed. If you made this change, you are all set. If you did not, please take action immediately.',
        date:         _fmtDate(new Date().toISOString()),
      });
      setTimeout(()=>{ hidePinOverlay(); addToast('🔒 App lock PIN set!','success'); },520);
    } else {
      pinSetError("PINs don't match — try again");
      setTimeout(()=>{ pinMode='setup'; const txt=PIN_TEXTS.setup;
        const hd=document.getElementById('pin-heading'); if(hd) hd.textContent=txt.heading;
        const sh=document.getElementById('pin-subheading'); if(sh) sh.textContent=txt.sub; },980);
    }
  } else if(pinMode==='unlock'){
    if(pinBuffer===storedPin()){
      updatePinDots('success');
      setTimeout(()=>{ hidePinOverlay(); addToast('✅ Welcome back!','success'); },400);
    } else {
      pinSetError('Incorrect PIN — try again');
    }
  }
}
function pinForgotAction(){
  if(!confirm("Reset app lock PIN?\n\nYou'll be signed out and can set a new PIN after logging back in.")) return;
  clearAppPin(); pinSignOut();
}
function pinSignOut(){ hidePinOverlay(); clearAppPin(); logout(); }

// ══════════════════════════════════════════════════════════════════
//  BIOMETRIC AUTHENTICATION — WebAuthn (Face ID / Fingerprint)
//  Uses the Web Authentication API (FIDO2/WebAuthn) which maps to
//  Touch ID, Face ID, Windows Hello, Android fingerprint, etc.
// ══════════════════════════════════════════════════════════════════

const BIO_KEY = 'db_biometric_enrolled_';      // per-user flag in localStorage
const BIO_CRED_KEY = 'db_biometric_cred_id_';  // stored credential ID (base64)

function getBioKey()     { return currentUser ? BIO_KEY      + currentUser.id : null; }
function getBioCredKey() { return currentUser ? BIO_CRED_KEY + currentUser.id : null; }

/** Is WebAuthn available in this browser/device? */
function isBiometricAvailable() {
  return !!(window.PublicKeyCredential &&
            typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function');
}

/** Has the current user already enrolled biometrics? */
function hasBiometricEnrolled() {
  const k = getBioKey();
  return k ? localStorage.getItem(k) === '1' : false;
}

function setBiometricEnrolled(val) {
  const k = getBioKey();
  if (k) {
    if (val) localStorage.setItem(k, '1');
    else { localStorage.removeItem(k); const ck=getBioCredKey(); if(ck) localStorage.removeItem(ck); }
  }
}

function storeBioCredId(credId) {
  const k = getBioCredKey();
  if (k && credId) localStorage.setItem(k, credId);
}

function getStoredBioCredId() {
  const k = getBioCredKey();
  return k ? localStorage.getItem(k) : null;
}

/** Encode ArrayBuffer → base64 string */
function bufToB64(buf) {
  return btoa(String.fromCharCode(...new Uint8Array(buf)));
}

/** Decode base64 string → Uint8Array */
function b64ToBuf(b64) {
  return Uint8Array.from(atob(b64), c => c.charCodeAt(0));
}

/** Random challenge bytes */
function randomChallenge() {
  const buf = new Uint8Array(32);
  window.crypto.getRandomValues(buf);
  return buf;
}

// ── ENROLL: Register biometric credential ──────────────────────────────────────
/** True when the page is opened from the filesystem (file://) — WebAuthn won't work here */
function isFileProtocol() {
  return location.protocol === 'file:';
}

/** Show a friendly modal explaining that biometrics needs HTTPS */
function showBiometricHttpsRequired() {
  document.getElementById('bio-https-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'bio-https-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:5000;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(10,37,64,.82);backdrop-filter:blur(14px);';
  modal.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg);border-radius:28px;padding:32px 28px;max-width:420px;width:100%;animation:fadeUp .3s ease;border:1px solid var(--border);">
    <!-- Icon -->
    <div style="width:64px;height:64px;border-radius:20px;background:linear-gradient(135deg,rgba(19,82,222,.15),rgba(19,82,222,.07));border:1.5px solid rgba(19,82,222,.25);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;">
      <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="var(--blue)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        <circle cx="12" cy="16" r="1"/>
      </svg>
    </div>

    <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:var(--text);font-size:20px;text-align:center;margin-bottom:8px;">HTTPS Required</h3>
    <p style="color:var(--text3);font-size:13px;text-align:center;line-height:1.6;margin-bottom:24px;">
      Face ID and Fingerprint use your device's secure biometric sensor, which browsers only allow on <strong style="color:var(--text);">secure (HTTPS) connections</strong> — not when a file is opened directly from storage.
    </p>

    <!-- Steps -->
    <div style="background:var(--bg3);border-radius:16px;padding:18px;margin-bottom:20px;display:flex;flex-direction:column;gap:14px;">
      <p style="font-size:11px;font-weight:700;color:var(--text3);letter-spacing:.8px;text-transform:uppercase;margin-bottom:2px;">How to enable it</p>
      ${[
        ['1','Host the app on HTTPS','Upload index.html to any web host (Netlify, GitHub Pages, Vercel — all free). Biometrics will work instantly once it\'s served over https://.'],
        ['2','Or open via a local server','Run a local server: in terminal → <code style="font-family:monospace;background:var(--bg);padding:1px 6px;border-radius:4px;font-size:11px;">npx serve .</code> then open the localhost URL in your browser.'],
      ].map(([n,title,desc]) => `
        <div style="display:flex;gap:12px;align-items:flex-start;">
          <div style="width:24px;height:24px;border-radius:50%;background:var(--blue);color:#fff;font-family:'Sora',sans-serif;font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px;">${n}</div>
          <div>
            <p style="font-weight:700;color:var(--text);font-size:13px;margin-bottom:3px;">${title}</p>
            <p style="color:var(--text3);font-size:12px;line-height:1.5;">${desc}</p>
          </div>
        </div>`).join('')}
    </div>

    <!-- Alternative: device PIN fallback -->
    <div style="background:rgba(0,196,140,.07);border:1px solid rgba(0,196,140,.2);border-radius:14px;padding:14px 16px;margin-bottom:20px;display:flex;gap:10px;align-items:flex-start;">
      <span style="font-size:18px;flex-shrink:0;">💡</span>
      <div>
        <p style="font-weight:700;color:#00A677;font-size:13px;margin-bottom:2px;">Already protected</p>
        <p style="color:var(--text3);font-size:12px;line-height:1.5;">Your app is secured by a 6-digit app lock PIN and a transaction PIN. Biometrics is an <em>extra</em> convenience layer once you host on HTTPS.</p>
      </div>
    </div>

    <button onclick="document.getElementById('bio-https-modal').remove()" style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:700;font-size:15px;cursor:pointer;box-shadow:0 6px 20px rgba(19,82,222,.3);">
      Got it
    </button>
  </div>`;
  modal.addEventListener('click', e => { if(e.target === modal) modal.remove(); });
  document.body.appendChild(modal);
}

async function enrollBiometric() {
  if (!currentUser) { addToast('Please log in first', 'error'); return; }

  // ── Pre-flight: HTTPS check ───────────────────────────────────────────────────
  // WebAuthn only works on https:// or localhost. If the file is opened from the
  // filesystem (file://) the browser will throw NotAllowedError or SecurityError
  // with no meaningful message. Detect this early and show a clear explanation.
  if (isFileProtocol()) {
    showBiometricHttpsRequired();
    return;
  }

  if (!isBiometricAvailable()) {
    showBiometricUnavailable('This browser does not support WebAuthn / biometric authentication.');
    return;
  }

  let platformSupported = false;
  try {
    platformSupported = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
  } catch(e) {}

  if (!platformSupported) {
    showBiometricUnavailable('No biometric sensor (Face ID / Fingerprint) was detected on this device.');
    return;
  }

  const userId = new TextEncoder().encode(currentUser.id.slice(0,32).padEnd(32,' '));
  const challenge = randomChallenge();

  // rpId must exactly match the hostname being served from
  const rpId = location.hostname || 'localhost';

  const options = {
    challenge,
    rp: { name: 'DrimBank', id: rpId },
    user: {
      id: userId,
      name: currentUser.email || currentUser.id,
      displayName: (currentUser.firstName + ' ' + currentUser.lastName).trim(),
    },
    pubKeyCredParams: [
      { alg: -7,   type: 'public-key' }, // ES256 (preferred)
      { alg: -257, type: 'public-key' }, // RS256 (fallback)
    ],
    authenticatorSelection: {
      authenticatorAttachment: 'platform',  // device-bound sensor only
      userVerification: 'required',         // must use biometric / device PIN
      requireResidentKey: false,
    },
    timeout: 60000,
    attestation: 'none',
  };

  try {
    const credential = await navigator.credentials.create({ publicKey: options });
    storeBioCredId(bufToB64(credential.rawId));
    setBiometricEnrolled(true);
    document.getElementById('biometric-settings-sheet')?.remove();
    addToast('🎉 Biometric login enabled! You can now use Face ID or Fingerprint.', 'success');
    goScreen('profile');
  } catch(err) {
    if (err.name === 'NotAllowedError') {
      // Could be: user cancelled, timeout, OR the page isn't on HTTPS.
      // Double-check protocol just in case (some browsers delay the error).
      if (isFileProtocol() || location.protocol !== 'https:' && location.hostname !== 'localhost') {
        showBiometricHttpsRequired();
      } else {
        addToast('Biometric setup was cancelled. Tap "Enable" and follow your device prompt.', 'info');
      }
    } else if (err.name === 'InvalidStateError') {
      // Credential already exists for this user on this device
      setBiometricEnrolled(true);
      document.getElementById('biometric-settings-sheet')?.remove();
      addToast('✅ Biometric is already set up on this device!', 'success');
      goScreen('profile');
    } else if (err.name === 'SecurityError') {
      showBiometricHttpsRequired();
    } else {
      addToast('Biometric setup failed: ' + (err.message || err.name), 'error');
    }
  }
}

/** Show a simple "not available on this device" modal */
function showBiometricUnavailable(reason) {
  document.getElementById('bio-unavail-modal')?.remove();
  const modal = document.createElement('div');
  modal.id = 'bio-unavail-modal';
  modal.style.cssText = 'position:fixed;inset:0;z-index:5000;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(10,37,64,.82);backdrop-filter:blur(14px);';
  modal.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg);border-radius:28px;padding:32px 28px;max-width:400px;width:100%;animation:fadeUp .3s ease;border:1px solid var(--border);text-align:center;">
    <div style="font-size:48px;margin-bottom:16px;">🤷</div>
    <h3 style="font-family:'Sora',sans-serif;font-weight:800;color:var(--text);font-size:18px;margin-bottom:10px;">Not available here</h3>
    <p style="color:var(--text3);font-size:13px;line-height:1.6;margin-bottom:24px;">${reason}</p>
    <button onclick="document.getElementById('bio-unavail-modal').remove()" style="width:100%;padding:14px;border:none;border-radius:14px;background:var(--bg3);color:var(--text);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;">OK</button>
  </div>`;
  modal.addEventListener('click', e => { if(e.target === modal) modal.remove(); });
  document.body.appendChild(modal);
}

// ── VERIFY: Authenticate with biometric ────────────────────────────────────────
async function verifyBiometric() {
  if (!currentUser) return false;

  if (isFileProtocol()) {
    showBiometricHttpsRequired();
    return false;
  }

  if (!isBiometricAvailable()) {
    addToast('Biometrics not supported on this device.', 'error');
    return false;
  }

  const challenge = randomChallenge();
  const credIdB64 = getStoredBioCredId();
  const rpId = location.hostname || 'localhost';

  const options = {
    challenge,
    rpId,
    userVerification: 'required',
    timeout: 60000,
    allowCredentials: credIdB64 ? [{
      id: b64ToBuf(credIdB64),
      type: 'public-key',
      transports: ['internal'],
    }] : [],
  };

  try {
    const assertion = await navigator.credentials.get({ publicKey: options });
    return true;
  } catch(err) {
    if (err.name === 'NotAllowedError') {
      // User cancelled or timed out — silent
    } else if (err.name === 'SecurityError') {
      showBiometricHttpsRequired();
    } else {
      addToast('Biometric verification failed: ' + (err.message || err.name), 'error');
    }
    return false;
  }
}

// ── SETTINGS: Open biometric settings sheet ────────────────────────────────────
async function openBiometricSettings() {
  const enrolled = hasBiometricEnrolled();

  // Check availability first
  let available = false;
  let platformSupported = false;
  if (isBiometricAvailable()) {
    available = true;
    try {
      platformSupported = await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
    } catch(e) { platformSupported = false; }
  }

  document.getElementById('biometric-settings-sheet')?.remove();
  const sheet = document.createElement('div');
  sheet.id = 'biometric-settings-sheet';
  sheet.style.cssText = 'position:fixed;inset:0;z-index:4500;display:flex;align-items:flex-end;justify-content:center;background:rgba(10,37,64,.75);backdrop-filter:blur(12px);';

  const unavailableNote = isFileProtocol()
    ? `<div style="background:rgba(245,158,11,.08);border:1.5px solid rgba(245,158,11,.25);border-radius:14px;padding:16px;margin-bottom:20px;">
        <div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:12px;">
          <span style="font-size:20px;flex-shrink:0;">🔒</span>
          <div>
            <p style="font-weight:800;color:#92400E;font-size:14px;margin-bottom:3px;">HTTPS required</p>
            <p style="color:var(--text3);font-size:12px;line-height:1.5;">This app is currently open as a local file (<code style="font-family:monospace;font-size:11px;background:var(--bg);padding:1px 5px;border-radius:4px;">file://</code>). Browsers only allow Face ID / Fingerprint on secure <strong style="color:var(--text);">https://</strong> connections.</p>
          </div>
        </div>
        <button onclick="document.getElementById('biometric-settings-sheet')?.remove();showBiometricHttpsRequired();" style="width:100%;padding:11px;border:none;border-radius:10px;background:rgba(245,158,11,.18);color:#92400E;font-family:'Sora',sans-serif;font-weight:700;font-size:13px;cursor:pointer;border:1px solid rgba(245,158,11,.3);">
          How to fix this →
        </button>
       </div>`
    : (!available || !platformSupported)
    ? `<div style="background:rgba(239,68,68,.08);border:1px solid rgba(239,68,68,.2);border-radius:12px;padding:14px;margin-bottom:20px;display:flex;gap:10px;align-items:flex-start;">
        <span style="font-size:18px;">⚠️</span>
        <div>
          <p style="font-weight:700;color:#DC2626;font-size:13px;margin-bottom:3px;">Not available on this device</p>
          <p style="color:var(--text3);font-size:12px;">This browser or device doesn't support platform biometrics (Face ID / Fingerprint). Try on a mobile device with Chrome, Safari, or Firefox.</p>
        </div>
       </div>`
    : '';

  sheet.innerHTML = `
  <div onclick="event.stopPropagation()" style="background:var(--modal-bg);border-radius:28px 28px 0 0;width:100%;max-width:520px;padding:28px 24px 44px;animation:slideUp .3s ease;">
    <div style="width:40px;height:4px;border-radius:4px;background:var(--border);margin:0 auto 24px;"></div>
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:20px;">
      <div style="width:52px;height:52px;border-radius:16px;background:${enrolled?'rgba(0,196,140,.12)':'rgba(19,82,222,.1)'};border:1.5px solid ${enrolled?'rgba(0,196,140,.25)':'rgba(19,82,222,.2)'};display:flex;align-items:center;justify-content:center;">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="${enrolled?'#00A677':'var(--blue)'}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8 2 4.5 5 4 9"/><path d="M4 13c.5 3.5 3.5 6.5 8 7"/><path d="M20 9c-.5-4-4-7-8-7"/><path d="M20 13c-.5 3.5-3.5 6.5-8 7"/><path d="M9 9a3 3 0 0 1 6 0v3a3 3 0 0 1-6 0V9z"/></svg>
      </div>
      <div>
        <h3 style="font-weight:800;color:var(--text);font-size:18px;margin-bottom:2px;">Biometric Login</h3>
        <p style="color:var(--text3);font-size:13px;">${enrolled ? '✅ Enrolled on this device' : 'Not set up on this device'}</p>
      </div>
    </div>

    ${unavailableNote}

    <div style="background:var(--bg3);border-radius:16px;padding:18px;margin-bottom:20px;">
      <p style="font-size:13px;font-weight:700;color:var(--text);margin-bottom:10px;">What biometric login does</p>
      <div style="display:flex;flex-direction:column;gap:8px;">
        ${[
          ['🔓','Unlock the app','Use Face ID or Fingerprint instead of your 6-digit lock PIN'],
          ['✅','Approve transactions','Skip the transaction PIN — authenticate with your biometric'],
          ['🔐','Device-bound','Your biometric never leaves this device — even DrimBank can\'t read it'],
        ].map(([icon,title,desc])=>`
          <div style="display:flex;gap:10px;align-items:flex-start;">
            <span style="font-size:16px;margin-top:1px;">${icon}</span>
            <div><p style="font-weight:700;color:var(--text);font-size:13px;">${title}</p><p style="color:var(--text3);font-size:12px;">${desc}</p></div>
          </div>`).join('')}
      </div>
    </div>

    ${enrolled ? `
      <button onclick="doBiometricTestUnlock()" style="width:100%;padding:15px;border:1.5px solid rgba(19,82,222,.3);border-radius:14px;background:rgba(19,82,222,.06);color:var(--blue);font-family:'Sora',sans-serif;font-weight:700;font-size:15px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;margin-bottom:12px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8 2 4.5 5 4 9"/><path d="M4 13c.5 3.5 3.5 6.5 8 7"/><path d="M20 9c-.5-4-4-7-8-7"/><path d="M20 13c-.5 3.5-3.5 6.5-8 7"/><path d="M9 9a3 3 0 0 1 6 0v3a3 3 0 0 1-6 0V9z"/></svg>
        Test Biometric
      </button>
      <button onclick="disableBiometric()" style="width:100%;padding:15px;border:none;border-radius:14px;background:rgba(239,68,68,.08);color:#DC2626;font-family:'Sora',sans-serif;font-weight:700;font-size:15px;cursor:pointer;border:1.5px solid rgba(239,68,68,.2);">
        Remove Biometric Login
      </button>
    ` : `
      <button onclick="startBiometricEnroll()" ${(isFileProtocol() || !available||!platformSupported)?'disabled style="opacity:.45;cursor:not-allowed;"':''} style="width:100%;padding:15px;border:none;border-radius:14px;background:linear-gradient(135deg,#1352DE,#2D6BE4);color:#fff;font-family:'Sora',sans-serif;font-weight:700;font-size:15px;cursor:pointer;box-shadow:0 6px 20px rgba(19,82,222,.3);display:flex;align-items:center;justify-content:center;gap:8px;">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8 2 4.5 5 4 9"/><path d="M4 13c.5 3.5 3.5 6.5 8 7"/><path d="M20 9c-.5-4-4-7-8-7"/><path d="M20 13c-.5 3.5-3.5 6.5-8 7"/><path d="M9 9a3 3 0 0 1 6 0v3a3 3 0 0 1-6 0V9z"/></svg>
        Enable Face ID / Fingerprint
      </button>
    `}
    <button onclick="document.getElementById('biometric-settings-sheet').remove()" style="width:100%;padding:13px;border:none;background:none;color:var(--text3);font-family:'Sora',sans-serif;font-weight:600;font-size:14px;cursor:pointer;margin-top:10px;">Cancel</button>
  </div>`;

  sheet.addEventListener('click', e => { if(e.target===sheet) sheet.remove(); });
  document.body.appendChild(sheet);
}

async function startBiometricEnroll() {
  document.getElementById('biometric-settings-sheet')?.remove();
  await enrollBiometric();
}

async function disableBiometric() {
  if (!confirm('Remove biometric login from this device?\n\nYou can re-enable it at any time.')) return;
  setBiometricEnrolled(false);
  document.getElementById('biometric-settings-sheet')?.remove();
  addToast('Biometric login removed from this device.', 'info');
  goScreen('profile');
}

async function doBiometricTestUnlock() {
  document.getElementById('biometric-settings-sheet')?.remove();
  const ok = await verifyBiometric();
  if (ok) addToast('✅ Biometric verified! Face ID / Fingerprint is working correctly.', 'success');
}

// ── UNLOCK via biometric (from PIN lock overlay) ───────────────────────────────
async function doBiometricUnlock() {
  const ok = await verifyBiometric();
  if (ok) {
    hidePinOverlay();
    addToast('✅ Welcome back!', 'success');
  }
}

// ── TRANSACTION APPROVAL via biometric ────────────────────────────────────────
async function doBiometricTransactionApproval() {
  const ok = await verifyBiometric();
  if (ok) {
    document.getElementById('pin-verify-overlay')?.remove();
    document.getElementById('pay-confirm-overlay')?.remove();
    executeTransfer(pendingTransfer);
  }
}

// ── Show/hide the biometric unlock button on the PIN overlay ──────────────────
// The original showPinOverlay is defined earlier in the same script block;
// we patch it after DOMContentLoaded so everything is defined first.
document.addEventListener('DOMContentLoaded', () => {
  const _origShow = window.showPinOverlay;
  if (typeof _origShow === 'function') {
    window.showPinOverlay = function(mode) {
      _origShow.call(this, mode);
      setTimeout(() => {
        const wrap = document.getElementById('biometric-unlock-btn-wrap');
        if (wrap) wrap.style.display = (mode === 'unlock' && hasBiometricEnrolled()) ? 'block' : 'none';
        if (mode === 'unlock' && hasBiometricEnrolled()) {
          setTimeout(doBiometricUnlock, 600);
        }
      }, 100);
    };
  }
});

// ── Patch openPinVerifyModal to inject biometric button dynamically ────────────
const _origOpenPinVerifyModal = window.openPinVerifyModal;
window.openPinVerifyModal = function() {
  if (typeof _origOpenPinVerifyModal === 'function') _origOpenPinVerifyModal();
  // After modal is in DOM, inject the biometric button if enrolled
  setTimeout(() => {
    const wrap = document.getElementById('biometric-tx-btn-wrap');
    if (!wrap) {
      // If wrap doesn't exist (template string evaluation), inject it manually
      if (hasBiometricEnrolled()) {
        const errDiv = document.getElementById('pin-error');
        if (errDiv && !document.getElementById('biometric-tx-btn-wrap')) {
          const btn = document.createElement('div');
          btn.id = 'biometric-tx-btn-wrap';
          btn.style.marginBottom = '10px';
          btn.innerHTML = `<button onclick="doBiometricTransactionApproval()" style="width:100%;padding:13px;border:none;border-radius:14px;background:linear-gradient(135deg,rgba(19,82,222,.12),rgba(19,82,222,.06));border:1.5px solid rgba(19,82,222,.25);color:var(--blue);font-family:'Sora',sans-serif;font-weight:700;font-size:14px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2C8 2 4.5 5 4 9"/><path d="M4 13c.5 3.5 3.5 6.5 8 7"/><path d="M20 9c-.5-4-4-7-8-7"/><path d="M20 13c-.5 3.5-3.5 6.5-8 7"/><path d="M9 9a3 3 0 0 1 6 0v3a3 3 0 0 1-6 0V9z"/></svg>
            Use Face ID / Fingerprint
          </button>`;
          errDiv.parentNode.insertBefore(btn, errDiv);
        }
      }
    } else {
      wrap.style.display = hasBiometricEnrolled() ? 'block' : 'none';
    }
  }, 80);
};

// ── SMART LOCK TRIGGER ──────────────────────────────────────────
// Lock ONLY fires after 30s of the page being hidden (phone locked /
// app switched). Activity while page is visible NEVER resets a timer.

function triggerPinLock(){
  if(!currentUser || pinLocked) return;
  showPinOverlay(storedPin() ? 'unlock' : 'setup');
}
function cancelPinTimer(){
  clearTimeout(pinLockTimer); pinLockTimer=null;
}

// Page visibility: tab hidden = start 30s countdown; visible = cancel if not elapsed
document.addEventListener('visibilitychange',()=>{
  if(!currentUser) return;
  if(document.hidden){
    if(!pinLocked){
      pinHiddenAt = Date.now();
      cancelPinTimer();
      pinLockTimer = setTimeout(triggerPinLock, PIN_BG_GRACE_MS);
    }
  } else {
    // Came back — check how long we were gone
    const elapsed = pinHiddenAt ? (Date.now() - pinHiddenAt) : 0;
    pinHiddenAt = null;
    if(pinLocked) return; // already locked, stay locked
    if(elapsed < PIN_BG_GRACE_MS){
      // Not long enough — cancel the pending lock
      cancelPinTimer();
    }
    // else: timer already fired and lock is showing — let it stay
  }
});

// Window blur (switch app, minimize): same grace period
window.addEventListener('blur',()=>{
  if(!currentUser||pinLocked) return;
  if(!pinHiddenAt) pinHiddenAt=Date.now();
  cancelPinTimer();
  pinLockTimer=setTimeout(triggerPinLock, PIN_BG_GRACE_MS);
});
window.addEventListener('focus',()=>{
  if(!currentUser||pinLocked) return;
  const elapsed = pinHiddenAt ? (Date.now()-pinHiddenAt) : 0;
  pinHiddenAt=null;
  if(elapsed < PIN_BG_GRACE_MS) cancelPinTimer();
});

// Patch loginUser / logout
document.addEventListener('DOMContentLoaded',()=>{
  const orig=window.loginUser;
  if(typeof orig==='function'){
    window.loginUser=function(user){
      orig.call(this,user);
      // Only ask for PIN setup once, right after login. Don't lock immediately.
      setTimeout(()=>{
        const pin=storedPin();
        if(!pin) showPinOverlay('setup');
        // If PIN already set, don't do anything — lock only triggers on bg/blur
      },900);
    };
  }
  const origOut=window.logout;
  if(typeof origOut==='function'){
    window.logout=function(){
      cancelPinTimer(); pinLocked=false; pinHiddenAt=null;
      origOut.call(this);
    };
  }
});



// ─── Auto Update System ───────────────────────────────────────────────────────
const APP_VERSION = '1.1.0';
const VERSION_URL = 'https://raw.githubusercontent.com/Nifemish/DrimBank/main/version.json';

async function checkForUpdate() {
  try {
    const res = await fetch(VERSION_URL + '?t=' + Date.now());
    if (!res.ok) return;
    const data = await res.json();
    const latest = data.version;
    const url = data.url;
    if (latest && latest !== APP_VERSION) {
      document.getElementById('ub-version-text').textContent =
        `Version ${latest} is ready — tap to get the latest features!`;
      document.getElementById('update-banner').dataset.url = url || location.href;
      document.getElementById('update-banner').style.display = 'block';
    }
  } catch(e) {
    // Silently fail — no update check available
  }
}

function applyUpdate() {
  const url = document.getElementById('update-banner').dataset.url || location.href;
  // Clear cache and reload
  if ('caches' in window) {
    caches.keys().then(keys => keys.forEach(k => caches.delete(k)));
  }
  window.location.href = url + '?v=' + Date.now();
}

function dismissUpdate() {
  document.getElementById('update-banner').style.display = 'none';
}

// Check on load and every 30 minutes
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(checkForUpdate, 3000); // wait 3s after load
  setInterval(checkForUpdate, 30 * 60 * 1000);
});
